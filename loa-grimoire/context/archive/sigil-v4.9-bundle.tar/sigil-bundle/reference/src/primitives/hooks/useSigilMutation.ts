// src/primitives/hooks/useSigilMutation.ts
// Sigil v4.9 — Transaction Objects (Sync + Visual + Input)

import { useState, useCallback, useRef } from 'react';
import { 
  PhysicsMode, 
  PhysicsConfig, 
  PHYSICS_CONFIG,
  GoldComponent,
  gold,
} from '../types';

// ============================================================================
// CONFIGURATION
// ============================================================================

interface SigilMutationConfig<TData, TVariables> {
  /**
   * The mutation function to execute
   */
  mutation: (variables: TVariables) => Promise<TData>;
  
  /**
   * Physics mode determines sync + visual + input behavior
   * - critical: pessimistic sync, 800ms animation, disabled during mutation
   * - standard: optimistic sync, 200ms animation, enabled
   * - instant: optimistic sync, 50ms animation, enabled
   * - playful: optimistic sync, 300ms bouncy animation, enabled
   */
  physics: PhysicsMode;
  
  /**
   * Optional callbacks
   */
  onSuccess?: (data: TData) => void;
  onError?: (error: Error) => void;
  onSettled?: () => void;
  
  /**
   * Optimistic update function (for optimistic sync)
   */
  optimisticUpdate?: (variables: TVariables) => void;
  
  /**
   * Rollback function (for optimistic sync on error)
   */
  rollback?: () => void;
  
  // =========================================================================
  // FRICTION BUDGET — Escape hatch (tracked)
  // =========================================================================
  
  /**
   * Override physics config (requires reason)
   * This is tracked and contributes to Taste Debt
   */
  unsafe_override_physics?: Partial<PhysicsConfig>;
  
  /**
   * Required if unsafe_override_physics is used
   */
  unsafe_override_reason?: string;
}

// ============================================================================
// STATE
// ============================================================================

type MutationState = 'idle' | 'pending' | 'success' | 'error';

interface MutationResult<TData, TVariables> {
  /**
   * Execute the mutation
   */
  commit: (variables: TVariables) => Promise<TData | undefined>;
  
  /**
   * Current state
   */
  state: MutationState;
  
  /**
   * Convenience booleans
   */
  isIdle: boolean;
  isPending: boolean;
  isSuccess: boolean;
  isError: boolean;
  
  /**
   * Last error (if any)
   */
  error: Error | null;
  
  /**
   * Last data (if any)
   */
  data: TData | null;
  
  /**
   * Input disabled (true during critical mutations)
   */
  disabled: boolean;
  
  /**
   * CSS variables for animation
   */
  style: React.CSSProperties;
  
  /**
   * Spread props for interactive elements
   */
  props: {
    disabled: boolean;
    style: React.CSSProperties;
    'data-sigil-physics': PhysicsMode;
    'data-sigil-state': MutationState;
  } & Record<string, unknown>;
  
  /**
   * Reset to idle state
   */
  reset: () => void;
}

// ============================================================================
// FRICTION TRACKING
// ============================================================================

function reportFriction(
  physics: PhysicsMode,
  override: Partial<PhysicsConfig>,
  reason: string
) {
  // In development, log to console and friction log
  if (process.env.NODE_ENV !== 'production') {
    console.warn(
      `[Sigil Friction] Physics override in ${physics} mode:`,
      override,
      `Reason: ${reason}`
    );
    
    // Would normally write to sigil-mark/friction-log.json
    // This is handled by the Gardener in CI
  }
}

// ============================================================================
// HOOK IMPLEMENTATION
// ============================================================================

/**
 * Transaction object that binds sync strategy to animation physics.
 * 
 * @example
 * // Critical transaction (pessimistic sync, heavy animation)
 * const transfer = useSigilMutation({
 *   mutation: (vars) => api.transfer(vars.amount, vars.to),
 *   physics: 'critical',
 * });
 * 
 * <button {...transfer.props} onClick={() => transfer.commit({ amount: 100 })}>
 *   {transfer.isPending ? 'Processing...' : 'Transfer $100'}
 * </button>
 * 
 * @example
 * // Standard transaction (optimistic sync, snappy animation)
 * const update = useSigilMutation({
 *   mutation: (vars) => api.updateTitle(vars.title),
 *   physics: 'standard',
 *   optimisticUpdate: (vars) => setTitle(vars.title),
 *   rollback: () => setTitle(previousTitle),
 * });
 */
export function useSigilMutation<TData = unknown, TVariables = void>(
  config: SigilMutationConfig<TData, TVariables>
): MutationResult<TData, TVariables> {
  const { 
    mutation, 
    physics, 
    onSuccess, 
    onError, 
    onSettled,
    optimisticUpdate,
    rollback,
    unsafe_override_physics,
    unsafe_override_reason,
  } = config;
  
  // Validate friction budget
  if (unsafe_override_physics && !unsafe_override_reason) {
    throw new Error(
      '[Sigil] unsafe_override_physics requires unsafe_override_reason. ' +
      'If you need to override Gold physics, explain why.'
    );
  }
  
  // Track friction
  if (unsafe_override_physics && unsafe_override_reason) {
    reportFriction(physics, unsafe_override_physics, unsafe_override_reason);
  }
  
  // Resolve physics config
  const baseConfig = PHYSICS_CONFIG[physics];
  const resolvedConfig: PhysicsConfig = unsafe_override_physics
    ? { ...baseConfig, ...unsafe_override_physics }
    : baseConfig;
  
  // State
  const [state, setState] = useState<MutationState>('idle');
  const [error, setError] = useState<Error | null>(null);
  const [data, setData] = useState<TData | null>(null);
  
  // Prevent double-commits
  const isCommitting = useRef(false);
  
  // Commit function
  const commit = useCallback(async (variables: TVariables): Promise<TData | undefined> => {
    if (isCommitting.current) {
      console.warn('[Sigil] Mutation already in progress');
      return undefined;
    }
    
    isCommitting.current = true;
    setState('pending');
    setError(null);
    
    try {
      // Optimistic update (if provided and sync is optimistic)
      if (resolvedConfig.syncStrategy === 'optimistic' && optimisticUpdate) {
        optimisticUpdate(variables);
      }
      
      // Execute mutation
      const result = await mutation(variables);
      
      // Success
      setData(result);
      setState('success');
      onSuccess?.(result);
      
      return result;
    } catch (err) {
      const error = err instanceof Error ? err : new Error(String(err));
      
      // Rollback optimistic update
      if (resolvedConfig.syncStrategy === 'optimistic' && rollback) {
        rollback();
      }
      
      setError(error);
      setState('error');
      onError?.(error);
      
      return undefined;
    } finally {
      isCommitting.current = false;
      onSettled?.();
    }
  }, [mutation, resolvedConfig.syncStrategy, optimisticUpdate, rollback, onSuccess, onError, onSettled]);
  
  // Reset function
  const reset = useCallback(() => {
    setState('idle');
    setError(null);
    setData(null);
  }, []);
  
  // CSS variables for animation
  const style: React.CSSProperties = {
    '--sigil-duration': `${resolvedConfig.duration}ms`,
    '--sigil-easing': resolvedConfig.easing,
  } as React.CSSProperties;
  
  // Disabled during critical mutations
  const disabled = physics === 'critical' && state === 'pending';
  
  // Keyboard props for keyboard-first/required modes
  const keyboardProps: Record<string, unknown> = {};
  if (resolvedConfig.inputMode === 'keyboard-first' || resolvedConfig.inputMode === 'keyboard-required') {
    keyboardProps.tabIndex = 0;
  }
  
  // Combined props for spreading
  const props = {
    disabled,
    style,
    'data-sigil-physics': physics,
    'data-sigil-state': state,
    ...keyboardProps,
  };
  
  return {
    commit,
    state,
    isIdle: state === 'idle',
    isPending: state === 'pending',
    isSuccess: state === 'success',
    isError: state === 'error',
    error,
    data,
    disabled,
    style,
    props,
    reset,
  };
}

// Type marker for Gold status
Object.assign(useSigilMutation, gold('standard', 'standard'));

export type { SigilMutationConfig, MutationResult };
