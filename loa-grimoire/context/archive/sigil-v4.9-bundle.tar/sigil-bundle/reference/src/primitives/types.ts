// src/primitives/types.ts
// Sigil v4.9 — Type-Level Authority

import type { ComponentType, FC } from 'react';

// ============================================================================
// INTENT & PHYSICS ENUMS
// ============================================================================

/**
 * Gold intent categories (compiler-enforced)
 */
export type GoldIntent =
  | 'destructive'    // Irreversible, high friction
  | 'critical'       // Financial, server-tick
  | 'standard'       // Normal interaction
  | 'machinery'      // High-density admin
  | 'marketing';     // Playful, attention

/**
 * Physics modes (determines sync + visual + input)
 */
export type PhysicsMode =
  | 'critical'       // Pessimistic, 500-800ms, keyboard-first
  | 'standard'       // Optimistic, 150-200ms, keyboard-first
  | 'instant'        // Optimistic, 50ms, mouse-ok
  | 'playful';       // Optimistic, 200-400ms, mouse-ok

/**
 * Sync strategies
 */
export type SyncStrategy = 'pessimistic' | 'optimistic';

/**
 * Input physics modes
 */
export type InputMode = 'keyboard-first' | 'keyboard-required' | 'mouse-ok';

// ============================================================================
// COMPONENT STATUS MARKERS
// ============================================================================

/**
 * Gold component marker — verified, stable, full trust.
 * 
 * @example
 * export const Button: FC<Props> & GoldComponent<'standard'> = ...
 */
export interface GoldComponent<
  TIntent extends GoldIntent = 'standard',
  TPhysics extends PhysicsMode = 'standard'
> {
  readonly __sigil_tier: 'gold';
  readonly __sigil_intent: TIntent;
  readonly __sigil_physics: TPhysics;
}

/**
 * Silver component marker — probationary, 14-day monitoring.
 * 
 * @example
 * export const NewButton: FC<Props> & SilverComponent<'standard'> = ...
 */
export interface SilverComponent<TIntent extends GoldIntent = 'standard'> {
  readonly __sigil_tier: 'silver';
  readonly __sigil_intent: TIntent;
  readonly __sigil_promoted_at: string;  // ISO date
}

/**
 * Draft marker — exploration mode, blocked at merge.
 * 
 * @example
 * const Experiment: Draft<FC> = () => <div>Playing...</div>;
 */
export type Draft<T> = T & {
  readonly __sigil_draft: true;
};

// ============================================================================
// PHYSICS CONFIGURATION
// ============================================================================

export interface PhysicsConfig {
  duration: number;
  easing: string;
  syncStrategy: SyncStrategy;
  inputMode: InputMode;
}

export const PHYSICS_CONFIG: Record<PhysicsMode, PhysicsConfig> = {
  critical: {
    duration: 800,
    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    syncStrategy: 'pessimistic',
    inputMode: 'keyboard-first',
  },
  standard: {
    duration: 200,
    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
    syncStrategy: 'optimistic',
    inputMode: 'keyboard-first',
  },
  instant: {
    duration: 50,
    easing: 'linear',
    syncStrategy: 'optimistic',
    inputMode: 'mouse-ok',
  },
  playful: {
    duration: 300,
    easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    syncStrategy: 'optimistic',
    inputMode: 'mouse-ok',
  },
};

// ============================================================================
// UTILITY TYPES
// ============================================================================

/**
 * Check if a component is Gold
 */
export function isGold<T>(component: T): component is T & GoldComponent {
  return (component as any)?.__sigil_tier === 'gold';
}

/**
 * Check if a component is Silver
 */
export function isSilver<T>(component: T): component is T & SilverComponent {
  return (component as any)?.__sigil_tier === 'silver';
}

/**
 * Check if a component is Draft
 */
export function isDraft<T>(component: T): component is Draft<T> {
  return (component as any)?.__sigil_draft === true;
}

/**
 * Create Gold component markers
 */
export function gold<
  TIntent extends GoldIntent,
  TPhysics extends PhysicsMode
>(intent: TIntent, physics: TPhysics): GoldComponent<TIntent, TPhysics> {
  return {
    __sigil_tier: 'gold',
    __sigil_intent: intent,
    __sigil_physics: physics,
  };
}

/**
 * Create Silver component markers
 */
export function silver<TIntent extends GoldIntent>(
  intent: TIntent
): SilverComponent<TIntent> {
  return {
    __sigil_tier: 'silver',
    __sigil_intent: intent,
    __sigil_promoted_at: new Date().toISOString(),
  };
}

// ============================================================================
// FRICTION BUDGET TYPES
// ============================================================================

export interface FrictionOverride {
  file: string;
  rule: string;
  expected: unknown;
  actual: unknown;
  reason: string;
  author: string;
  date: string;
}

export interface FrictionLog {
  overrides: FrictionOverride[];
  lastUpdated: string;
}
