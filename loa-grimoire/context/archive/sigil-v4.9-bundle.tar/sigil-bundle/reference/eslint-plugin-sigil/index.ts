// eslint-plugin-sigil/index.ts
// Sigil v4.9 — Token Enforcement via ESLint

import type { Rule } from 'eslint';

// ============================================================================
// TOKEN DEFINITIONS
// ============================================================================

const VALID_SPACING = [
  'gap-0', 'gap-1', 'gap-2', 'gap-3', 'gap-4', 'gap-5', 'gap-6', 'gap-8', 'gap-10', 'gap-12',
  'p-0', 'p-1', 'p-2', 'p-3', 'p-4', 'p-5', 'p-6', 'p-8', 'p-10', 'p-12',
  'px-0', 'px-1', 'px-2', 'px-3', 'px-4', 'px-5', 'px-6', 'px-8',
  'py-0', 'py-1', 'py-2', 'py-3', 'py-4', 'py-5', 'py-6', 'py-8',
  'm-0', 'm-1', 'm-2', 'm-3', 'm-4', 'm-5', 'm-6', 'm-8',
  'mx-auto', 'my-auto',
];

const VALID_DURATIONS = [
  'duration-0', 'duration-50', 'duration-75', 'duration-100', 'duration-150',
  'duration-200', 'duration-300', 'duration-500', 'duration-700', 'duration-1000',
];

const ZONE_DURATION_REQUIREMENTS: Record<string, { min: number; max: number }> = {
  critical: { min: 500, max: 1000 },
  standard: { min: 150, max: 300 },
  machinery: { min: 0, max: 150 },
  marketing: { min: 200, max: 500 },
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function extractClasses(value: string): string[] {
  return value.split(/\s+/).filter(Boolean);
}

function isMagicNumber(cls: string): boolean {
  // Detect arbitrary values like gap-[13px], p-[7px], duration-[350ms]
  return /\[.+\]/.test(cls);
}

function suggestToken(cls: string): string | null {
  // Extract the type and value
  const match = cls.match(/^(\w+)-\[(\d+)(px|ms|rem)?\]$/);
  if (!match) return null;
  
  const [, type, value, unit] = match;
  const numValue = parseInt(value, 10);
  
  if (type === 'gap' || type === 'p' || type === 'px' || type === 'py' || type === 'm') {
    // Map px to Tailwind spacing scale (4px = 1)
    const scale = Math.round(numValue / 4);
    return `${type}-${scale}`;
  }
  
  if (type === 'duration') {
    // Find closest valid duration
    const durations = [0, 50, 75, 100, 150, 200, 300, 500, 700, 1000];
    const closest = durations.reduce((prev, curr) => 
      Math.abs(curr - numValue) < Math.abs(prev - numValue) ? curr : prev
    );
    return `duration-${closest}`;
  }
  
  return null;
}

function getZoneFromPath(filename: string): string | null {
  if (/\/(checkout|payment|delete|transfer)\//.test(filename)) return 'critical';
  if (/\/(admin|dashboard)\//.test(filename)) return 'machinery';
  if (/\/(landing|promo|marketing)\//.test(filename)) return 'marketing';
  if (/\/(settings|profile)\//.test(filename)) return 'standard';
  return null;
}

function getDurationValue(cls: string): number | null {
  const match = cls.match(/^duration-(\d+)$/);
  return match ? parseInt(match[1], 10) : null;
}

// ============================================================================
// RULE: enforce-tokens
// ============================================================================

const enforceTokens: Rule.RuleModule = {
  meta: {
    type: 'suggestion',
    docs: {
      description: 'Enforce design tokens over magic numbers',
      category: 'Sigil',
      recommended: true,
    },
    fixable: 'code',
    messages: {
      magicNumber: 'Use token instead of magic number: {{ cls }}. Suggested: {{ suggestion }}',
      noSuggestion: 'Use token instead of magic number: {{ cls }}',
    },
    schema: [],
  },
  
  create(context) {
    return {
      JSXAttribute(node: any) {
        if (node.name.name !== 'className') return;
        if (!node.value || node.value.type !== 'Literal') return;
        
        const classes = extractClasses(String(node.value.value));
        
        for (const cls of classes) {
          if (isMagicNumber(cls)) {
            const suggestion = suggestToken(cls);
            
            context.report({
              node,
              messageId: suggestion ? 'magicNumber' : 'noSuggestion',
              data: { cls, suggestion: suggestion || '' },
              fix: suggestion ? (fixer) => {
                const newValue = node.value.value.replace(cls, suggestion);
                return fixer.replaceText(node.value, `"${newValue}"`);
              } : undefined,
            });
          }
        }
      },
    };
  },
};

// ============================================================================
// RULE: zone-compliance
// ============================================================================

const zoneCompliance: Rule.RuleModule = {
  meta: {
    type: 'suggestion',
    docs: {
      description: 'Enforce zone-appropriate timing tokens',
      category: 'Sigil',
      recommended: true,
    },
    messages: {
      zoneMismatch: 'duration-{{ actual }} violates {{ zone }} zone (expected {{ min }}-{{ max }}ms)',
    },
    schema: [],
  },
  
  create(context) {
    const zone = getZoneFromPath(context.getFilename());
    if (!zone) return {};
    
    const requirements = ZONE_DURATION_REQUIREMENTS[zone];
    if (!requirements) return {};
    
    return {
      JSXAttribute(node: any) {
        if (node.name.name !== 'className') return;
        if (!node.value || node.value.type !== 'Literal') return;
        
        const classes = extractClasses(String(node.value.value));
        
        for (const cls of classes) {
          const duration = getDurationValue(cls);
          if (duration === null) continue;
          
          if (duration < requirements.min || duration > requirements.max) {
            context.report({
              node,
              messageId: 'zoneMismatch',
              data: {
                actual: duration,
                zone,
                min: requirements.min,
                max: requirements.max,
              },
            });
          }
        }
      },
    };
  },
};

// ============================================================================
// RULE: no-deprecated
// ============================================================================

const noDeprecated: Rule.RuleModule = {
  meta: {
    type: 'problem',
    docs: {
      description: 'Prevent use of deprecated patterns',
      category: 'Sigil',
      recommended: true,
    },
    messages: {
      deprecated: '{{ name }} is deprecated: {{ reason }}. Use {{ replacement }} instead.',
    },
    schema: [],
  },
  
  create(context) {
    // This would normally read from a deprecation registry
    // For now, check JSDoc comments in imported files
    return {
      ImportDeclaration(node: any) {
        // Implementation would check imported module's JSDoc for @deprecated
        // Simplified version just warns on known deprecated patterns
        const source = node.source.value;
        
        if (source.includes('QuickDelete') || source.includes('Spinner')) {
          context.report({
            node,
            messageId: 'deprecated',
            data: {
              name: source,
              reason: 'See .graveyard for details',
              replacement: 'Gold primitive',
            },
          });
        }
      },
    };
  },
};

// ============================================================================
// RULE: no-draft-in-main
// ============================================================================

const noDraftInMain: Rule.RuleModule = {
  meta: {
    type: 'problem',
    docs: {
      description: 'Prevent Draft<T> types from merging to main',
      category: 'Sigil',
      recommended: true,
    },
    messages: {
      draft: 'Draft<T> must be resolved before merge. Type the component or delete it.',
    },
    schema: [],
  },
  
  create(context) {
    // Only enforce in CI
    if (!process.env.CI) return {};
    
    return {
      TSTypeReference(node: any) {
        if (node.typeName?.name === 'Draft') {
          context.report({
            node,
            messageId: 'draft',
          });
        }
      },
    };
  },
};

// ============================================================================
// RULE: input-physics
// ============================================================================

const inputPhysics: Rule.RuleModule = {
  meta: {
    type: 'suggestion',
    docs: {
      description: 'Enforce input physics for zones',
      category: 'Sigil',
      recommended: true,
    },
    messages: {
      keyboardRequired: 'Machinery zone requires keyboard navigation. Add tabIndex or onKeyDown.',
      focusRequired: 'Critical zone requires visible focus indicators.',
    },
    schema: [],
  },
  
  create(context) {
    const zone = getZoneFromPath(context.getFilename());
    if (!zone) return {};
    
    return {
      JSXOpeningElement(node: any) {
        const tagName = node.name.name;
        
        // Check interactive elements
        if (!['button', 'a', 'input', 'select', 'textarea'].includes(tagName)) {
          // Check for onClick on non-interactive elements
          const hasOnClick = node.attributes.some((attr: any) => 
            attr.name?.name === 'onClick'
          );
          
          if (hasOnClick && zone === 'machinery') {
            const hasTabIndex = node.attributes.some((attr: any) =>
              attr.name?.name === 'tabIndex'
            );
            const hasKeyHandler = node.attributes.some((attr: any) =>
              attr.name?.name === 'onKeyDown' || attr.name?.name === 'onKeyUp'
            );
            
            if (!hasTabIndex && !hasKeyHandler) {
              context.report({
                node,
                messageId: 'keyboardRequired',
              });
            }
          }
        }
      },
    };
  },
};

// ============================================================================
// PLUGIN EXPORT
// ============================================================================

export = {
  rules: {
    'enforce-tokens': enforceTokens,
    'zone-compliance': zoneCompliance,
    'no-deprecated': noDeprecated,
    'no-draft-in-main': noDraftInMain,
    'input-physics': inputPhysics,
  },
  configs: {
    recommended: {
      plugins: ['sigil'],
      rules: {
        'sigil/enforce-tokens': 'error',
        'sigil/zone-compliance': 'warn',
        'sigil/no-deprecated': 'error',
        'sigil/no-draft-in-main': 'error',
        'sigil/input-physics': 'warn',
      },
    },
  },
};
