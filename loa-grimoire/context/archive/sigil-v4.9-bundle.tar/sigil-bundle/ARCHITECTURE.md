# Sigil v4.9 Architectural Overview

## Executive Summary

Sigil is a design context framework that gives AI agents the information they need to make consistent design decisions. It captures product "taste" and provides guardrails during implementation without adding bureaucracy.

**Core Insight:** The best design system is invisible. It enforces through tokens and types, not custom components. It blocks merges, not renders.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              SIGIL v4.9                                     │
│                         "The Invisible Guardrail"                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐         │
│  │   SOUL LAYER    │    │  PHYSICS LAYER  │    │ GOVERNANCE LAYER│         │
│  │                 │    │                 │    │                 │         │
│  │ • soul.yaml     │    │ • useSigilMut.  │    │ • Draft<T>      │         │
│  │ • vocabulary    │    │ • Token linting │    │ • Taste Debt    │         │
│  │ • Anti-patterns │    │ • Zone system   │    │ • Graduation    │         │
│  │                 │    │ • Input physics │    │ • Mutiny Proto. │         │
│  └────────┬────────┘    └────────┬────────┘    └────────┬────────┘         │
│           │                      │                      │                   │
│           └──────────────────────┼──────────────────────┘                   │
│                                  │                                          │
│                                  ▼                                          │
│                    ┌─────────────────────────┐                              │
│                    │     AGENT INTERFACE     │                              │
│                    │                         │                              │
│                    │  8 Specialized Agents   │                              │
│                    │  via Slash Commands     │                              │
│                    └─────────────────────────┘                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Three-Layer Model

### Layer 1: Soul (The Why)

Captures **what the product should feel like**, not just look like.

| File | Purpose | Updated By |
|------|---------|------------|
| `soul.yaml` | Product feel, references, anti-patterns | `/envision` |
| `vocabulary.yaml` | Term → material mapping | `/codify` |
| `.graveyard/*.tsx` | Killed patterns with tombstones | `/garden` |

**Key Insight:** Soul is not documentation that rots. Soul is structured data that agents read.

### Layer 2: Physics (The How)

Controls **the complete interaction experience**: sync + visual + input.

| Component | Controls | Enforcement |
|-----------|----------|-------------|
| `useSigilMutation` | Sync strategy, animation, input state | Type system |
| Token classes | Spacing, timing, colors | ESLint |
| Zone system | Physics by context | Path + user state |

**Key Insight:** Physics is not just animation timing. Physics is whether the data waits for the server.

### Layer 3: Governance (The When)

Controls **how patterns graduate and evolve**.

| Mechanism | Purpose | Timing |
|-----------|---------|--------|
| `Draft<T>` | Exploration escape hatch | Blocked at merge |
| Taste Debt | Override tracking | PR comment |
| Graduation | Silver → Gold promotion | 14 days, 2 approvals |
| Mutiny Protocol | Rule evolution | 3 seniors in 1 week |

**Key Insight:** Governance happens at PR time, not in the editor. Flow is sacred.

---

## Zone System

Zones determine physics based on **what the user is doing**, not just where the file lives.

```yaml
# .sigilrc.yaml

zones:
  critical:
    paths: ["**/checkout/**", "**/payment/**", "**/delete/**"]
    sync: pessimistic      # Wait for server
    visual: 500-800ms      # Heavy, deliberate
    input: keyboard-first  # Focus management required
    
  standard:
    paths: ["**/settings/**", "**/profile/**"]
    sync: optimistic       # Instant local, background server
    visual: 150-200ms      # Snappy
    input: keyboard-first
    
  machinery:
    paths: ["**/admin/**", "**/dashboard/**"]
    sync: optimistic
    visual: 50-150ms       # Instant
    input: keyboard-required  # Arrow keys, no mouse-only
    
  marketing:
    paths: ["**/landing/**", "**/promo/**"]
    sync: optimistic
    visual: 200-400ms      # Playful
    input: mouse-ok        # Flexible

  # User segment overrides
  overrides:
    - when: { segment: "newcomer", zone: "critical" }
      visual: 1000ms       # Even more deliberate for novices
```

---

## Token System

Sigil enforces design through **tokens**, not custom components.

### Why Tokens, Not Components

| Custom Component | Token + Standard HTML |
|------------------|----------------------|
| `<CriticalZone>` | `className="duration-500"` |
| `<Layout.Row spacing="lg">` | `className="flex gap-6"` |
| Learn proprietary DSL | Standard CSS/Tailwind |
| Agents struggle | Agents excel |

### Valid Tokens

```yaml
spacing: [gap-1, gap-2, gap-4, gap-6, gap-8, p-1, p-2, p-4, p-6, p-8]
timing: [duration-50, duration-100, duration-150, duration-200, duration-300, duration-500, duration-700, duration-1000]
colors: [bg-red-50, bg-green-50, text-slate-900, ...]  # From Tailwind
```

### ESLint Enforcement

```javascript
// ✓ Valid
<div className="gap-4 p-6 duration-500">

// ✗ Magic number (lint error)
<div className="gap-[13px]">

// ✗ Zone violation (lint warning)
// In critical zone:
<button className="duration-100">  // Too fast for critical
```

---

## Transaction Objects

The core innovation: **hooks that control sync + visual + input together**.

```typescript
interface TransactionConfig {
  mutation: () => Promise<void>;
  physics: 'critical' | 'standard' | 'instant';
  
  // Optional escape hatch (tracked)
  unsafe_override_physics?: Partial<PhysicsConfig>;
  unsafe_override_reason?: string;  // Required if override used
}

function useSigilMutation(config: TransactionConfig) {
  // Physics determines ALL behavior
  const sync = PHYSICS_TO_SYNC[config.physics];       // pessimistic | optimistic
  const timing = PHYSICS_TO_TIMING[config.physics];   // duration, easing
  const input = PHYSICS_TO_INPUT[config.physics];     // keyboard props
  
  return {
    commit,              // The mutation function
    isPending,           // Loading state
    disabled,            // Input disabled during critical mutations
    style,               // CSS variables for timing
    ...keyboardProps,    // Keyboard handlers if needed
  };
}
```

---

## Graduation Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    GRADUATION PIPELINE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  EXPLORATION           PROBATION             STABLE             │
│  ───────────           ─────────             ──────             │
│                                                                 │
│  Draft<T>      ──►    SilverComponent<T>  ──►  GoldComponent<T> │
│                                                                 │
│  • Untyped             • Ship immediately      • Verified       │
│  • No lint             • 14 day monitor        • Stable API     │
│  • Blocked merge       • Auto-promote if OK    • Full trust     │
│                        • Veto-only review                       │
│                                                                 │
│  ────────────────────────────────────────────────────────────── │
│                                                                 │
│  APPLIES TO: src/primitives/ ONLY                               │
│  FEATURE CODE: Inherits validity from primitives used           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Friction Budget

Overrides are **allowed but expensive**.

### The Cost

```typescript
// To override Gold physics, you must:
useSigilMutation({
  mutation: fn,
  physics: 'critical',
  
  // 1. Use explicit escape hatch
  unsafe_override_physics: { duration: 200 },
  
  // 2. Provide reason (enforced by TypeScript)
  unsafe_override_reason: 'User research showed 800ms felt slow',
});
```

### The Tracking

Every override is logged to `sigil-mark/friction-log.json`:

```json
{
  "overrides": [
    {
      "file": "src/features/checkout/FastButton.tsx",
      "rule": "critical.duration",
      "expected": 500,
      "actual": 200,
      "reason": "User research showed 800ms felt slow",
      "author": "jane@company.com",
      "date": "2026-01-08"
    }
  ]
}
```

### The Mutiny Protocol

When too many overrides accumulate:

```
3 senior engineers override same rule in 1 week
                    ↓
        Mutiny Protocol triggers
                    ↓
     Gardener opens issue:
     "The rule 'critical.duration' is being rejected.
      Should we update the Gold standard?"
                    ↓
         Taste Owner decides
```

---

## Eight Specialized Agents

| Agent | Role | Command | Focus |
|-------|------|---------|-------|
| **Soul Director** | Design Director | `/envision` | Product feel, references |
| **Token Engineer** | Design Systems Eng | `/codify` | Token definitions |
| **Component Crafter** | Senior UI Engineer | `/craft` | Generate using Gold |
| **Taste Critic** | Design Reviewer | `/taste-review` | Review compliance |
| **Pattern Gardener** | Pattern Librarian | `/garden` | Graduation, drift |
| **Physics Auditor** | Performance Arch | `/audit-physics` | Sync + visual + input |
| **Taste Advocate** | Developer Relations | `/explain-taste` | Stakeholder comms |
| **UX Simulator** | UX Researcher | `/simulate-user` | Persona validation |

---

## Integration Points

### With ck (Semantic Search)

```bash
# Find Gold components by intent
ck --sem "@gold destructive" src/primitives/

# Find deprecated patterns
ck --sem "@deprecated delete" src/
```

### With ESLint

```javascript
// .eslintrc.js
{
  plugins: ['sigil'],
  rules: {
    'sigil/enforce-tokens': 'error',
    'sigil/zone-compliance': 'warn',
    'sigil/input-physics': 'warn',
    'sigil/no-deprecated': 'error',
    'sigil/no-draft-in-main': 'error',
  }
}
```

### With CI/CD

```yaml
# PR checks
- Taste Debt calculation
- Draft<T> detection
- Token violation count
- Zone compliance check

# Weekly cron
- Graduation candidates
- Mutiny detection
- Friction report
```

---

## File Structure

```
project/
├── CLAUDE.md                    # Agent instructions
├── .sigilrc.yaml                # Zone config, tokens
│
├── sigil-mark/                  # Soul layer
│   ├── soul.yaml                # Product feel
│   ├── vocabulary.yaml          # Term → material
│   └── friction-log.json        # Override tracking
│
├── src/
│   ├── primitives/              # Physics layer (status tracked)
│   │   ├── types.ts             # Gold/Silver/Draft types
│   │   ├── hooks/
│   │   │   └── useSigilMutation.ts
│   │   ├── Button.tsx           # GoldComponent
│   │   └── Input.tsx            # GoldComponent
│   │
│   └── features/                # Feature code (no status)
│       ├── checkout/
│       ├── settings/
│       └── marketing/
│
├── .claude/
│   ├── commands/                # Slash commands
│   └── skills/                  # Agent skills
│
└── .github/workflows/
    └── sigil.yml                # Governance automation
```

---

## Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Token compliance | >95% | `eslint-plugin-sigil` |
| Gold primitive usage | >80% | Import analysis |
| Draft<T> at merge | 0% | CI check |
| Average taste debt | <15 points | PR reports |
| Mutiny rate | <5% | Friction log |
| Graduation time | <14 days | Gardener tracking |

---

## The Promise

If you build with Sigil:

1. **Agents generate consistent UI** — They read soul.yaml and use Gold primitives
2. **Types catch mistakes** — GoldComponent<T> enforces at compile time
3. **Flow is preserved** — Friction surfaces at PR, not in editor
4. **Taste evolves** — Mutiny Protocol turns rebellion into evolution

**The system disappears. The soul remains.**
