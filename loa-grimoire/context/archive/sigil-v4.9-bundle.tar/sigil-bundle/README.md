# Sigil v4.9 — The Invisible Guardrail

> "The best system is one you forget is there. Rigorous outcome. Flexible input."

Sigil is a design context framework that gives AI agents the information they need to make consistent design decisions. It captures product "taste" and provides guardrails during implementation without blocking flow.

## Quick Start

```bash
# 1. Install
curl -fsSL https://raw.githubusercontent.com/[org]/sigil/main/install.sh | bash

# 2. Setup
cd your-project
sigil init

# 3. Capture soul
/envision

# 4. Define tokens
/codify

# 5. Start building
/craft "checkout button"
```

## Philosophy

### Three Laws

1. **Don't wrap the platform** — Use standard HTML/CSS/React. Enforce tokens, not components.
2. **Don't block the render** — Block the merge. Exploration is sacred.
3. **Physics is complete** — Sync strategy + visual timing + input mode. All three, always.

### The Invisible Guardrail

Sigil doesn't slow you down during coding. It:

- ✅ Lets you write standard HTML/CSS
- ✅ Provides Gold hooks that handle physics
- ✅ Reports Taste Debt at PR time (not in editor)
- ✅ Enforces through types (compile time, not runtime)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         SIGIL v4.9                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  SOUL LAYER          PHYSICS LAYER       GOVERNANCE LAYER       │
│  ───────────         ─────────────       ────────────────       │
│  soul.yaml           useSigilMutation    Draft<T>               │
│  vocabulary.yaml     Token linting       Taste Debt             │
│  Anti-patterns       Zone system         Graduation             │
│                      Input physics       Mutiny Protocol        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Eight Specialized Agents

| Agent | Command | Role | Focus |
|-------|---------|------|-------|
| **Soul Director** | `/envision` | Design Director | Capture product feel |
| **Token Engineer** | `/codify` | Design Systems Eng | Define constraints |
| **Component Crafter** | `/craft` | Senior UI Engineer | Generate using Gold |
| **Taste Critic** | `/taste-review` | Design Reviewer | Calculate debt |
| **Pattern Gardener** | `/garden` | Pattern Librarian | Graduation, drift |
| **Physics Auditor** | `/audit-physics` | Performance Arch | Sync + visual + input |
| **Taste Advocate** | `/explain-taste` | Developer Relations | Stakeholder comms |
| **UX Simulator** | `/simulate-user` | UX Researcher | Persona validation |

## Core Concepts

### Zones

Physics are determined by file path:

| Zone | Sync | Visual | Input | Paths |
|------|------|--------|-------|-------|
| `critical` | Pessimistic | 500-800ms | Keyboard-first | checkout, payment, delete |
| `standard` | Optimistic | 150-200ms | Keyboard-first | settings, profile |
| `machinery` | Optimistic | 50-150ms | Keyboard-required | admin, dashboard |
| `marketing` | Optimistic | 200-400ms | Mouse-ok | landing, promo |

### Transaction Objects

The core hook binds sync + visual + input:

```typescript
import { useSigilMutation } from '@/primitives';

// Critical: Pessimistic sync + 800ms + disabled during mutation
const transfer = useSigilMutation({
  mutation: () => api.transfer(amount),
  physics: 'critical',
});

<button {...transfer.props} onClick={() => transfer.commit()}>
  {transfer.isPending ? 'Processing...' : 'Transfer'}
</button>
```

### Token Enforcement

Standard HTML/CSS with token validation:

```typescript
// ✓ Valid tokens
<div className="gap-4 p-6 duration-500">

// ✗ Magic numbers (lint error)
<div className="gap-[13px] duration-[350ms]">
```

### Graduation Pipeline

```
Draft<T>  →  SilverComponent<T>  →  GoldComponent<T>
(explore)     (14 days)              (verified)
```

### Friction Budget

Override Gold physics (tracked):

```typescript
useSigilMutation({
  mutation: fn,
  physics: 'critical',
  unsafe_override_physics: { duration: 200 },
  unsafe_override_reason: 'User research showed 800ms felt slow',
});
```

## File Structure

```
project/
├── CLAUDE.md                    # Agent instructions
├── .sigilrc.yaml                # Zone config, tokens
│
├── sigil-mark/
│   ├── soul.yaml                # Product feel
│   ├── vocabulary.yaml          # Term → material
│   └── friction-log.json        # Override tracking
│
├── src/
│   ├── primitives/              # Gold/Silver (status tracked)
│   │   ├── types.ts
│   │   ├── hooks/
│   │   │   └── useSigilMutation.ts
│   │   └── Button.tsx
│   │
│   └── features/                # Feature code (no status)
│
└── .claude/
    ├── commands/                # Slash commands
    └── skills/                  # Agent skills
```

## Workflow

### New Project

```bash
/envision              # Capture soul through interview
/codify                # Generate .sigilrc.yaml
# Build features with /craft
```

### Existing Project

```bash
sigil init             # Create structure
/envision              # Interview for soul
/codify                # Define tokens/zones
/garden                # Check existing components
```

### Daily Development

```bash
/craft "feature"       # Generate component
# ... edit code ...
# PR triggers /taste-review automatically
```

### Weekly Maintenance

```bash
/garden                # Check graduations, mutiny
/audit-physics         # Verify physics alignment
```

## ESLint Integration

```javascript
// .eslintrc.js
module.exports = {
  plugins: ['sigil'],
  extends: ['plugin:sigil/recommended'],
};
```

Rules:
- `sigil/enforce-tokens` — No magic numbers
- `sigil/zone-compliance` — Zone-appropriate timing
- `sigil/no-deprecated` — Block deprecated imports
- `sigil/no-draft-in-main` — Block Draft<T> in CI
- `sigil/input-physics` — Keyboard support in machinery

## CI/CD Integration

```yaml
# .github/workflows/sigil.yml
name: Sigil
on: [pull_request]

jobs:
  taste-review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci
      - run: npx sigil taste-review
      - uses: actions/github-script@v6
        with:
          script: |
            // Post taste debt comment
```

## Migration Guide

### From No System

1. Run `sigil init`
2. Run `/envision` to capture existing taste
3. Run `/codify` to formalize
4. Add ESLint plugin
5. Wrap mutations with `useSigilMutation`

### From v4.8

```bash
# Remove layout primitives
rm -rf src/primitives/layout/

# Keep hooks and types
# Update to token enforcement
```

## Success Metrics

| Metric | Target |
|--------|--------|
| Token compliance | >95% |
| Gold primitive usage | >80% |
| Draft<T> at merge | 0% |
| Average taste debt | <15 pts |
| Mutiny rate | <5% |

## FAQ

### "Why can't I use custom timing?"

You can! Use `unsafe_override_physics` with a reason. It's tracked, not blocked.

### "Why is the linter complaining?"

Sigil prefers tokens over magic numbers. Use `gap-4` instead of `gap-[15px]`.

### "How do I add a new primitive?"

1. Create with `Draft<T>` type
2. Use in features for 14 days
3. Gardener will nominate for Gold
4. 2 maintainers approve

### "What if the rule is wrong?"

Override it! If 15% of usages override a rule, Mutiny Protocol triggers and we reconsider.

## License

MIT

---

Built for teams that care about craft.
