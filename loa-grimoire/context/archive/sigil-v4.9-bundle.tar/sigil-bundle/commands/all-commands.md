<!-- .claude/commands/envision.md -->
---
name: envision
description: Capture product soul through investigative interview
agent: sigil-envisioning
agent_path: .claude/skills/sigil-envisioning/SKILL.md
preflight:
  - sigil_mounted
---

# /envision

Capture what your product should **feel like** through guided interview.

**Output:** `sigil-mark/soul.yaml`

**Usage:**
```
/envision                    # Start fresh
/envision --update           # Update existing soul
/envision --section emotions # Update specific section
```

---
<!-- .claude/commands/codify.md -->
---
name: codify
description: Define tokens and zone constraints from soul
agent: sigil-codifying
agent_path: .claude/skills/sigil-codifying/SKILL.md
preflight:
  - sigil_mounted
  - soul_exists
---

# /codify

Transform soul into enforceable tokens and zones.

**Input:** `sigil-mark/soul.yaml`
**Output:** `.sigilrc.yaml`

**Usage:**
```
/codify                      # Generate from soul
/codify --zones              # Update zones only
/codify --tokens             # Update tokens only
```

---
<!-- .claude/commands/craft.md -->
---
name: craft
description: Generate UI components using Gold primitives
agent: sigil-crafting
agent_path: .claude/skills/sigil-crafting/SKILL.md
preflight:
  - sigil_mounted
  - sigilrc_exists
---

# /craft

Generate production UI using Gold primitives.

**Context:** Reads zone from file path, uses Gold hooks.

**Usage:**
```
/craft "delete button for checkout"
/craft "admin data table with keyboard nav"
/craft "marketing hero with playful animation"
```

---
<!-- .claude/commands/taste-review.md -->
---
name: taste-review
description: Review code for taste compliance and calculate debt
agent: sigil-reviewing
agent_path: .claude/skills/sigil-reviewing/SKILL.md
preflight:
  - sigil_mounted
---

# /taste-review

Calculate Taste Debt for code changes.

**Output:** PR comment with debt score and suggestions.

**Usage:**
```
/taste-review                # Review staged changes
/taste-review --pr 1234      # Review specific PR
/taste-review --file X.tsx   # Review specific file
```

---
<!-- .claude/commands/garden.md -->
---
name: garden
description: Maintain design system health (graduations, mutiny, drift)
agent: sigil-gardening
agent_path: .claude/skills/sigil-gardening/SKILL.md
preflight:
  - sigil_mounted
---

# /garden

Tend the design system. Check graduations, detect mutiny.

**Usage:**
```
/garden                      # Full health report
/garden graduation           # Check promotion candidates
/garden deprecation          # Check failing patterns
/garden mutiny               # Check rule rebellion
```

---
<!-- .claude/commands/audit-physics.md -->
---
name: audit-physics
description: Validate sync + visual + input physics alignment
agent: sigil-physics
agent_path: .claude/skills/sigil-physics/SKILL.md
preflight:
  - sigil_mounted
---

# /audit-physics

Verify physics completeness (sync + visual + input).

**Usage:**
```
/audit-physics               # Audit all mutations
/audit-physics --zone critical
/audit-physics --file X.tsx
```

---
<!-- .claude/commands/explain-taste.md -->
---
name: explain-taste
description: Explain design decisions to stakeholders
agent: sigil-explaining
agent_path: .claude/skills/sigil-explaining/SKILL.md
preflight:
  - sigil_mounted
---

# /explain-taste

Translate taste constraints for different audiences.

**Usage:**
```
/explain-taste "why 800ms for transfers?"
/explain-taste "business case for confirmation dialogs" --for executives
/explain-taste "how to override physics" --for engineers
```

---
<!-- .claude/commands/simulate-user.md -->
---
name: simulate-user
description: Walk through flows as different user personas
agent: sigil-simulating
agent_path: .claude/skills/sigil-simulating/SKILL.md
preflight:
  - sigil_mounted
---

# /simulate-user

Experience the UI as different personas.

**Usage:**
```
/simulate-user "checkout flow" --as newcomer
/simulate-user "delete account" --as anxious_user
/simulate-user "admin dashboard" --all-personas
```
