# CLAUDE.md — Sigil v4.9: The Invisible Guardrail

You are operating within **Sigil**, a design context framework that captures product "taste" and provides guardrails during implementation. Sigil ensures AI agents make consistent design decisions without over-engineering or bureaucracy.

## Core Philosophy

```
The best system is one you forget is there.
Rigorous outcome. Flexible input.
```

**Three Laws:**
1. **Don't wrap the platform** — Use standard HTML/CSS/React. Enforce tokens, not components.
2. **Don't block the render** — Block the merge. Exploration is sacred.
3. **Physics is complete** — Sync strategy + visual timing + input mode. All three, always.

---

## Zone System

Sigil uses **zones** to determine physics based on file path + user state:

| Zone | Sync | Visual | Input | Example Paths |
|------|------|--------|-------|---------------|
| `critical` | Pessimistic | 500-800ms | Keyboard-first | `**/checkout/**`, `**/payment/**`, `**/delete/**` |
| `standard` | Optimistic | 150-200ms | Keyboard-first | `**/settings/**`, `**/profile/**` |
| `machinery` | Optimistic | 50-150ms | Keyboard-required | `**/admin/**`, `**/dashboard/**` |
| `marketing` | Optimistic | 200-400ms | Mouse-ok | `**/landing/**`, `**/promo/**` |

**Resolution:** Check `.sigilrc.yaml` for zone definitions. Path is default; user segment can override.

---

## The Gold Primitives

When generating UI, **always use Gold primitives** from `src/primitives/`:

### Transaction Hook (Required for mutations)

```typescript
import { useSigilMutation } from '@/primitives';

// Critical: pessimistic sync + heavy animation + disabled during mutation
const transfer = useSigilMutation({
  mutation: () => api.transfer(amount),
  physics: 'critical',
});

// Standard: optimistic sync + snappy animation
const update = useSigilMutation({
  mutation: () => api.updateTitle(title),
  physics: 'standard',
});

// Usage
<button {...transfer} onClick={() => transfer.commit()}>
  {transfer.isPending ? 'Processing...' : 'Transfer'}
</button>
```

### Token Classes (Required for styling)

```typescript
// ✓ CORRECT: Use token classes
<div className="gap-4 p-6 duration-500">

// ✗ WRONG: Magic numbers
<div className="gap-[13px] p-[7px]" style={{ animationDuration: '350ms' }}>
```

**Valid tokens:** `gap-{1,2,4,6,8}`, `p-{1,2,4,6,8}`, `duration-{50,100,150,200,300,500,700,1000}`

---

## Component Status

Components have status **only in `src/primitives/`**:

| Status | Meaning | Usage |
|--------|---------|-------|
| `GoldComponent<T>` | Verified, stable | Use freely |
| `SilverComponent<T>` | Probationary (14 days) | Use with awareness |
| `Draft<T>` | Exploration mode | Must resolve before merge |
| `@deprecated` | Killed pattern | Do not use, see replacement |

**Feature code** (`src/features/**`) has NO status. It inherits validity from the primitives it uses.

---

## Agent Behavior Rules

### When Generating Components

1. **Check zone** from file path
2. **Use `useSigilMutation`** for any data mutation
3. **Use token classes** for spacing, timing, colors
4. **Check for Gold primitives** before creating new patterns
5. **If creating new pattern**, use `Draft<T>` type

### When Reviewing

1. **Check token usage** — flag magic numbers
2. **Check zone compliance** — critical needs pessimistic sync
3. **Check input physics** — machinery needs keyboard navigation
4. **Calculate taste debt** — report at PR level, not inline

### When Asked About Taste

1. **Read `sigil-mark/soul.yaml`** for product feel
2. **Read `sigil-mark/vocabulary.yaml`** for term meanings
3. **Check `.graveyard/` JSDoc** for killed patterns
4. **Explain with references** to the soul, not personal opinion

---

## File Locations

```
.sigilrc.yaml              # Zone definitions, token config
sigil-mark/
├── soul.yaml              # Product feel, references, anti-patterns
├── vocabulary.yaml        # Term → material mapping
└── friction-log.json      # Override tracking (auto-generated)

src/primitives/            # Gold/Silver primitives (status tracked)
├── types.ts               # GoldComponent<T>, SilverComponent<T>, Draft<T>
├── hooks/
│   └── useSigilMutation.ts
├── Button.tsx
└── Input.tsx

src/features/              # Feature code (no status, uses primitives)
```

---

## Commands

Sigil provides these slash commands:

| Command | Agent | Purpose |
|---------|-------|---------|
| `/envision` | Soul Director | Capture product feel through interview |
| `/codify` | Token Engineer | Define tokens and constraints |
| `/craft` | Component Crafter | Generate UI using Gold primitives |
| `/taste-review` | Taste Critic | Review code for taste compliance |
| `/garden` | Pattern Gardener | Check graduations, drift, mutiny |
| `/audit-physics` | Physics Auditor | Validate sync + visual + input |
| `/explain-taste` | Taste Advocate | Explain decisions to stakeholders |
| `/simulate-user` | UX Simulator | Validate against personas |

---

## Quick Reference

### Friction Budget

Overrides are **expensive** (require reason) and **tracked**:

```typescript
useSigilMutation({
  mutation: fn,
  physics: 'critical',
  // Escape hatch (tracked, requires reason)
  unsafe_override_physics: { duration: 200 },
  unsafe_override_reason: 'User research showed 800ms felt slow on mobile',
});
```

### Draft Escape Hatch

```typescript
// Valid during exploration, blocked at merge
const Experiment: Draft<React.FC> = () => <div>Playing...</div>;
```

### Deprecated Check

Always check for `@deprecated` in JSDoc before using a pattern:

```typescript
/**
 * @deprecated 2024-12 — Users accidentally deleted 3x more
 * @killed-by DestructiveButton
 */
export function QuickDeleteButton() { ... }  // DO NOT USE
```

---

## The Invisible Guardrail Promise

If you follow these rules, the system disappears:
- Standard HTML/CSS works
- Types catch mistakes at compile time
- Taste debt surfaces at PR time, not in your flow
- Gold primitives handle the physics

**You write code. Sigil ensures it has soul.**
