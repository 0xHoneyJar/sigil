---
name: seeding-sanctuary
description: Provide virtual taste context for new projects with empty Sanctuaries. Use when initializing Sigil, starting a new project, or when no components exist yet. Triggers on "sigil init", "new project", "empty sanctuary", "cold start".
---

# Seeding Sanctuary

Solve the "empty room" problem by providing virtual taste context until real components exist.

## Instructions

### When to Seed

Check if Sanctuary is empty:

```bash
find src/sanctuary -name "*.tsx" -o -name "*.ts" 2>/dev/null | head -1
```

If empty or non-existent, offer seed selection.

### Seed Selection

Ask the user:

```
Your Sanctuary is empty. Which vibe should I use as a starting point?

1. **Linear-like** — Minimal, keyboard-first, monochrome
2. **Vercel-like** — Bold, high-contrast, geometric  
3. **Stripe-like** — Soft gradients, generous spacing
4. **Blank** — No seed, pure inference from your code
```

### Load Seed

Based on selection, reference the appropriate seed file:

- Linear: `.sigil/seeds/linear-like.yaml`
- Vercel: `.sigil/seeds/vercel-like.yaml`
- Stripe: `.sigil/seeds/stripe-like.yaml`

Or create `.sigil/seed.yaml` with the selection.

### Virtual Components

Seeds provide virtual component definitions:

```yaml
virtual_components:
  Button:
    tier: gold
    physics: snappy
    timing: 150ms
    zones: [standard, critical]
  Card:
    tier: gold
    physics: smooth
    timing: 300ms
    zones: [standard]
```

Use these as if they exist in the Sanctuary.

### Fade Behavior

When a real component is created that matches a virtual one:

1. The real component takes precedence
2. The virtual component "fades"
3. Once all virtuals are replaced, seed can be deleted

### Tracking Fade

After generating a real component:

```markdown
Virtual Button → Real src/sanctuary/gold/Button.tsx
Status: Faded (real component now exists)
```

## Seed File Format

```yaml
seed: linear-like
version: 2026.01
description: Minimal, keyboard-first, monochrome

physics:
  snappy: 150ms ease-out
  smooth: 300ms cubic-bezier(0.4, 0, 0.2, 1)
  deliberate: 800ms cubic-bezier(0.4, 0, 0.2, 1)

materials:
  default:
    shadows: minimal
    borders: subtle
    radii: 6px

virtual_components:
  Button:
    tier: gold
    physics: snappy
    zones: [standard, critical]
  Card:
    tier: gold  
    physics: smooth
    zones: [standard]
  Input:
    tier: gold
    physics: snappy
    zones: [standard]
  Dialog:
    tier: gold
    physics: smooth
    zones: [standard, critical]
```
