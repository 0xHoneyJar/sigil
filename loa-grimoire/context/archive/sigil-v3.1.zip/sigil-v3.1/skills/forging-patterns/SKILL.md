---
name: forging-patterns
description: Break precedent and explore new patterns explicitly. Ignores survival history, respects only hard physics. Use when innovating, starting new era, or explicitly breaking from established patterns. Triggers on "/craft --forge" or "/forge".
context: fork
---

# Forging Patterns

Explicit mode for breaking precedent and exploring innovation.

## Core Principle

> Sometimes you need to break the pattern to find a better one.

Forge mode ignores survival precedent while still respecting physics laws.

## When to Use

- Introducing a new design direction
- Breaking from established patterns intentionally
- Exploring radical alternatives
- Starting a new era

## Trigger

```
/craft --forge "reimagine the claim flow"
```

Or:

```
/forge "radical new onboarding"
```

## What Gets Ignored

| Ignored | Why |
|---------|-----|
| Survival patterns | You're intentionally breaking them |
| Learned preferences | Fresh slate for exploration |
| Previous rejections | May want to revisit |
| Canonical status | Doesn't constrain innovation |

## What Still Applies

| Respected | Why |
|-----------|-----|
| Physics laws | API correctness still matters |
| Zone constraints | Critical actions still need weight |
| Fidelity ceiling | Hard limits still apply |
| Material constraints | Physical properties still hold |

## Forge Flow

```
/forge "radical new onboarding"
  ↓
Fork context (isolated)
  ↓
Load:
  - Physics constraints (from sigil.yaml)
  - Zone definitions
  - Material properties
  - Current framework APIs (from workshop)
  ↓
Ignore:
  - Survival patterns
  - Precedent history
  - "How we've always done it"
  ↓
Generate: Novel approach
  ↓
Return: Experimental code + rationale
  ↓
User decides:
  ├── Keep → Enters codebase, tracked for survival
  └── Discard → Never existed
```

## Era Transitions

Forge is especially useful when starting a new era:

```
/new-era "Tactile"
```

This:
1. Archives current patterns as "Era: v1-Flat"
2. Creates new era marker in rules.md
3. Deprioritizes old precedent
4. Forge mode becomes default for new patterns

### Era in rules.md

```markdown
## Era: v2-Tactile (started 2026-01-08)

Previous era (v1-Flat) patterns archived.
New patterns emphasize: depth, texture, physicality.

### Archived from v1-Flat
- Flat shadows
- Minimal borders
- Monochrome palette
```

## Output Format

Forge output includes explicit markers:

```tsx
/**
 * @sigil-forged 2026-01-08
 * @sigil-intent "radical onboarding reimagining"
 * @sigil-era v2-Tactile
 * 
 * This component was created in Forge mode.
 * It intentionally breaks from previous patterns.
 */
export function OnboardingFlow() {
  // ... novel implementation
}
```

## Rationale

When forging, explain the break:

```markdown
## Forge Rationale

### What was broken
- Previous onboarding used multi-step wizard
- Old pattern: linear progression

### What's new
- Single immersive canvas
- Non-linear exploration
- Physics: fluid, not stepped

### Why
User research showed wizard fatigue.
Exploring "playground" mental model.

### Risk
- Unfamiliar to existing users
- Accessibility needs verification
```

## Forked Context Benefits

Because forge runs in `context: fork`:

- Main conversation not polluted with exploration
- Can generate multiple alternatives
- Failed experiments don't clutter history
- Only final choice returns to main
