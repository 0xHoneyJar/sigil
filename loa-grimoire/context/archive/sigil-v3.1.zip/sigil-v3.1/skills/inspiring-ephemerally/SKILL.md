---
name: inspiring-ephemerally
description: One-time external fetch for design inspiration. Runs in forked context - fetched content is used then discarded, never pollutes main conversation. Triggers on "like stripe.com", "inspired by [url]", "similar to [url]".
context: fork
allowed-tools: Bash, Read, WebFetch
---

# Inspiring Ephemerally

Fetch external inspiration without polluting the Sanctuary.

## Core Principle

> Ephemeral = safe to explore. Use it, discard it.

Content fetched here exists only for the current generation. It never enters the Sanctuary unless explicitly sanctified.

## Instructions

### Detect Trigger

Patterns that trigger ephemeral fetch:

- "like stripe.com"
- "inspired by [url]"
- "similar to [url]"
- "in the style of [site]"

### Fetch and Extract

1. **Fetch the URL**
   ```bash
   # If Firecrawl available
   firecrawl scrape [url] --format markdown
   
   # Fallback
   curl -s [url] | pandoc -f html -t markdown
   ```

2. **Extract design patterns**
   - CSS custom properties
   - Animation curves (cubic-bezier, spring configs)
   - Spacing values
   - Color tokens
   - Typography scales
   - Shadow definitions

3. **Apply to current generation**
   - Use extracted patterns in the code
   - Reference them in comments if helpful

4. **Discard**
   - Fetched content is not saved
   - Patterns exist only in this generation
   - Main conversation never sees the fetch

### Forked Context

Because this skill has `context: fork`:

- Runs in isolated sub-agent
- Has its own conversation history
- Main context never polluted
- Only generated code returns to main

### Example Flow

```
User: /craft "signup form like linear.app/signup"

[Fork context]
  → Fetch linear.app/signup
  → Extract:
    - Spacing: 24px, 48px rhythm
    - Colors: #5E6AD2 primary
    - Animation: 200ms ease-out
    - Typography: Inter, 14px base
  → Generate signup form using patterns
[End fork]

← Return: Generated code only
```

### Sanctification

If user wants to keep patterns permanently:

```
/sanctify "linear spacing rhythm"
```

This extracts patterns from the ephemeral context and proposes additions to `rules.md`:

```markdown
## Spacing (sanctified from linear.app, 2026-01-08)
- rhythm: 24px base, 48px sections
- compact: 16px
- generous: 64px
```

Once sanctified, patterns become permanent in the Sanctuary.

### What Gets Extracted

| Pattern Type | Example | How Used |
|--------------|---------|----------|
| Spacing | `--spacing-4: 16px` | Applied to layout |
| Colors | `--primary: #5E6AD2` | Inform palette choices |
| Animation | `transition: 200ms ease-out` | Apply to motion |
| Typography | `font-size: 14px; line-height: 1.5` | Set text styles |
| Shadows | `box-shadow: 0 1px 2px rgba(0,0,0,0.05)` | Apply to surfaces |

### Limitations

- **Single page**: Does not follow links
- **Public only**: Cannot fetch authenticated pages
- **Static content**: May miss JS-rendered content
- **Rate limited**: Respect source server

### Error Handling

If fetch fails:

```
Could not fetch [url].
Proceeding with inference based on description.
```

Don't block generation. Infer from the description instead.
