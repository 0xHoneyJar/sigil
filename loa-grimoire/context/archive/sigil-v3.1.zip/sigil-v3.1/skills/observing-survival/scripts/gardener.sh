#!/bin/bash
# gardener.sh - Scan for pattern survival and update index
# Run weekly or on-demand: ./scripts/gardener.sh

set -e

SRC_DIR="${1:-src}"
OUTPUT_FILE="${2:-.sigil/survival.json}"
PROMOTION_THRESHOLD=3
SURVIVAL_DAYS=14

# Ensure output directory exists
mkdir -p "$(dirname "$OUTPUT_FILE")"

# Get current timestamp
NOW=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
TODAY=$(date -u +"%Y-%m-%d")

# Load existing index or create empty
if [ -f "$OUTPUT_FILE" ]; then
  EXISTING=$(cat "$OUTPUT_FILE")
else
  EXISTING='{"patterns":{},"last_scan":null}'
fi

# Find all pattern tags
echo "🌱 Scanning for patterns in $SRC_DIR..."

# Extract patterns and their locations
PATTERNS=$(rg "@sigil-pattern[: ]+([a-zA-Z0-9_]+)" "$SRC_DIR" -o --no-filename 2>/dev/null | \
  sed 's/@sigil-pattern[: ]*//' | \
  sort | uniq -c | \
  awk '{print $2 ":" $1}')

# Also extract dates if available
PATTERN_DATES=$(rg "@sigil-pattern[: ]+([a-zA-Z0-9_]+).*\(([0-9-]+)\)" "$SRC_DIR" -o --no-filename 2>/dev/null | \
  sed 's/@sigil-pattern[: ]*//;s/[()]//g' | \
  awk '{print $1 ":" $2}' || echo "")

# Build new patterns object
NEW_PATTERNS="{"
FIRST=true

# Track stats
PROMOTED=0
EXPERIMENTAL=0
REJECTED=0
TOTAL=0

for entry in $PATTERNS; do
  NAME=$(echo "$entry" | cut -d: -f1)
  COUNT=$(echo "$entry" | cut -d: -f2)
  
  # Get first seen date from existing or from tag or today
  FIRST_SEEN=$(echo "$EXISTING" | jq -r ".patterns[\"$NAME\"].first_seen // \"$TODAY\"")
  
  # Check for date in tag
  TAG_DATE=$(echo "$PATTERN_DATES" | grep "^$NAME:" | cut -d: -f2 | head -1)
  if [ -n "$TAG_DATE" ]; then
    # Use tag date if it's earlier
    if [[ "$TAG_DATE" < "$FIRST_SEEN" ]]; then
      FIRST_SEEN="$TAG_DATE"
    fi
  fi
  
  # Calculate age in days
  FIRST_SEEN_EPOCH=$(date -d "$FIRST_SEEN" +%s 2>/dev/null || date -j -f "%Y-%m-%d" "$FIRST_SEEN" +%s 2>/dev/null || echo "0")
  NOW_EPOCH=$(date +%s)
  AGE_DAYS=$(( (NOW_EPOCH - FIRST_SEEN_EPOCH) / 86400 ))
  
  # Determine status
  if [ "$COUNT" -ge "$PROMOTION_THRESHOLD" ]; then
    STATUS="canonical"
    ((PROMOTED++)) || true
  elif [ "$AGE_DAYS" -ge "$SURVIVAL_DAYS" ]; then
    STATUS="survived"
    ((EXPERIMENTAL++)) || true
  else
    STATUS="experimental"
    ((EXPERIMENTAL++)) || true
  fi
  
  # Get files containing this pattern
  FILES=$(rg "@sigil-pattern[: ]+$NAME" "$SRC_DIR" -l 2>/dev/null | jq -R -s -c 'split("\n") | map(select(. != ""))')
  
  # Add to JSON
  if [ "$FIRST" = true ]; then
    FIRST=false
  else
    NEW_PATTERNS+=","
  fi
  
  NEW_PATTERNS+="\"$NAME\":{\"first_seen\":\"$FIRST_SEEN\",\"occurrences\":$COUNT,\"status\":\"$STATUS\",\"files\":$FILES}"
  
  ((TOTAL++)) || true
done

# Check for rejections (patterns in old index but not found)
OLD_PATTERNS=$(echo "$EXISTING" | jq -r '.patterns | keys[]' 2>/dev/null || echo "")
for OLD_NAME in $OLD_PATTERNS; do
  # Check if it's in new patterns
  if ! echo "$PATTERNS" | grep -q "^$OLD_NAME:"; then
    # Pattern was deleted
    OLD_STATUS=$(echo "$EXISTING" | jq -r ".patterns[\"$OLD_NAME\"].status")
    if [ "$OLD_STATUS" != "rejected" ]; then
      # Newly rejected
      FIRST_SEEN=$(echo "$EXISTING" | jq -r ".patterns[\"$OLD_NAME\"].first_seen")
      
      if [ "$FIRST" = true ]; then
        FIRST=false
      else
        NEW_PATTERNS+=","
      fi
      
      NEW_PATTERNS+="\"$OLD_NAME\":{\"first_seen\":\"$FIRST_SEEN\",\"occurrences\":0,\"status\":\"rejected\",\"deleted_at\":\"$TODAY\",\"files\":[]}"
      
      ((REJECTED++)) || true
      ((TOTAL++)) || true
    fi
  fi
done

NEW_PATTERNS+="}"

# Build final JSON
FINAL_JSON=$(cat <<EOF
{
  "patterns": $NEW_PATTERNS,
  "last_scan": "$NOW",
  "stats": {
    "total": $TOTAL,
    "canonical": $PROMOTED,
    "experimental": $EXPERIMENTAL,
    "rejected": $REJECTED
  }
}
EOF
)

# Write output
echo "$FINAL_JSON" | jq '.' > "$OUTPUT_FILE"

# Print report
echo ""
echo "🌱 Gardener Report ($TODAY)"
echo "=========================="
echo ""

# Canonical
CANONICAL_LIST=$(echo "$FINAL_JSON" | jq -r '.patterns | to_entries | map(select(.value.status == "canonical")) | .[].key')
if [ -n "$CANONICAL_LIST" ]; then
  echo "📗 Canonical patterns:"
  for p in $CANONICAL_LIST; do
    COUNT=$(echo "$FINAL_JSON" | jq -r ".patterns[\"$p\"].occurrences")
    echo "   - $p ($COUNT occurrences)"
  done
  echo ""
fi

# Experimental
EXP_LIST=$(echo "$FINAL_JSON" | jq -r '.patterns | to_entries | map(select(.value.status == "experimental" or .value.status == "survived")) | .[].key')
if [ -n "$EXP_LIST" ]; then
  echo "🌱 Experimental patterns:"
  for p in $EXP_LIST; do
    STATUS=$(echo "$FINAL_JSON" | jq -r ".patterns[\"$p\"].status")
    echo "   - $p ($STATUS)"
  done
  echo ""
fi

# Rejected
REJ_LIST=$(echo "$FINAL_JSON" | jq -r '.patterns | to_entries | map(select(.value.status == "rejected")) | .[].key')
if [ -n "$REJ_LIST" ]; then
  echo "🗑️  Rejected patterns:"
  for p in $REJ_LIST; do
    echo "   - $p (deleted)"
  done
  echo ""
fi

echo "Total patterns tracked: $TOTAL"
echo "Output: $OUTPUT_FILE"
