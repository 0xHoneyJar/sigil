---
name: observing-survival
description: Silently track pattern adoption through code existence. No approval dialogs - survival is the only vote. Tags new patterns, runs gardener to check survival. PostToolUse hook.
hooks:
  PostToolUse:
    - matcher: "Write|Edit|MultiEdit"
      hooks:
        - type: command
          command: "echo 'Pattern observation active'"
---

# Observing Survival

Track pattern adoption silently. Code existence IS precedent.

## Core Principle

> Survival is the only vote that counts.

Don't ask for approval. Don't flag "phantoms". Generate the code, tag it, and let survival determine canonicity.

## The Rule

```
Approved    = exists in src/
Rejected    = doesn't exist in src/
Canonical   = exists 3+ times
Experimental = exists 1 time, < 2 weeks old
```

## Silent Tagging

After generating code with new patterns, add observation tags:

```tsx
// @sigil-pattern: useClaimAnimation (2026-01-08)
const animation = useClaimAnimation();
```

Or in JSDoc:

```tsx
/**
 * @sigil-pattern useClaimAnimation
 * @sigil-observed 2026-01-08
 */
```

## No Interruption

**Wrong (v3 approach):**
```
Agent: "This is a Phantom pattern. Approve?"
User: [context switch, flow broken]
```

**Right (v3.1 approach):**
```
Agent: [generates code with silent tag]
User: [keeps flowing]
[Later] Gardener: "useClaimAnimation survived 2 weeks, promoting"
```

## The Gardener

Weekly background process that scans for survival:

```bash
./scripts/gardener.sh
```

### What Gardener Does

1. **Scan for pattern tags**
   ```bash
   rg "@sigil-pattern" src/ --json
   ```

2. **Count occurrences**
   ```bash
   rg "@sigil-pattern: useClaimAnimation" src/ --count
   ```

3. **Check age**
   - First seen date from tag
   - Current date
   - Age = difference

4. **Update survival index**
   ```json
   {
     "useClaimAnimation": {
       "first_seen": "2026-01-08",
       "occurrences": 3,
       "status": "canonical"
     }
   }
   ```

5. **Detect deletions**
   - Pattern in index but 0 occurrences
   - Mark as "rejected"
   - Record deletion date

### Promotion Rules

| Condition | Status |
|-----------|--------|
| 1 occurrence, < 2 weeks | experimental |
| 1 occurrence, >= 2 weeks | survived |
| 3+ occurrences | canonical |
| 0 occurrences (was > 0) | rejected |

### Gardener Output

```
🌱 Gardener Report (2026-01-08)

Promoted to canonical:
  - useClaimAnimation (3 occurrences)
  - ClaimConfirmation (5 occurrences)

Still experimental:
  - useVaultPreview (1 occurrence, 5 days)

Rejected (deleted):
  - bouncySpring (was 2, now 0)

Total patterns tracked: 24
```

## Survival Index

`.sigil/survival.json` (auto-generated):

```json
{
  "patterns": {
    "useClaimAnimation": {
      "first_seen": "2026-01-08",
      "occurrences": 3,
      "status": "canonical",
      "files": [
        "src/hooks/useClaimAnimation.ts",
        "src/components/ClaimButton.tsx",
        "src/pages/Claim.tsx"
      ]
    },
    "bouncySpring": {
      "first_seen": "2026-01-05",
      "occurrences": 0,
      "status": "rejected",
      "deleted_at": "2026-01-07"
    }
  },
  "last_scan": "2026-01-08T10:00:00Z"
}
```

## How Agent Uses Survival

During `/craft`:

1. Query survival index for context patterns
2. Prefer canonical patterns over experimental
3. Avoid rejected patterns (unless forge mode)
4. No blocking, just preference weighting

```
Generating claim button...
  - Found canonical: useClaimAnimation (prefer)
  - Found rejected: bouncySpring (avoid)
  - Generating with useClaimAnimation
```

## Git Integration (Optional)

For more accurate deletion tracking:

```bash
# Check if pattern was in previous commit
git show HEAD~1:src/ | rg "@sigil-pattern: bouncySpring"
```

This confirms intentional deletion vs. refactor.
