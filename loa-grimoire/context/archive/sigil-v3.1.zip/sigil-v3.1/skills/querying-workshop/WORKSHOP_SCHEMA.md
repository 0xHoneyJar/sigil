# Workshop Schema

The workshop index at `.sigil/workshop.json` provides fast lookups for framework APIs and component signatures.

## Full Schema

```typescript
interface Workshop {
  // Metadata
  indexed_at: string;        // ISO timestamp
  package_hash: string;      // Hash of package.json for staleness check
  imports_hash: string;      // Hash of .sigil/imports.yaml
  
  // Framework materials
  materials: {
    [packageName: string]: MaterialEntry;
  };
  
  // Sanctuary components
  components: {
    [componentName: string]: ComponentEntry;
  };
  
  // Physics definitions (from sigil.yaml)
  physics: {
    [name: string]: PhysicsDefinition;
  };
  
  // Zone definitions (from sigil.yaml)
  zones: {
    [name: string]: ZoneDefinition;
  };
}

interface MaterialEntry {
  version: string;
  exports: string[];           // Top-level exports
  types_available: boolean;    // Has .d.ts files
  readme_available: boolean;   // Has README.md
  docs_cached: boolean;        // Has cached docs in .sigil/knowledge/
  
  // Optional: extracted type signatures for key exports
  signatures?: {
    [exportName: string]: string;  // e.g., "motion: React.FC<MotionProps>"
  };
}

interface ComponentEntry {
  path: string;                // Relative path to component file
  tier: "gold" | "silver" | "bronze";
  zone?: string;               // Default zone
  physics?: string;            // Default physics
  vocabulary?: string[];       // Associated vocabulary terms
  imports: string[];           // Frameworks this component uses
}

interface PhysicsDefinition {
  timing: string;              // e.g., "800ms"
  easing: string;              // e.g., "cubic-bezier(0.4, 0, 0.2, 1)"
  description: string;
}

interface ZoneDefinition {
  physics: string;             // Default physics for this zone
  timing: string;
  description: string;
}
```

## Example

```json
{
  "indexed_at": "2026-01-08T14:30:00Z",
  "package_hash": "a1b2c3d4e5f6...",
  "imports_hash": "f6e5d4c3b2a1...",
  
  "materials": {
    "framer-motion": {
      "version": "11.0.0",
      "exports": [
        "motion",
        "AnimatePresence", 
        "useAnimation",
        "useMotionValue",
        "useTransform",
        "useSpring"
      ],
      "types_available": true,
      "readme_available": true,
      "docs_cached": false,
      "signatures": {
        "motion": "MotionComponent",
        "AnimatePresence": "React.FC<AnimatePresenceProps>",
        "useSpring": "(value: number, config?: SpringOptions) => MotionValue<number>"
      }
    },
    "@radix-ui/react-dialog": {
      "version": "1.1.0",
      "exports": ["Root", "Trigger", "Portal", "Overlay", "Content", "Title", "Description", "Close"],
      "types_available": true,
      "readme_available": false,
      "docs_cached": true
    }
  },
  
  "components": {
    "ClaimButton": {
      "path": "src/sanctuary/gold/ClaimButton.tsx",
      "tier": "gold",
      "zone": "critical",
      "physics": "deliberate",
      "vocabulary": ["claim", "withdraw"],
      "imports": ["framer-motion", "@radix-ui/react-dialog"]
    },
    "Card": {
      "path": "src/sanctuary/gold/Card.tsx",
      "tier": "gold",
      "zone": "standard",
      "physics": "smooth",
      "vocabulary": ["card", "container"],
      "imports": ["framer-motion"]
    }
  },
  
  "physics": {
    "snappy": {
      "timing": "150ms",
      "easing": "ease-out",
      "description": "Quick, responsive feedback"
    },
    "smooth": {
      "timing": "300ms",
      "easing": "cubic-bezier(0.4, 0, 0.2, 1)",
      "description": "Comfortable, standard motion"
    },
    "deliberate": {
      "timing": "800ms",
      "easing": "cubic-bezier(0.4, 0, 0.2, 1)",
      "description": "Intentional, weighty actions"
    }
  },
  
  "zones": {
    "critical": {
      "physics": "deliberate",
      "timing": "800ms",
      "description": "Irreversible actions"
    },
    "standard": {
      "physics": "smooth",
      "timing": "300ms",
      "description": "Normal interactions"
    },
    "marketing": {
      "physics": "expressive",
      "timing": "variable",
      "description": "Promotional content"
    }
  }
}
```

## Building the Workshop

The workshop is built by the Startup Sentinel:

```bash
#!/bin/bash
# build-workshop.sh

# 1. Read imports
IMPORTS=$(cat .sigil/imports.yaml | yq '.imports[]')

# 2. For each import, extract info
for pkg in $IMPORTS; do
  VERSION=$(jq -r '.version' "node_modules/$pkg/package.json")
  # ... extract types, exports, etc.
done

# 3. Scan Sanctuary
rg "@sigil-tier" src/sanctuary/ -l | while read -r file; do
  # Extract component metadata
done

# 4. Merge with sigil.yaml physics/zones
# 5. Write to .sigil/workshop.json
```

## Staleness Check

Compare hashes to detect when rebuild is needed:

```bash
# Current package.json hash
CURRENT_HASH=$(md5sum package.json | cut -d' ' -f1)

# Stored hash
STORED_HASH=$(jq -r '.package_hash' .sigil/workshop.json)

if [ "$CURRENT_HASH" != "$STORED_HASH" ]; then
  echo "Workshop stale, rebuilding..."
fi
```
