---
name: querying-workshop
description: Fast lookups of framework APIs and component signatures from pre-computed index. Use when needing framework knowledge, checking APIs, or verifying component props. Provides 5ms lookups instead of 200ms grep.
allowed-tools: Read, Bash
---

# Querying Workshop

Query the pre-computed workshop index for instant framework and component lookups.

## Instructions

### Read the Index

The workshop index lives at `.sigil/workshop.json`:

```bash
cat .sigil/workshop.json
```

### Index Structure

See [WORKSHOP_SCHEMA.md](WORKSHOP_SCHEMA.md) for full schema.

Quick reference:

```json
{
  "indexed_at": "2026-01-08T14:30:00Z",
  "package_hash": "a1b2c3...",
  "materials": {
    "framer-motion": {
      "version": "11.0.0",
      "exports": ["motion", "AnimatePresence", "useAnimation"],
      "types_available": true
    }
  },
  "components": {
    "ClaimButton": {
      "path": "src/sanctuary/gold/ClaimButton.tsx",
      "tier": "gold",
      "zone": "critical"
    }
  }
}
```

### Query Patterns

**Check if framework is indexed:**
```bash
jq '.materials["framer-motion"]' .sigil/workshop.json
```

**Get component info:**
```bash
jq '.components["ClaimButton"]' .sigil/workshop.json
```

**List all Gold components:**
```bash
jq '.components | to_entries | map(select(.value.tier == "gold")) | from_entries' .sigil/workshop.json
```

**Get framework exports:**
```bash
jq '.materials["framer-motion"].exports' .sigil/workshop.json
```

### When Index is Stale

If `package_hash` doesn't match current `package.json`:

1. Trigger Graphing Imports to rescan
2. Rebuild workshop index
3. Continue with updated data

### Fallback to Types

If workshop doesn't have enough detail:

```bash
# Get types directly from node_modules
cat node_modules/framer-motion/dist/index.d.ts | head -100
```

This is slower but always authoritative.

### Performance Target

- Workshop query: <5ms
- Direct type read: <50ms
- Full grep: ~200ms (avoid during craft)

### Building the Index

The workshop is built by:

1. Reading `.sigil/imports.yaml` (from Graphing Imports)
2. For each import, extracting:
   - Version from node_modules/pkg/package.json
   - Exports from .d.ts files
   - README availability
3. Scanning Sanctuary for components
4. Writing to `.sigil/workshop.json`

See the Startup Sentinel in hooks for automatic rebuilding.
