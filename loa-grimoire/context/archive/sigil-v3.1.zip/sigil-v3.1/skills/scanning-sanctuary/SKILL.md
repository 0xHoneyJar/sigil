---
name: scanning-sanctuary
description: Find components in the design system Sanctuary. Use when looking for existing components, searching for patterns, or checking what's available in the codebase. Triggers on "find component", "what components", "search for", "do we have".
allowed-tools: Grep, Glob, Read
---

# Scanning Sanctuary

Find components in the Sanctuary (design system) using fast filesystem searches.

## Instructions

When searching for components:

1. **Check the Sanctuary first**
   ```bash
   rg "@sigil-tier (gold|silver)" src/sanctuary/ -l
   ```

2. **Search by vocabulary term**
   ```bash
   rg "@sigil-vocabulary claim" src/ -l
   ```

3. **Search by zone**
   ```bash
   rg "@sigil-zone critical" src/ -l
   ```

4. **Search by physics**
   ```bash
   rg "@sigil-physics deliberate" src/ -l
   ```

## Component Annotation Format

Sanctuary components should have JSDoc annotations:

```tsx
/**
 * @sigil-tier gold
 * @sigil-zone critical
 * @sigil-physics deliberate
 * @sigil-vocabulary claim, withdraw
 */
export function ClaimButton() { ... }
```

## Tier Priority

When multiple components match:

| Tier | Priority | Meaning |
|------|----------|---------|
| Gold | Highest | Verified, production-ready |
| Silver | Medium | Tested, standard use |
| Bronze | Lower | Experimental, limited use |

Always prefer higher-tier components.

## Output Format

Report findings as:

```
Found: ClaimButton (Gold)
  Path: src/sanctuary/gold/ClaimButton.tsx
  Zone: critical
  Physics: deliberate
  Vocabulary: claim, withdraw
```

## If Nothing Found

1. Check if Sanctuary is empty → Suggest Seeding Sanctuary
2. Check broader src/ directory
3. Report gap → May need to create new component
