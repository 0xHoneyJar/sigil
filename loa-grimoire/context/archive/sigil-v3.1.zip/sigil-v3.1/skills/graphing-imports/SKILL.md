---
name: graphing-imports
description: Map actual dependencies by scanning src/ for import statements. Use when checking what frameworks are used, before indexing, or when workshop needs updating. Only index what's actually imported, not all of node_modules.
allowed-tools: Bash, Read
---

# Graphing Imports

Determine which dependencies actually matter by scanning what src/ imports.

## Instructions

### Core Principle

> Only index what's imported. Ignore transitive dependencies.

node_modules contains hundreds of packages. Most are transitive. Only index packages directly imported in src/.

### Run the Scanner

Execute the bundled script:

```bash
./scripts/scan-imports.sh
```

Or manually:

```bash
# ES imports
rg "from ['\"]([^'\"./][^'\"]*)['\"]" src/ -o --no-filename | \
  sed "s/from ['\"]//;s/['\"]$//" | \
  cut -d'/' -f1-2 | \
  sort -u

# CommonJS requires  
rg "require\(['\"]([^'\"./][^'\"]*)['\"]" src/ -o --no-filename | \
  sed "s/require(['\"]//;s/['\"]\)$//" | \
  cut -d'/' -f1-2 | \
  sort -u
```

### Output Format

Write to `.sigil/imports.yaml`:

```yaml
scanned_at: 2026-01-08T14:30:00Z
source_hash: a1b2c3...  # Hash of src/ for change detection
imports:
  - framer-motion
  - "@radix-ui/react-dialog"
  - "@radix-ui/react-popover"
  - react-hook-form
  - zod
```

### Scoped Packages

Handle @org/package format:

```
@radix-ui/react-dialog → @radix-ui/react-dialog (keep full name)
framer-motion → framer-motion
lodash/merge → lodash (root package only)
```

### Integration with Workshop

After scanning imports:

1. Compare with current `workshop.json`
2. For new imports: queue type extraction
3. For removed imports: prune from workshop
4. Update `workshop.json` with changes

### When to Run

- Startup Sentinel detects package.json change
- User explicitly requests dependency scan
- Before `/craft` if imports.yaml is stale

### Performance

Target: <500ms for typical project

Optimize by:
- Only scan .ts, .tsx, .js, .jsx files
- Skip node_modules, dist, build directories
- Cache results until src/ changes
