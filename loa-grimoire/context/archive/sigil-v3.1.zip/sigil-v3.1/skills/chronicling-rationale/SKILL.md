---
name: chronicling-rationale
description: Generate lightweight craft logs for audit trail and Loa integration. Runs at end of craft via Stop hook. No blocking approval - just documentation.
hooks:
  Stop:
    - matcher: ".*"
      hooks:
        - type: command
          command: "echo 'Craft log check'"
          once: true
---

# Chronicling Rationale

Generate lightweight craft logs for audit trail.

## Core Principle

> Document decisions, don't gate them.

The craft log is for understanding, not approval. It captures why decisions were made so future maintainers (human or agent) can understand context.

## When Generated

At the end of every `/craft` command that produces code.

## Log Structure

```markdown
# Craft: [component-name] ([date])

## Request
"[original user prompt]"

## Decisions

### Context Resolution
- Zone: [zone] ([why])
- Physics: [physics] ([why])
- Material: [material] (if applicable)

### Component Selection
- Selected: [component] ([tier])
- Path: [file path]
- Why: [reasoning]

### Framework Usage
- [framework]: v[version]
- APIs used: [list]
- Source: [workshop/types/docs]

## New Patterns
- [pattern]: [experimental/forged] (if any)

## Physics Checks
- ✓ Zone constraint passed
- ✓ Material constraint passed
- ✓ API correctness verified

## Notes
[Any additional context]
```

## Example Log

```markdown
# Craft: claim-button (2026-01-08)

## Request
"trustworthy claim button"

## Decisions

### Context Resolution
- Zone: critical (vocabulary "claim" maps to critical)
- Physics: deliberate (critical zone requires weighted motion)
- Material: clay (inherited from design system)

### Component Selection
- Selected: ClaimButton (Gold)
- Path: src/sanctuary/gold/ClaimButton.tsx
- Why: Exact match for "claim" vocabulary, highest tier

### Framework Usage
- framer-motion: v11.0.0
- APIs used: motion.button, AnimatePresence
- Source: workshop index + node_modules types

## New Patterns
None (all patterns canonical)

## Physics Checks
- ✓ Zone: critical → deliberate physics (800ms)
- ✓ Material: clay → soft shadows, 200ms+ transitions
- ✓ API: motion.button exists in framer-motion

## Notes
Used existing ClaimButton Gold component.
No modifications needed for "trustworthy" feel -
deliberate physics already conveys weight and consideration.
```

## Storage

Logs are stored in `.sigil/craft-log/`:

```
.sigil/craft-log/
├── 2026-01-08-claim-button.md
├── 2026-01-08-signup-form.md
└── 2026-01-07-dashboard-card.md
```

Filename format: `[date]-[component-slug].md`

## Loa Integration

When Sigil runs as a Loa construct:

1. Craft log attached to Loa task
2. Provides audit trail for design decisions
3. Helps future agents understand context

```yaml
# Returned to Loa
artifacts:
  - type: craft-log
    path: .sigil/craft-log/2026-01-08-claim-button.md
```

## Lightweight

Keep logs concise:

- No code snippets (code is in the repo)
- No approval checklists
- No blocking prompts
- Just decisions and reasoning

## Retention

By default, keep last 30 days of logs.

To clean old logs:

```bash
find .sigil/craft-log -mtime +30 -delete
```

Or configure in sigil.yaml:

```yaml
craft_log:
  retention_days: 30
  auto_clean: true
```
