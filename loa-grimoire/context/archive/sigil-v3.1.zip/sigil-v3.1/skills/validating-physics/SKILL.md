---
name: validating-physics
description: Validate constraints before generation. Checks zone rules, material constraints, and API correctness. Does NOT flag novelty - only physics violations. Runs as PreToolUse hook.
hooks:
  PreToolUse:
    - matcher: "Write|Edit|MultiEdit"
      hooks:
        - type: command
          command: "echo 'Physics validation active'"
---

# Validating Physics

Check constraints before generation. Block violations, not novelty.

## Core Principle

> Flag physics violations, not pattern novelty.

Innovation is the job. New patterns are expected. Only block when hard constraints are violated.

## What Gets Validated

| Check | Example | Action |
|-------|---------|--------|
| API correctness | `motion.div` exists in framer-motion? | Block if invalid |
| Zone constraints | Critical zone using playful physics? | Block |
| Material constraints | Clay button with 0ms transition? | Block |
| Fidelity ceiling | 3D transform in standard component? | Block |

## What Does NOT Get Validated

| Non-Check | Why |
|-----------|-----|
| Pattern existence | New patterns are the job |
| Style novelty | Experimentation encouraged |
| Component precedent | Survival decides, not pre-approval |

## Validation Rules

### Zone Constraints

From `sigil.yaml`:

```yaml
zones:
  critical:
    physics: deliberate
    forbidden:
      - bounce
      - playful
    required:
      - min_timing: 500ms
```

**Check:**
```
Zone: critical
Proposed physics: spring({ stiffness: 500, damping: 10 })  # Bouncy
Result: BLOCK - "Critical zone forbids bounce animations"
```

### Material Constraints

From `sigil.yaml`:

```yaml
materials:
  clay:
    min_timing: 200ms
    max_timing: 1000ms
    shadows: soft
    forbidden:
      - sharp_shadows
      - instant_transitions
```

**Check:**
```
Material: clay
Proposed: transition: 50ms
Result: BLOCK - "Clay material requires 200ms+ transitions"
```

### API Correctness

From workshop index:

```
Framework: framer-motion@11.0.0
Proposed: motion.animate({ x: 100 })
Check: Does 'animate' exist on motion?
Result: Workshop says 'motion' has methods: [div, span, etc.]
        'animate' is not a method on motion
        BLOCK - "motion.animate is not valid. Did you mean useAnimation?"
```

### Fidelity Ceiling

From `rules.md`:

```markdown
## Fidelity Ceiling
- No 3D transforms in standard components
- No WebGL in critical zone
- Max shadow blur: 24px
```

**Check:**
```
Component: StandardCard
Proposed: transform: rotateY(15deg)
Result: BLOCK - "3D transforms forbidden in standard components"
```

## Validation Flow

```
Agent proposes code
  ↓
PreToolUse hook fires
  ↓
Extract:
  - Zone context
  - Material context
  - Framework calls
  - CSS properties
  ↓
Check against:
  - sigil.yaml constraints
  - rules.md fidelity ceiling
  - workshop.json API exports
  ↓
Violations found?
  ├── Yes → BLOCK with explanation
  └── No → ALLOW (proceed with generation)
```

## Error Messages

Provide actionable feedback:

```
❌ PHYSICS VIOLATION

Zone: critical
Constraint: No bounce animations in critical zone
Proposed: spring({ stiffness: 500, damping: 10 })

Suggestion: Use deliberate physics instead:
  spring({ stiffness: 100, damping: 20 })
  
Or change zone context if this is intentional.
```

## Override

If user explicitly wants to break physics:

```
/craft --force "bouncy claim button"
```

The `--force` flag bypasses physics validation. Use sparingly.

## Integration

This skill runs automatically via the PreToolUse hook before any file write operations. No explicit invocation needed.
