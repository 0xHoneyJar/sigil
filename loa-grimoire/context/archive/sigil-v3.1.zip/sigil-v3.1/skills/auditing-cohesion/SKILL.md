---
name: auditing-cohesion
description: Check visual consistency of generated components against surrounding context. Compares shadows, borders, colors, spacing against Sanctuary patterns. Use when reviewing components, checking consistency, or before merging.
allowed-tools: Read, Grep, Glob
---

# Auditing Cohesion

Verify visual consistency against the design system.

## Core Principle

> Cohesion is conformity to context, not to rules.

Check if the component looks like it belongs with its neighbors, not if it matches an abstract ideal.

## When to Audit

- After `/craft` completes (optional)
- Before merging PRs
- When reviewing component changes
- On-demand: `/audit [component]`

## What Gets Checked

| Property | Comparison |
|----------|------------|
| Shadows | Match Sanctuary shadow tokens |
| Borders | Match border width/style/color |
| Colors | Within palette or justified deviation |
| Spacing | Matches rhythm (4px, 8px, 16px, etc.) |
| Typography | Uses defined scale |
| Radii | Matches corner radius tokens |
| Transitions | Matches physics timings |

## Audit Process

### 1. Gather Context

```bash
# Find components in same zone
rg "@sigil-zone critical" src/sanctuary/ -l
```

### 2. Extract Properties

From the new component:
```bash
rg "shadow|border|color|spacing|padding|margin|radius|transition" [file]
```

From Sanctuary reference:
```bash
rg "shadow|border|color" src/sanctuary/gold/*.tsx
```

### 3. Compare

```
New Component           Sanctuary Average
--------------          -----------------
shadow: 0 2px 4px       shadow: 0 1px 2px
border: 1px solid       border: 1px solid ✓
radius: 8px             radius: 6px
transition: 200ms       transition: 300ms
```

### 4. Report Variance

```markdown
## Cohesion Audit: ClaimButton

### ✓ Consistent
- Border: 1px solid (matches)
- Colors: within palette

### ⚠️ Variance Detected
- Shadow: 0 2px 4px (Sanctuary uses 0 1px 2px)
  Deviation: +100% blur, +100% offset
  
- Radius: 8px (Sanctuary uses 6px)
  Deviation: +33%
  
- Transition: 200ms (Zone expects 800ms)
  Deviation: -75% (may violate physics)

### Recommendation
- Shadow/radius variance is minor (stylistic)
- Transition variance may violate critical zone physics
```

## Variance Thresholds

| Property | Acceptable Variance | Flag Threshold |
|----------|---------------------|----------------|
| Shadow blur | ±50% | >50% |
| Shadow offset | ±2px | >2px |
| Border width | exact | any deviation |
| Radius | ±2px | >2px |
| Timing | ±100ms | >100ms in critical |
| Spacing | exact rhythm | off-rhythm |

## Justifiable Deviation

Some variance is intentional. If variance is detected but justified:

```tsx
/**
 * @sigil-deviation shadow
 * @sigil-reason Elevated emphasis for primary CTA
 */
```

Auditor will note but not flag these.

## Integration with Craft

After generation, optionally run audit:

```
/craft "claim button"
[generates code]

Run cohesion audit? (y/n/always/never)
```

Or configure in sigil.yaml:

```yaml
cohesion:
  auto_audit: true  # Always audit after craft
  fail_on_variance: false  # Report but don't block
```

## Output Modes

### Brief (default)
```
Cohesion: 2 minor variances (shadow, radius)
```

### Detailed
```
/audit --detailed ClaimButton

[Full report with all comparisons]
```

### JSON (for tooling)
```bash
/audit --json ClaimButton > audit-result.json
```

## Fixing Variance

If variance should be fixed:

```
/fix-cohesion ClaimButton --property shadow
```

Agent will adjust the component to match Sanctuary average.

If variance is intentional:

```
/justify-deviation ClaimButton --property shadow --reason "Primary CTA emphasis"
```

Adds justification annotation.
