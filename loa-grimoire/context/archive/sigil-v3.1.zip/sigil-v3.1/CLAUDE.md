# Sigil: Design Context Framework

> You are implementing Sigil v3.1 "Native Muse" - a design context framework that helps AI agents make consistent design decisions.

## What is Sigil?

Sigil captures design intent so artists can describe *feel* and agents handle *implementation*. It provides:

- **Zones**: Where in the app (critical, marketing, admin)
- **Personas**: Who is using it (depositor, whale, newcomer)
- **Physics**: How things move (deliberate 800ms, snappy 150ms)
- **Vocabulary**: Product terms mapped to physics (claim, deposit, vault)

## Core Philosophy

```
Artists think in feel. Agents handle implementation. Flow is preserved.
```

**The Problem**: Artists context-switch between "feel-thinking" and "implementation-thinking" dozens of times per session. Every switch breaks flow.

**The Solution**: The agent knows everything—feel context, component APIs, codebase patterns, framework gotchas—so artists never leave feel-thinking.

## Architecture: The Native Muse

### Source of Truth Hierarchy

```
1. Type definitions (*.d.ts)     → LAW (compiler-enforced)
2. Code existence in src/        → PRECEDENT (survival = approval)
3. Installed README.md           → Local reference
4. Cached docs (.sigil/)         → Fallback
```

**Rule**: Documentation is hearsay. Type definitions are law. The repo is the only truth.

### Key Principles

1. **Code is precedent** - Existence is approval, deletion is rejection
2. **Survival is the vote** - Patterns that persist are canonical
3. **Never interrupt flow** - No approval dialogs, silent observation
4. **Innovation is the job** - Don't flag novelty as risk

## Skills Overview

| Skill | Purpose | Key Feature |
|-------|---------|-------------|
| Scanning Sanctuary | Find components | ripgrep, <50ms |
| Seeding Sanctuary | Cold start taste | Virtual components until real ones exist |
| Graphing Imports | Map dependencies | Only index what src/ actually uses |
| Querying Workshop | Fast lookups | Pre-computed index, 5ms |
| Validating Physics | Constraint check | Block violations, not novelty |
| Inspiring Ephemerally | External taste | context: fork, one-time fetch |
| Forging Patterns | Break precedent | Explicit innovation mode |
| Observing Survival | Track patterns | Silent tagging, grep-based |
| Chronicling Rationale | Craft logs | Lightweight audit trail |
| Auditing Cohesion | Visual consistency | Property comparison |

## The /craft Flow

```
/craft "trustworthy claim button"
  │
  ├─► Graphing Imports → Verify deps in workshop
  ├─► Scanning Sanctuary → Find matching component
  ├─► Querying Workshop → Get framework types (5ms)
  ├─► Validating Physics → Check constraints (not existence)
  ├─► Generate → No interruption, no approval
  ├─► Observing Survival → Tag new patterns silently
  └─► Chronicling Rationale → Lightweight log
  ↓
Output: Code + Craft Log (no blocking gate)
```

## Implementation Checklist

### Phase 1: Foundation
- [ ] Create `.sigil/` directory structure
- [ ] Implement `workshop.json` schema and builder
- [ ] Create Startup Sentinel (hash check + quick index)
- [ ] Build Graphing Imports script (scan src/ for deps)

### Phase 2: Skills
- [ ] Implement each skill as `skills/{name}/SKILL.md`
- [ ] Add bundled scripts where needed
- [ ] Configure hooks (PreToolUse, PostToolUse, Stop)
- [ ] Test skill discovery and activation

### Phase 3: Evolution
- [ ] Implement Inspiring Ephemerally with context: fork
- [ ] Build Forging Patterns mode
- [ ] Create seed libraries (Linear-like, Vercel-like, Stripe-like)
- [ ] Implement Gardener for survival scanning

### Phase 4: Integration
- [ ] Create sigil-craft agent
- [ ] Define Loa construct interface
- [ ] Test end-to-end cold start → /craft → survival

## File Structure

```
.sigil/
├── workshop.json         # Pre-computed index
├── seed.yaml             # Virtual Sanctuary (fades as real code grows)
├── survival.json         # Pattern tracking (auto-generated)
├── knowledge/            # Cached docs (minimal)
└── craft-log/            # Rationale artifacts

.claude/
├── skills/               # Sigil skills
│   ├── scanning-sanctuary/
│   ├── seeding-sanctuary/
│   ├── graphing-imports/
│   ├── querying-workshop/
│   ├── validating-physics/
│   ├── inspiring-ephemerally/
│   ├── forging-patterns/
│   ├── observing-survival/
│   ├── chronicling-rationale/
│   └── auditing-cohesion/
└── agents/
    └── sigil-craft.md
```

## Configuration

### sigil.yaml

```yaml
version: "3.1"
name: native-muse

# Zone definitions
zones:
  critical:
    physics: deliberate
    timing: 800ms
    description: Irreversible actions (claim, withdraw, delete)
  standard:
    physics: smooth
    timing: 300ms
    description: Normal interactions
  marketing:
    physics: expressive
    timing: variable
    description: Landing pages, promotional content

# Material definitions
materials:
  clay:
    min_timing: 200ms
    shadows: soft
    description: Tactile, moldable feel
  glass:
    min_timing: 150ms
    shadows: sharp
    description: Transparent, reflective

# Vocabulary mappings
vocabulary:
  claim:
    zone: critical
    physics: deliberate
  deposit:
    zone: critical
    physics: deliberate
  browse:
    zone: standard
    physics: smooth

# Framework settings
frameworks:
  detect: true  # Auto-detect from package.json
  include: []   # Additional frameworks to index
  exclude: []   # Frameworks to skip
```

### rules.md

```markdown
# Design Constitution

## Era: v1 (initialized)

## Physics Laws
- Critical zone actions require deliberate timing (800ms+)
- No 3D transforms in standard components
- Bounce animations forbidden in critical zone

## Material Constraints
- Clay material requires 200ms+ transitions
- Glass material uses sharp shadows only

## Sanctified Patterns
(Patterns imported via /sanctify appear here)
```

## Key Commands

| Command | Purpose |
|---------|---------|
| `/craft "description"` | Generate from feel |
| `/craft --forge "description"` | Break precedent, explore |
| `/inspire stripe.com` | Ephemeral fetch (one-time) |
| `/sanctify "pattern name"` | Promote ephemeral to rule |
| `/garden` | Run survival scan |
| `/new-era "name"` | Start fresh precedent epoch |

## References

- See `ARCHITECTURE.md` for full v3.1 specification
- See `skills/` for individual skill implementations
- See `templates/` for configuration templates
- See `reference/` for example outputs
