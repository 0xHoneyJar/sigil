# Sigil v3.1 "Native Muse"

> Design context framework for AI agents. Artists describe feel. Agents handle implementation.

## Quick Start

### 1. Install Skills

Copy the `skills/` directory to your project:

```bash
cp -r skills/ .claude/skills/
```

Or for personal use (all projects):

```bash
cp -r skills/ ~/.claude/skills/
```

### 2. Initialize Sigil

Create the Sigil directory structure:

```bash
mkdir -p .sigil/{knowledge,craft-log}
```

Copy and customize the templates:

```bash
cp templates/sigil.yaml.template sigil.yaml
cp templates/rules.md.template rules.md
```

### 3. Select a Seed (Optional)

For new projects, select a taste seed:

```bash
cp templates/seeds/linear-like.yaml .sigil/seed.yaml
# or: vercel-like.yaml, stripe-like.yaml
```

### 4. Start Crafting

```
/craft "trustworthy claim button"
```

## Skills

| Skill | Triggers On |
|-------|-------------|
| scanning-sanctuary | Finding components, searching codebase |
| seeding-sanctuary | New projects, empty Sanctuary |
| graphing-imports | Dependency mapping, package analysis |
| querying-workshop | Framework lookups, API questions |
| validating-physics | Before generation (PreToolUse hook) |
| inspiring-ephemerally | "like stripe.com", "inspired by X" |
| forging-patterns | `/craft --forge`, explicit innovation |
| observing-survival | After generation (PostToolUse hook) |
| chronicling-rationale | End of craft (Stop hook) |
| auditing-cohesion | Visual consistency checks |

## Key Commands

| Command | Purpose |
|---------|---------|
| `/craft "description"` | Generate from feel description |
| `/craft --forge "desc"` | Break precedent, explore |
| `/inspire [url]` | One-time fetch, ephemeral |
| `/sanctify "name"` | Promote pattern to rule |
| `/garden` | Run survival scan |
| `/new-era "name"` | Start fresh precedent epoch |

## File Structure

```
your-project/
├── .sigil/
│   ├── workshop.json      # Pre-computed index (auto-generated)
│   ├── seed.yaml          # Virtual Sanctuary (optional)
│   ├── survival.json      # Pattern tracking (auto-generated)
│   └── craft-log/         # Rationale artifacts
│
├── .claude/
│   └── skills/            # Sigil skills (copied from package)
│
├── sigil.yaml             # Configuration
├── rules.md               # Design constitution
└── src/
    └── sanctuary/         # Your design system
        ├── gold/          # Highest tier components
        └── silver/        # Standard components
```

## Philosophy

### The Three Laws

1. **Code is precedent** — Existence is approval, deletion is rejection
2. **Survival is the vote** — Patterns that persist become canonical
3. **Never interrupt flow** — No approval dialogs, silent observation

### Source of Truth

```
Type definitions (*.d.ts)  → LAW
Code in src/               → PRECEDENT  
Installed README.md        → Reference
Cached docs                → Fallback
```

## Testing

Sigil uses TDD at three layers:

| Layer | What's Tested | How |
|-------|---------------|-----|
| Mechanics | Scanning, graphing, querying, validation | Unit tests |
| Craft Flow | Context resolution, pattern selection | Integration tests |
| Taste | Does the pattern work? | Survival (codebase as test suite) |

```bash
# Run all tests
npm test

# Run with coverage
npm test:coverage

# Watch mode
npm test:watch

# Specific test layers
npm test:unit
npm test:integration
npm test:survival
```

**Coverage targets:**
- Validation: 100% (safety-critical)
- Vocabulary: 100% (core mapping)
- Overall: 70%

See `tests/README.md` for full testing philosophy.

## Documentation

- `CLAUDE.md` — CLI prompt for implementation
- `ARCHITECTURE.md` — Full v3.1 specification
- `skills/*/SKILL.md` — Individual skill docs
- `templates/` — Configuration templates
- `reference/` — Example outputs
- `tests/` — Test suite with fixtures

## License

MIT
