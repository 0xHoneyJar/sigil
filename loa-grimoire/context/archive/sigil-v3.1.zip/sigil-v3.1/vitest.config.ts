import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    // Test environment
    environment: 'node',
    
    // Include patterns
    include: [
      'tests/**/*.test.ts'
    ],
    
    // Exclude patterns
    exclude: [
      'node_modules',
      'dist'
    ],
    
    // Coverage configuration
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      include: ['src/**/*.ts'],
      exclude: ['src/**/*.d.ts'],
      thresholds: {
        // Validation is safety-critical
        'src/skills/validation.ts': {
          statements: 100,
          branches: 100,
          functions: 100,
          lines: 100
        },
        // Vocabulary resolution is core mapping
        'src/skills/vocabulary.ts': {
          statements: 100,
          branches: 100,
          functions: 100,
          lines: 100
        },
        // Global thresholds
        global: {
          statements: 70,
          branches: 70,
          functions: 70,
          lines: 70
        }
      }
    },
    
    // Setup files
    setupFiles: ['./tests/setup.ts'],
    
    // Timeout for async tests
    testTimeout: 10000,
    
    // Reporter
    reporters: ['verbose'],
    
    // Aliases for imports
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@fixtures': path.resolve(__dirname, './tests/fixtures')
    }
  }
});
