# Sigil Tests

> TDD for design context. Mechanics are testable. Survival is the acceptance test.

## Philosophy

From Obie Fernandez via Martin Fowler:

> "You can't write a meaningful test for something you don't understand. 
> And you can't verify that a test correctly captures intent without 
> understanding the intent yourself."

Sigil applies this at three layers:

| Layer | What's Tested | How |
|-------|---------------|-----|
| Mechanics | Scanning, graphing, querying, validation | Unit tests |
| Craft Flow | Context resolution, pattern selection | Integration tests |
| Taste | Does the pattern work? | Survival (codebase as test suite) |

## Test Structure

```
tests/
├── unit/
│   ├── scanning.test.ts      # Sanctuary search patterns
│   ├── graphing.test.ts      # Import extraction
│   ├── querying.test.ts      # Workshop index lookups
│   ├── validation.test.ts    # Physics constraint checking
│   └── vocabulary.test.ts    # Term → zone → physics resolution
│
├── integration/
│   ├── craft-flow.test.ts    # Full /craft command flow
│   ├── context-resolution.test.ts
│   └── pattern-selection.test.ts
│
├── survival/
│   ├── promotion.test.ts     # 3+ occurrences → canonical
│   ├── rejection.test.ts     # 0 occurrences → rejected
│   └── gardener.test.ts      # Survival scanning accuracy
│
└── fixtures/
    ├── workshop.json         # Test workshop index
    ├── survival.json         # Test survival state
    ├── sigil.yaml            # Test configuration
    └── sanctuary/            # Mock component files
```

## Running Tests

```bash
# All tests
npm test

# Unit tests only
npm test -- --grep "unit"

# Integration tests
npm test -- --grep "integration"

# Watch mode during development
npm test -- --watch
```

## The TDD Cycle for Sigil

### Red: Define the constraint

```typescript
it('blocks bounce in critical zone', () => {
  const result = validatePhysics(bouncySpring, { zone: 'critical' });
  expect(result.valid).toBe(false);
});
```

### Green: Implement minimally

```typescript
function validatePhysics(code, context) {
  if (context.zone === 'critical' && isBouncy(code)) {
    return { valid: false, reason: 'Critical zone forbids bounce' };
  }
  return { valid: true };
}
```

### Refactor: Clean up

Extract `isBouncy`, add proper error messages, handle edge cases.

## Survival as Acceptance Testing

Unit and integration tests verify mechanics. **Survival verifies taste.**

| CI Question | Survival Question |
|-------------|-------------------|
| Does it compile? | Does it persist? |
| Do tests pass? | Does the team keep it? |
| Is coverage high? | Are patterns spreading? |

The codebase is the final test suite. Deletion is a failing test.

## Coverage Goals

| Area | Target | Rationale |
|------|--------|-----------|
| Validation | 100% | Safety-critical, blocks bad code |
| Vocabulary resolution | 100% | Core mapping logic |
| Workshop queries | 90% | Data access patterns |
| Scanning | 80% | Regex patterns have edge cases |
| Craft flow | 70% | Integration paths vary |
| Survival | 60% | Some behavior is emergent |

## Writing Good Sigil Tests

### DO: Test constraints

```typescript
it('requires 500ms+ timing in critical zone', () => {
  expect(validateTiming(400, 'critical').valid).toBe(false);
  expect(validateTiming(500, 'critical').valid).toBe(true);
});
```

### DO: Test mappings

```typescript
it('maps "claim" to critical zone', () => {
  expect(resolveVocabulary('claim').zone).toBe('critical');
});
```

### DON'T: Test taste directly

```typescript
// BAD - taste is subjective
it('generates beautiful code', () => {
  expect(isBeautiful(result)).toBe(true); // How?
});

// GOOD - test the constraint that enables beauty
it('uses deliberate physics for claim actions', () => {
  expect(result.physics).toBe('deliberate');
});
```

### DO: Use survival as delayed acceptance

```typescript
// This test runs weekly via gardener
it('promotes patterns with 3+ occurrences', () => {
  const result = runGardener(mockCodebase);
  expect(result.patterns['useClaimAnimation'].status).toBe('canonical');
});
```

## Fixtures

Test fixtures in `fixtures/` provide consistent test data:

- `workshop.json` - Pre-built index for query tests
- `survival.json` - Pattern state for survival tests
- `sigil.yaml` - Configuration for resolution tests
- `sanctuary/` - Mock components for scanning tests

Update fixtures when schema changes. Keep them minimal but representative.
