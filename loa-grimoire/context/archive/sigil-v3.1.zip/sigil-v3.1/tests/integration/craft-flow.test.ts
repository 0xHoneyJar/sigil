/**
 * Craft Flow Integration Tests
 * 
 * Tests the full /craft command flow from prompt to output.
 * Verifies that all skills work together correctly.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { craft, CraftResult } from '../src/craft';
import { loadFixtures } from './helpers';

describe('integration/craft-flow', () => {
  let fixtures: Awaited<ReturnType<typeof loadFixtures>>;

  beforeEach(async () => {
    fixtures = await loadFixtures();
  });

  describe('context resolution', () => {
    it('resolves "trustworthy claim button" to critical/deliberate', async () => {
      const result = await craft('trustworthy claim button', fixtures);
      
      expect(result.context).toEqual({
        zone: 'critical',
        physics: 'deliberate',
        vocabulary: ['claim'],
        timing: expect.any(Number)
      });
      expect(result.context.timing).toBeGreaterThanOrEqual(500);
    });

    it('resolves "snappy navigation menu" to standard/snappy', async () => {
      const result = await craft('snappy navigation menu', fixtures);
      
      expect(result.context).toEqual({
        zone: 'standard',
        physics: 'snappy',
        vocabulary: ['navigate'],
        timing: expect.any(Number)
      });
    });

    it('resolves "explore feature" to marketing/expressive', async () => {
      const result = await craft('explore feature showcase', fixtures);
      
      expect(result.context.zone).toBe('marketing');
      expect(result.context.physics).toBe('expressive');
    });

    it('defaults to standard when no vocabulary matched', async () => {
      const result = await craft('beautiful card component', fixtures);
      
      expect(result.context.zone).toBe('standard');
      expect(result.context.physics).toBe('smooth');
    });
  });

  describe('component selection', () => {
    it('finds exact component match in Sanctuary', async () => {
      const result = await craft('claim button', fixtures);
      
      expect(result.component).toEqual({
        name: 'ClaimButton',
        tier: 'gold',
        path: expect.stringContaining('ClaimButton.tsx')
      });
    });

    it('prefers gold tier over silver', async () => {
      const result = await craft('tooltip component', fixtures);
      
      // If gold Tooltip exists, should prefer it
      if (result.component) {
        expect(['gold', 'silver']).toContain(result.component.tier);
      }
    });

    it('returns null component when no match found', async () => {
      const result = await craft('nonexistent widget', fixtures);
      
      // Should still generate, just without existing component
      expect(result.generated).toBe(true);
    });
  });

  describe('physics validation', () => {
    it('blocks generation that violates zone constraints', async () => {
      // Force a bouncy spring in critical context
      const result = await craft('bouncy claim button', fixtures);
      
      // Should either reject or correct the physics
      if (result.validation.passed) {
        // If it passed, physics should have been corrected
        expect(result.code).not.toMatch(/bounce: 0\.[5-9]/);
      } else {
        expect(result.validation.reason).toContain('bounce');
      }
    });

    it('passes validation for correct physics', async () => {
      const result = await craft('deliberate claim button', fixtures);
      
      expect(result.validation.passed).toBe(true);
    });
  });

  describe('pattern selection', () => {
    it('prefers canonical patterns over experimental', async () => {
      const fixturesWithSurvival = {
        ...fixtures,
        survival: {
          patterns: {
            'useClaimAnimation': { status: 'canonical', occurrences: 5 },
            'useNewClaimAnimation': { status: 'experimental', occurrences: 1 }
          }
        }
      };
      
      const result = await craft('claim button', fixturesWithSurvival);
      
      // Should use the canonical pattern
      expect(result.patterns.selected).toContain('useClaimAnimation');
    });

    it('avoids rejected patterns', async () => {
      const fixturesWithRejected = {
        ...fixtures,
        survival: {
          patterns: {
            'bouncySpring': { status: 'rejected', occurrences: 0 }
          }
        }
      };
      
      const result = await craft('animated button', fixturesWithRejected);
      
      expect(result.patterns.avoided).toContain('bouncySpring');
    });
  });

  describe('craft log generation', () => {
    it('generates craft log with decisions', async () => {
      const result = await craft('trustworthy claim button', fixtures);
      
      expect(result.craftLog).toBeDefined();
      expect(result.craftLog.request).toBe('trustworthy claim button');
      expect(result.craftLog.context).toBeDefined();
      expect(result.craftLog.decisions).toBeDefined();
    });

    it('includes physics checks in craft log', async () => {
      const result = await craft('claim button', fixtures);
      
      expect(result.craftLog.physicsChecks).toBeDefined();
      expect(result.craftLog.physicsChecks.length).toBeGreaterThan(0);
    });
  });

  describe('survival tagging', () => {
    it('tags new patterns with observation date', async () => {
      const result = await craft('novel pattern button', fixtures);
      
      if (result.patterns.new.length > 0) {
        expect(result.code).toMatch(/@sigil-pattern/);
        expect(result.code).toMatch(/\d{4}-\d{2}-\d{2}/);
      }
    });

    it('does not tag existing canonical patterns', async () => {
      const result = await craft('claim button', fixtures);
      
      // Existing patterns don't need new tags
      if (result.patterns.existing.includes('ClaimButton')) {
        // Should use existing pattern without adding new tag
        expect(result.patterns.new).not.toContain('ClaimButton');
      }
    });
  });

  describe('error handling', () => {
    it('handles missing workshop gracefully', async () => {
      const noWorkshop = { ...fixtures, workshop: null };
      
      // Should not throw, should use fallback
      const result = await craft('button', noWorkshop);
      expect(result).toBeDefined();
    });

    it('handles empty Sanctuary gracefully', async () => {
      const emptySanctuary = { ...fixtures, sanctuary: [] };
      
      // Should use seed or generate new
      const result = await craft('button', emptySanctuary);
      expect(result.generated).toBe(true);
    });

    it('handles invalid prompt gracefully', async () => {
      const result = await craft('', fixtures);
      
      expect(result.error).toBeDefined();
      expect(result.error).toContain('prompt');
    });
  });

  describe('output structure', () => {
    it('returns complete CraftResult', async () => {
      const result = await craft('claim button', fixtures);
      
      expect(result).toMatchObject({
        code: expect.any(String),
        context: expect.any(Object),
        component: expect.anything(), // Can be null
        validation: expect.any(Object),
        patterns: expect.any(Object),
        craftLog: expect.any(Object),
        generated: expect.any(Boolean)
      });
    });

    it('code is syntactically valid', async () => {
      const result = await craft('claim button', fixtures);
      
      // Should not throw when parsed
      expect(() => {
        // Basic check - starts with import or export or function
        const isValidStart = /^(import|export|function|const|let|var|\/\*)/m
          .test(result.code.trim());
        expect(isValidStart).toBe(true);
      }).not.toThrow();
    });
  });

});
