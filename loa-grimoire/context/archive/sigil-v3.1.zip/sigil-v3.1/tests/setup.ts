/**
 * Test Setup
 * 
 * Global setup for all tests.
 */

import { beforeAll, afterAll, beforeEach } from 'vitest';

// Mock current date for consistent survival tests
const MOCK_DATE = new Date('2026-01-08T12:00:00Z');

beforeAll(() => {
  // Store original Date
  const OriginalDate = global.Date;
  
  // Mock Date for survival calculations
  global.Date = class extends OriginalDate {
    constructor(...args: any[]) {
      if (args.length === 0) {
        return new OriginalDate(MOCK_DATE);
      }
      // @ts-ignore
      return new OriginalDate(...args);
    }
    
    static now() {
      return MOCK_DATE.getTime();
    }
  } as any;
});

beforeEach(() => {
  // Reset any mocks between tests
});

afterAll(() => {
  // Cleanup
});

// Global test utilities
declare global {
  namespace Vi {
    interface JestAssertion<T = any> {
      toBeValidPhysics(): void;
      toBeInvalidPhysics(reason?: string): void;
    }
  }
}
