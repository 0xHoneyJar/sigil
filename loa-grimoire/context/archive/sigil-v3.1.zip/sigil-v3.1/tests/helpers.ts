/**
 * Test Helpers
 * 
 * Utilities for loading fixtures and creating test scenarios.
 */

import { readFile } from 'fs/promises';
import { join } from 'path';
import { parse as parseYaml } from 'yaml';

const FIXTURES_DIR = join(__dirname, 'fixtures');

/**
 * Load all standard fixtures for testing
 */
export async function loadFixtures() {
  const [workshop, survival, sigil] = await Promise.all([
    loadJson('workshop.json'),
    loadJson('survival.json'),
    loadYaml('sigil.yaml')
  ]);

  return {
    workshop,
    survival,
    sigil,
    sanctuary: await loadSanctuary()
  };
}

/**
 * Load a JSON fixture
 */
export async function loadJson(filename: string) {
  const content = await readFile(join(FIXTURES_DIR, filename), 'utf-8');
  return JSON.parse(content);
}

/**
 * Load a YAML fixture
 */
export async function loadYaml(filename: string) {
  const content = await readFile(join(FIXTURES_DIR, filename), 'utf-8');
  return parseYaml(content);
}

/**
 * Load mock Sanctuary components
 */
export async function loadSanctuary() {
  // Return mock component metadata
  return [
    {
      name: 'ClaimButton',
      path: 'src/sanctuary/gold/ClaimButton.tsx',
      tier: 'gold',
      zone: 'critical',
      physics: 'deliberate',
      vocabulary: ['claim', 'withdraw']
    },
    {
      name: 'Card',
      path: 'src/sanctuary/gold/Card.tsx',
      tier: 'gold',
      zone: 'standard',
      physics: 'smooth',
      vocabulary: ['card']
    },
    {
      name: 'Tooltip',
      path: 'src/sanctuary/silver/Tooltip.tsx',
      tier: 'silver',
      zone: 'standard',
      physics: 'snappy',
      vocabulary: ['tooltip', 'hint']
    }
  ];
}

/**
 * Create a mock codebase for survival testing
 */
export function createMockCodebase(files: Record<string, string>) {
  return files;
}

/**
 * Create a pattern state for testing
 */
export function createPatternState(overrides: Partial<PatternState> = {}): PatternState {
  return {
    firstSeen: new Date('2026-01-01'),
    occurrences: 1,
    status: 'experimental',
    files: [],
    ...overrides
  };
}

interface PatternState {
  firstSeen: Date;
  occurrences: number;
  status: 'canonical' | 'survived' | 'experimental' | 'rejected' | 'unknown';
  files: string[];
  deletedAt?: Date;
  wasGreaterThanZero?: boolean;
}

/**
 * Assert that code passes physics validation
 */
export function assertValidPhysics(
  validateFn: (code: string, context: any) => { valid: boolean; reason?: string },
  code: string,
  context: any
) {
  const result = validateFn(code, context);
  if (!result.valid) {
    throw new Error(`Physics validation failed: ${result.reason}`);
  }
}

/**
 * Assert that code fails physics validation
 */
export function assertInvalidPhysics(
  validateFn: (code: string, context: any) => { valid: boolean; reason?: string },
  code: string,
  context: any,
  expectedReason?: string
) {
  const result = validateFn(code, context);
  if (result.valid) {
    throw new Error('Expected physics validation to fail, but it passed');
  }
  if (expectedReason && !result.reason?.includes(expectedReason)) {
    throw new Error(
      `Expected reason to contain "${expectedReason}", got "${result.reason}"`
    );
  }
}

/**
 * Create a test workshop with specific materials
 */
export function createWorkshop(materials: Record<string, any>, components: Record<string, any> = {}) {
  return {
    indexed_at: new Date().toISOString(),
    package_hash: 'test-hash',
    imports_hash: 'test-imports-hash',
    materials,
    components,
    physics: {
      snappy: { timing: '150ms', easing: 'ease-out' },
      smooth: { timing: '300ms', easing: 'cubic-bezier(0.4, 0, 0.2, 1)' },
      deliberate: { timing: '800ms', easing: 'cubic-bezier(0.4, 0, 0.2, 1)' }
    },
    zones: {
      critical: { physics: 'deliberate', timing: '800ms' },
      standard: { physics: 'smooth', timing: '300ms' },
      marketing: { physics: 'expressive', timing: 'variable' }
    }
  };
}

/**
 * Wait for async operations in tests
 */
export function wait(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Create a date relative to today
 */
export function daysAgo(days: number): Date {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date;
}
