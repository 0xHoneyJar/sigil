/**
 * Scanning Sanctuary Tests
 * 
 * Tests for finding components in the design system.
 * These verify ripgrep patterns and tier resolution.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { 
  scanForComponents, 
  scanByVocabulary, 
  scanByZone,
  scanByTier,
  parseSigilAnnotations 
} from '../src/skills/scanning';

describe('unit/scanning', () => {
  
  describe('parseSigilAnnotations', () => {
    it('extracts tier from JSDoc comment', () => {
      const source = `
        /**
         * @sigil-tier gold
         */
        export function Button() {}
      `;
      const annotations = parseSigilAnnotations(source);
      expect(annotations.tier).toBe('gold');
    });

    it('extracts multiple annotations', () => {
      const source = `
        /**
         * @sigil-tier gold
         * @sigil-zone critical
         * @sigil-physics deliberate
         * @sigil-vocabulary claim, withdraw
         */
        export function ClaimButton() {}
      `;
      const annotations = parseSigilAnnotations(source);
      expect(annotations).toEqual({
        tier: 'gold',
        zone: 'critical',
        physics: 'deliberate',
        vocabulary: ['claim', 'withdraw']
      });
    });

    it('returns empty object for unannotated source', () => {
      const source = `export function Button() {}`;
      const annotations = parseSigilAnnotations(source);
      expect(annotations).toEqual({});
    });

    it('handles inline annotations', () => {
      const source = `// @sigil-tier silver`;
      const annotations = parseSigilAnnotations(source);
      expect(annotations.tier).toBe('silver');
    });
  });

  describe('scanByVocabulary', () => {
    it('finds components matching vocabulary term', async () => {
      const results = await scanByVocabulary('claim', 'fixtures/sanctuary');
      expect(results).toContainEqual(
        expect.objectContaining({ name: 'ClaimButton' })
      );
    });

    it('returns empty array for unknown vocabulary', async () => {
      const results = await scanByVocabulary('nonexistent', 'fixtures/sanctuary');
      expect(results).toEqual([]);
    });

    it('matches partial vocabulary terms', async () => {
      // Component has vocabulary: ['claim', 'withdraw']
      const results = await scanByVocabulary('withdraw', 'fixtures/sanctuary');
      expect(results.length).toBeGreaterThan(0);
    });
  });

  describe('scanByZone', () => {
    it('finds all critical zone components', async () => {
      const results = await scanByZone('critical', 'fixtures/sanctuary');
      expect(results.every(r => r.zone === 'critical')).toBe(true);
    });

    it('finds all standard zone components', async () => {
      const results = await scanByZone('standard', 'fixtures/sanctuary');
      expect(results.length).toBeGreaterThan(0);
    });
  });

  describe('scanByTier', () => {
    it('finds gold tier components', async () => {
      const results = await scanByTier('gold', 'fixtures/sanctuary');
      expect(results.every(r => r.tier === 'gold')).toBe(true);
    });

    it('orders by tier priority', async () => {
      const results = await scanForComponents('Button', 'fixtures/sanctuary');
      const tiers = results.map(r => r.tier);
      // Gold should come before Silver
      const goldIndex = tiers.indexOf('gold');
      const silverIndex = tiers.indexOf('silver');
      if (goldIndex !== -1 && silverIndex !== -1) {
        expect(goldIndex).toBeLessThan(silverIndex);
      }
    });
  });

  describe('scanForComponents', () => {
    it('finds exact name match', async () => {
      const results = await scanForComponents('ClaimButton', 'fixtures/sanctuary');
      expect(results[0].name).toBe('ClaimButton');
    });

    it('finds partial name match', async () => {
      const results = await scanForComponents('Claim', 'fixtures/sanctuary');
      expect(results.some(r => r.name.includes('Claim'))).toBe(true);
    });

    it('includes file path in results', async () => {
      const results = await scanForComponents('ClaimButton', 'fixtures/sanctuary');
      expect(results[0].path).toMatch(/\.tsx?$/);
    });

    it('returns empty for no matches', async () => {
      const results = await scanForComponents('NonExistent', 'fixtures/sanctuary');
      expect(results).toEqual([]);
    });
  });

});
