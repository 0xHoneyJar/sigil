/**
 * Querying Workshop Tests
 * 
 * Tests for fast lookups against the pre-computed workshop index.
 * Verifies index queries, staleness detection, and fallback behavior.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { 
  queryMaterial,
  queryComponent,
  queryPhysics,
  queryZone,
  isWorkshopStale,
  getMaterialExports,
  getComponentsByZone 
} from '../src/skills/querying';
import workshopFixture from '../fixtures/workshop.json';

describe('unit/querying', () => {

  describe('queryMaterial', () => {
    it('returns material info for known package', () => {
      const result = queryMaterial('framer-motion', workshopFixture);
      expect(result).toEqual({
        version: '11.0.0',
        exports: expect.arrayContaining(['motion', 'AnimatePresence']),
        types_available: true
      });
    });

    it('returns null for unknown package', () => {
      const result = queryMaterial('nonexistent-package', workshopFixture);
      expect(result).toBeNull();
    });

    it('includes signatures when available', () => {
      const result = queryMaterial('framer-motion', workshopFixture);
      expect(result.signatures).toBeDefined();
      expect(result.signatures['useSpring']).toContain('MotionValue');
    });
  });

  describe('getMaterialExports', () => {
    it('returns exports array for known package', () => {
      const exports = getMaterialExports('framer-motion', workshopFixture);
      expect(exports).toContain('motion');
      expect(exports).toContain('useAnimation');
    });

    it('returns empty array for unknown package', () => {
      const exports = getMaterialExports('unknown', workshopFixture);
      expect(exports).toEqual([]);
    });
  });

  describe('queryComponent', () => {
    it('returns component info for known component', () => {
      const result = queryComponent('ClaimButton', workshopFixture);
      expect(result).toEqual({
        path: 'src/sanctuary/gold/ClaimButton.tsx',
        tier: 'gold',
        zone: 'critical',
        physics: 'deliberate',
        vocabulary: ['claim', 'withdraw'],
        imports: expect.arrayContaining(['framer-motion'])
      });
    });

    it('returns null for unknown component', () => {
      const result = queryComponent('NonExistent', workshopFixture);
      expect(result).toBeNull();
    });

    it('is case-sensitive', () => {
      const result = queryComponent('claimbutton', workshopFixture);
      expect(result).toBeNull();
    });
  });

  describe('getComponentsByZone', () => {
    it('returns all critical zone components', () => {
      const components = getComponentsByZone('critical', workshopFixture);
      expect(components.length).toBeGreaterThan(0);
      expect(components.every(c => c.zone === 'critical')).toBe(true);
    });

    it('returns all standard zone components', () => {
      const components = getComponentsByZone('standard', workshopFixture);
      expect(components.length).toBeGreaterThan(0);
    });

    it('returns empty array for unknown zone', () => {
      const components = getComponentsByZone('nonexistent', workshopFixture);
      expect(components).toEqual([]);
    });
  });

  describe('queryPhysics', () => {
    it('returns physics definition for known physics', () => {
      const result = queryPhysics('deliberate', workshopFixture);
      expect(result).toEqual({
        timing: '800ms',
        easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
        description: 'Intentional, weighty actions'
      });
    });

    it('returns snappy physics', () => {
      const result = queryPhysics('snappy', workshopFixture);
      expect(result.timing).toBe('150ms');
    });

    it('returns null for unknown physics', () => {
      const result = queryPhysics('unknown', workshopFixture);
      expect(result).toBeNull();
    });
  });

  describe('queryZone', () => {
    it('returns zone definition for critical', () => {
      const result = queryZone('critical', workshopFixture);
      expect(result).toEqual({
        physics: 'deliberate',
        timing: '800ms',
        description: 'Irreversible actions'
      });
    });

    it('returns zone definition for standard', () => {
      const result = queryZone('standard', workshopFixture);
      expect(result.physics).toBe('smooth');
    });

    it('returns null for unknown zone', () => {
      const result = queryZone('unknown', workshopFixture);
      expect(result).toBeNull();
    });
  });

  describe('isWorkshopStale', () => {
    it('returns false when hashes match', () => {
      const currentHash = workshopFixture.package_hash;
      expect(isWorkshopStale(workshopFixture, currentHash)).toBe(false);
    });

    it('returns true when package hash differs', () => {
      const differentHash = 'different-hash-value';
      expect(isWorkshopStale(workshopFixture, differentHash)).toBe(true);
    });

    it('returns true when workshop has no hash', () => {
      const noHashWorkshop = { ...workshopFixture, package_hash: undefined };
      expect(isWorkshopStale(noHashWorkshop, 'any-hash')).toBe(true);
    });
  });

  describe('query performance', () => {
    it('queries material in under 5ms', () => {
      const start = performance.now();
      for (let i = 0; i < 100; i++) {
        queryMaterial('framer-motion', workshopFixture);
      }
      const elapsed = performance.now() - start;
      expect(elapsed / 100).toBeLessThan(5);
    });

    it('queries component in under 5ms', () => {
      const start = performance.now();
      for (let i = 0; i < 100; i++) {
        queryComponent('ClaimButton', workshopFixture);
      }
      const elapsed = performance.now() - start;
      expect(elapsed / 100).toBeLessThan(5);
    });
  });

});
