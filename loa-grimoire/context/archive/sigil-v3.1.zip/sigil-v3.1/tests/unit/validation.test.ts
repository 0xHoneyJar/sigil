/**
 * Validating Physics Tests
 * 
 * Tests for physics constraint validation.
 * CRITICAL: These tests ensure safety constraints are enforced.
 * 100% coverage target - blocks bad code from being generated.
 */

import { describe, it, expect } from 'vitest';
import {
  validatePhysics,
  validateZoneConstraint,
  validateMaterialConstraint,
  validateApiCorrectness,
  validateFidelityCeiling,
  parseSpringConfig,
  isBouncySpring,
  extractTimingFromCode
} from '../src/skills/validation';

describe('unit/validation', () => {

  // ===========================================
  // ZONE CONSTRAINTS - Critical Safety Tests
  // ===========================================

  describe('validateZoneConstraint', () => {
    describe('critical zone', () => {
      it('BLOCKS bounce animation in critical zone', () => {
        const code = `spring({ stiffness: 500, damping: 10 })`;
        const result = validateZoneConstraint(code, 'critical');
        expect(result.valid).toBe(false);
        expect(result.reason).toContain('bounce');
      });

      it('BLOCKS playful physics in critical zone', () => {
        const code = `transition: { type: "spring", bounce: 0.5 }`;
        const result = validateZoneConstraint(code, 'critical');
        expect(result.valid).toBe(false);
      });

      it('ALLOWS deliberate physics in critical zone', () => {
        const code = `spring({ stiffness: 100, damping: 20 })`;
        const result = validateZoneConstraint(code, 'critical');
        expect(result.valid).toBe(true);
      });

      it('BLOCKS timing under 500ms in critical zone', () => {
        const code = `transition: { duration: 0.2 }`;
        const result = validateZoneConstraint(code, 'critical');
        expect(result.valid).toBe(false);
        expect(result.reason).toContain('500ms');
      });

      it('ALLOWS timing of 800ms in critical zone', () => {
        const code = `transition: { duration: 0.8 }`;
        const result = validateZoneConstraint(code, 'critical');
        expect(result.valid).toBe(true);
      });
    });

    describe('standard zone', () => {
      it('ALLOWS smooth physics in standard zone', () => {
        const code = `transition: { duration: 0.3 }`;
        const result = validateZoneConstraint(code, 'standard');
        expect(result.valid).toBe(true);
      });

      it('ALLOWS snappy physics in standard zone', () => {
        const code = `transition: { duration: 0.15 }`;
        const result = validateZoneConstraint(code, 'standard');
        expect(result.valid).toBe(true);
      });
    });

    describe('marketing zone', () => {
      it('ALLOWS bounce in marketing zone', () => {
        const code = `spring({ stiffness: 500, damping: 10 })`;
        const result = validateZoneConstraint(code, 'marketing');
        expect(result.valid).toBe(true);
      });

      it('ALLOWS playful physics in marketing zone', () => {
        const code = `transition: { type: "spring", bounce: 0.7 }`;
        const result = validateZoneConstraint(code, 'marketing');
        expect(result.valid).toBe(true);
      });
    });
  });

  // ===========================================
  // MATERIAL CONSTRAINTS
  // ===========================================

  describe('validateMaterialConstraint', () => {
    describe('clay material', () => {
      it('BLOCKS transitions under 200ms for clay', () => {
        const code = `transition: { duration: 0.1 }`;
        const result = validateMaterialConstraint(code, 'clay');
        expect(result.valid).toBe(false);
        expect(result.reason).toContain('200ms');
      });

      it('ALLOWS transitions of 200ms+ for clay', () => {
        const code = `transition: { duration: 0.2 }`;
        const result = validateMaterialConstraint(code, 'clay');
        expect(result.valid).toBe(true);
      });

      it('BLOCKS sharp shadows for clay', () => {
        const code = `boxShadow: "0 1px 0 rgba(0,0,0,0.5)"`;
        const result = validateMaterialConstraint(code, 'clay');
        expect(result.valid).toBe(false);
        expect(result.reason).toContain('shadow');
      });

      it('ALLOWS soft shadows for clay', () => {
        const code = `boxShadow: "0 4px 12px rgba(0,0,0,0.1)"`;
        const result = validateMaterialConstraint(code, 'clay');
        expect(result.valid).toBe(true);
      });
    });

    describe('glass material', () => {
      it('ALLOWS transitions of 150ms+ for glass', () => {
        const code = `transition: { duration: 0.15 }`;
        const result = validateMaterialConstraint(code, 'glass');
        expect(result.valid).toBe(true);
      });

      it('ALLOWS sharp shadows for glass', () => {
        const code = `boxShadow: "0 1px 0 rgba(0,0,0,0.3)"`;
        const result = validateMaterialConstraint(code, 'glass');
        expect(result.valid).toBe(true);
      });
    });
  });

  // ===========================================
  // API CORRECTNESS
  // ===========================================

  describe('validateApiCorrectness', () => {
    const framerExports = ['motion', 'AnimatePresence', 'useAnimation', 'useSpring'];

    it('ALLOWS valid framer-motion API usage', () => {
      const code = `<motion.div animate={{ x: 100 }} />`;
      const result = validateApiCorrectness(code, 'framer-motion', framerExports);
      expect(result.valid).toBe(true);
    });

    it('BLOCKS invalid method on motion', () => {
      const code = `motion.animate({ x: 100 })`;
      const result = validateApiCorrectness(code, 'framer-motion', framerExports);
      expect(result.valid).toBe(false);
      expect(result.reason).toContain('motion.animate');
    });

    it('ALLOWS useAnimation hook', () => {
      const code = `const controls = useAnimation()`;
      const result = validateApiCorrectness(code, 'framer-motion', framerExports);
      expect(result.valid).toBe(true);
    });

    it('BLOCKS non-existent hook', () => {
      const code = `const x = useMotion()`;
      const result = validateApiCorrectness(code, 'framer-motion', framerExports);
      expect(result.valid).toBe(false);
      expect(result.reason).toContain('useMotion');
    });
  });

  // ===========================================
  // FIDELITY CEILING
  // ===========================================

  describe('validateFidelityCeiling', () => {
    it('BLOCKS 3D transforms in standard components', () => {
      const code = `transform: "rotateY(15deg)"`;
      const result = validateFidelityCeiling(code, 'standard');
      expect(result.valid).toBe(false);
      expect(result.reason).toContain('3D');
    });

    it('ALLOWS 3D transforms in marketing zone', () => {
      const code = `transform: "rotateY(15deg)"`;
      const result = validateFidelityCeiling(code, 'marketing');
      expect(result.valid).toBe(true);
    });

    it('BLOCKS excessive shadow blur', () => {
      const code = `boxShadow: "0 0 30px rgba(0,0,0,0.5)"`;
      const result = validateFidelityCeiling(code, 'standard');
      expect(result.valid).toBe(false);
      expect(result.reason).toContain('blur');
    });

    it('ALLOWS shadow blur under ceiling', () => {
      const code = `boxShadow: "0 0 20px rgba(0,0,0,0.5)"`;
      const result = validateFidelityCeiling(code, 'standard');
      expect(result.valid).toBe(true);
    });

    it('BLOCKS WebGL in critical zone', () => {
      const code = `<Canvas><mesh /></Canvas>`;
      const result = validateFidelityCeiling(code, 'critical');
      expect(result.valid).toBe(false);
    });
  });

  // ===========================================
  // HELPER FUNCTIONS
  // ===========================================

  describe('parseSpringConfig', () => {
    it('parses spring with stiffness and damping', () => {
      const code = `spring({ stiffness: 500, damping: 10 })`;
      const config = parseSpringConfig(code);
      expect(config).toEqual({ stiffness: 500, damping: 10 });
    });

    it('parses spring with bounce', () => {
      const code = `type: "spring", bounce: 0.5`;
      const config = parseSpringConfig(code);
      expect(config.bounce).toBe(0.5);
    });

    it('returns null for non-spring code', () => {
      const code = `transition: { duration: 0.3 }`;
      const config = parseSpringConfig(code);
      expect(config).toBeNull();
    });
  });

  describe('isBouncySpring', () => {
    it('identifies bouncy spring by damping ratio', () => {
      // Low damping relative to stiffness = bouncy
      expect(isBouncySpring({ stiffness: 500, damping: 10 })).toBe(true);
    });

    it('identifies non-bouncy spring', () => {
      // High damping relative to stiffness = critically damped
      expect(isBouncySpring({ stiffness: 100, damping: 20 })).toBe(false);
    });

    it('identifies bouncy by bounce parameter', () => {
      expect(isBouncySpring({ bounce: 0.5 })).toBe(true);
    });

    it('identifies non-bouncy by bounce parameter', () => {
      expect(isBouncySpring({ bounce: 0 })).toBe(false);
    });
  });

  describe('extractTimingFromCode', () => {
    it('extracts duration in seconds', () => {
      const code = `transition: { duration: 0.3 }`;
      expect(extractTimingFromCode(code)).toBe(300);
    });

    it('extracts duration in milliseconds string', () => {
      const code = `transition: "300ms"`;
      expect(extractTimingFromCode(code)).toBe(300);
    });

    it('returns null for spring without duration', () => {
      const code = `transition: { type: "spring" }`;
      expect(extractTimingFromCode(code)).toBeNull();
    });
  });

  // ===========================================
  // FULL VALIDATION FLOW
  // ===========================================

  describe('validatePhysics (integration)', () => {
    it('runs all validations and returns first failure', () => {
      const code = `
        spring({ stiffness: 500, damping: 10 });
        boxShadow: "0 0 30px black";
      `;
      const context = { zone: 'critical', material: 'clay' };
      const result = validatePhysics(code, context);
      
      expect(result.valid).toBe(false);
      // Should fail on zone constraint (bounce in critical)
    });

    it('passes when all constraints satisfied', () => {
      const code = `
        transition: { duration: 0.8, ease: [0.4, 0, 0.2, 1] };
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)";
      `;
      const context = { zone: 'critical', material: 'clay' };
      const result = validatePhysics(code, context);
      
      expect(result.valid).toBe(true);
    });

    it('provides actionable suggestion on failure', () => {
      const code = `spring({ stiffness: 500, damping: 10 })`;
      const context = { zone: 'critical' };
      const result = validatePhysics(code, context);
      
      expect(result.suggestion).toBeDefined();
      expect(result.suggestion).toContain('deliberate');
    });
  });

});
