/**
 * Graphing Imports Tests
 * 
 * Tests for extracting actual dependencies from source code.
 * Verifies import detection for ES modules, CommonJS, and scoped packages.
 */

import { describe, it, expect } from 'vitest';
import { 
  extractImports, 
  normalizePackageName,
  isBuiltinModule,
  parseImportStatement 
} from '../src/skills/graphing';

describe('unit/graphing', () => {

  describe('parseImportStatement', () => {
    it('parses ES module default import', () => {
      const result = parseImportStatement(`import React from 'react'`);
      expect(result).toEqual({
        package: 'react',
        imports: ['default'],
        type: 'esm'
      });
    });

    it('parses ES module named imports', () => {
      const result = parseImportStatement(
        `import { useState, useEffect } from 'react'`
      );
      expect(result).toEqual({
        package: 'react',
        imports: ['useState', 'useEffect'],
        type: 'esm'
      });
    });

    it('parses ES module namespace import', () => {
      const result = parseImportStatement(`import * as d3 from 'd3'`);
      expect(result).toEqual({
        package: 'd3',
        imports: ['*'],
        type: 'esm'
      });
    });

    it('parses CommonJS require', () => {
      const result = parseImportStatement(`const fs = require('fs')`);
      expect(result).toEqual({
        package: 'fs',
        imports: ['default'],
        type: 'cjs'
      });
    });

    it('parses dynamic import', () => {
      const result = parseImportStatement(`const mod = await import('lodash')`);
      expect(result).toEqual({
        package: 'lodash',
        imports: ['dynamic'],
        type: 'dynamic'
      });
    });

    it('returns null for relative imports', () => {
      const result = parseImportStatement(`import { Button } from './Button'`);
      expect(result).toBeNull();
    });

    it('returns null for parent imports', () => {
      const result = parseImportStatement(`import { utils } from '../utils'`);
      expect(result).toBeNull();
    });
  });

  describe('normalizePackageName', () => {
    it('keeps simple package names', () => {
      expect(normalizePackageName('react')).toBe('react');
      expect(normalizePackageName('lodash')).toBe('lodash');
    });

    it('preserves scoped packages', () => {
      expect(normalizePackageName('@radix-ui/react-dialog'))
        .toBe('@radix-ui/react-dialog');
    });

    it('extracts root from subpath imports', () => {
      expect(normalizePackageName('lodash/merge')).toBe('lodash');
      expect(normalizePackageName('lodash/fp/map')).toBe('lodash');
    });

    it('handles scoped package subpaths', () => {
      expect(normalizePackageName('@radix-ui/react-dialog/dist/index'))
        .toBe('@radix-ui/react-dialog');
    });

    it('handles packages with dots', () => {
      expect(normalizePackageName('socket.io')).toBe('socket.io');
    });
  });

  describe('isBuiltinModule', () => {
    it('identifies Node.js built-ins', () => {
      expect(isBuiltinModule('fs')).toBe(true);
      expect(isBuiltinModule('path')).toBe(true);
      expect(isBuiltinModule('http')).toBe(true);
      expect(isBuiltinModule('crypto')).toBe(true);
      expect(isBuiltinModule('stream')).toBe(true);
    });

    it('identifies node: prefixed built-ins', () => {
      expect(isBuiltinModule('node:fs')).toBe(true);
      expect(isBuiltinModule('node:path')).toBe(true);
    });

    it('rejects non-built-ins', () => {
      expect(isBuiltinModule('react')).toBe(false);
      expect(isBuiltinModule('lodash')).toBe(false);
      expect(isBuiltinModule('express')).toBe(false);
    });
  });

  describe('extractImports', () => {
    it('extracts all ES imports from source', () => {
      const source = `
        import React from 'react';
        import { motion } from 'framer-motion';
        import { Dialog } from '@radix-ui/react-dialog';
      `;
      const imports = extractImports(source);
      expect(imports).toContain('react');
      expect(imports).toContain('framer-motion');
      expect(imports).toContain('@radix-ui/react-dialog');
    });

    it('extracts CommonJS requires', () => {
      const source = `
        const express = require('express');
        const { Router } = require('express');
      `;
      const imports = extractImports(source);
      expect(imports).toContain('express');
    });

    it('deduplicates imports', () => {
      const source = `
        import React from 'react';
        import { useState } from 'react';
        import { useEffect } from 'react';
      `;
      const imports = extractImports(source);
      const reactCount = imports.filter(i => i === 'react').length;
      expect(reactCount).toBe(1);
    });

    it('excludes relative imports', () => {
      const source = `
        import { Button } from './Button';
        import { utils } from '../utils';
        import React from 'react';
      `;
      const imports = extractImports(source);
      expect(imports).not.toContain('./Button');
      expect(imports).not.toContain('../utils');
      expect(imports).toContain('react');
    });

    it('excludes Node.js built-ins', () => {
      const source = `
        import fs from 'fs';
        import path from 'path';
        import React from 'react';
      `;
      const imports = extractImports(source);
      expect(imports).not.toContain('fs');
      expect(imports).not.toContain('path');
      expect(imports).toContain('react');
    });

    it('handles mixed import styles', () => {
      const source = `
        import React from 'react';
        const lodash = require('lodash');
        const dynamic = await import('chart.js');
      `;
      const imports = extractImports(source);
      expect(imports).toContain('react');
      expect(imports).toContain('lodash');
      expect(imports).toContain('chart.js');
    });

    it('returns empty array for no imports', () => {
      const source = `const x = 1 + 2;`;
      const imports = extractImports(source);
      expect(imports).toEqual([]);
    });
  });

});
