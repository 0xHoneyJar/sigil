/**
 * Vocabulary Resolution Tests
 * 
 * Tests for mapping product terms to zones and physics.
 * Core mapping logic - 100% coverage target.
 */

import { describe, it, expect } from 'vitest';
import {
  resolveVocabulary,
  extractVocabularyTerms,
  inferZoneFromTerms,
  inferPhysicsFromZone,
  fuzzyMatchVocabulary
} from '../src/skills/vocabulary';
import sigilConfig from '../fixtures/sigil.yaml';

describe('unit/vocabulary', () => {

  describe('resolveVocabulary', () => {
    describe('critical zone vocabulary', () => {
      it('maps "claim" to critical zone', () => {
        const result = resolveVocabulary('claim', sigilConfig);
        expect(result.zone).toBe('critical');
        expect(result.physics).toBe('deliberate');
      });

      it('maps "withdraw" to critical zone', () => {
        const result = resolveVocabulary('withdraw', sigilConfig);
        expect(result.zone).toBe('critical');
      });

      it('maps "delete" to critical zone', () => {
        const result = resolveVocabulary('delete', sigilConfig);
        expect(result.zone).toBe('critical');
      });

      it('maps "confirm" to critical zone', () => {
        const result = resolveVocabulary('confirm', sigilConfig);
        expect(result.zone).toBe('critical');
      });
    });

    describe('standard zone vocabulary', () => {
      it('maps "deposit" to standard zone', () => {
        const result = resolveVocabulary('deposit', sigilConfig);
        expect(result.zone).toBe('standard');
        expect(result.physics).toBe('smooth');
      });

      it('maps "browse" to standard zone', () => {
        const result = resolveVocabulary('browse', sigilConfig);
        expect(result.zone).toBe('standard');
      });

      it('maps "select" to standard zone with snappy physics', () => {
        const result = resolveVocabulary('select', sigilConfig);
        expect(result.zone).toBe('standard');
        expect(result.physics).toBe('snappy');
      });

      it('maps "navigate" to standard zone', () => {
        const result = resolveVocabulary('navigate', sigilConfig);
        expect(result.zone).toBe('standard');
      });
    });

    describe('marketing zone vocabulary', () => {
      it('maps "explore" to marketing zone', () => {
        const result = resolveVocabulary('explore', sigilConfig);
        expect(result.zone).toBe('marketing');
        expect(result.physics).toBe('expressive');
      });

      it('maps "discover" to marketing zone', () => {
        const result = resolveVocabulary('discover', sigilConfig);
        expect(result.zone).toBe('marketing');
      });
    });

    describe('unknown vocabulary', () => {
      it('returns null for unknown term', () => {
        const result = resolveVocabulary('foobar', sigilConfig);
        expect(result).toBeNull();
      });
    });
  });

  describe('extractVocabularyTerms', () => {
    it('extracts vocabulary from natural language', () => {
      const prompt = 'trustworthy claim button';
      const terms = extractVocabularyTerms(prompt, sigilConfig);
      expect(terms).toContain('claim');
    });

    it('extracts multiple terms', () => {
      const prompt = 'claim and withdraw actions';
      const terms = extractVocabularyTerms(prompt, sigilConfig);
      expect(terms).toContain('claim');
      expect(terms).toContain('withdraw');
    });

    it('ignores non-vocabulary words', () => {
      const prompt = 'trustworthy claim button';
      const terms = extractVocabularyTerms(prompt, sigilConfig);
      expect(terms).not.toContain('trustworthy');
      expect(terms).not.toContain('button');
    });

    it('handles case insensitivity', () => {
      const prompt = 'CLAIM Button';
      const terms = extractVocabularyTerms(prompt, sigilConfig);
      expect(terms).toContain('claim');
    });

    it('returns empty array for no matches', () => {
      const prompt = 'beautiful shiny component';
      const terms = extractVocabularyTerms(prompt, sigilConfig);
      expect(terms).toEqual([]);
    });
  });

  describe('inferZoneFromTerms', () => {
    it('returns critical when any term is critical', () => {
      const terms = ['browse', 'claim'];
      const zone = inferZoneFromTerms(terms, sigilConfig);
      // Critical takes precedence
      expect(zone).toBe('critical');
    });

    it('returns standard when all terms are standard', () => {
      const terms = ['browse', 'navigate'];
      const zone = inferZoneFromTerms(terms, sigilConfig);
      expect(zone).toBe('standard');
    });

    it('returns marketing when all terms are marketing', () => {
      const terms = ['explore', 'discover'];
      const zone = inferZoneFromTerms(terms, sigilConfig);
      expect(zone).toBe('marketing');
    });

    it('returns null for empty terms', () => {
      const zone = inferZoneFromTerms([], sigilConfig);
      expect(zone).toBeNull();
    });

    it('prioritizes critical over all', () => {
      const terms = ['explore', 'claim', 'browse'];
      const zone = inferZoneFromTerms(terms, sigilConfig);
      expect(zone).toBe('critical');
    });
  });

  describe('inferPhysicsFromZone', () => {
    it('returns deliberate for critical zone', () => {
      expect(inferPhysicsFromZone('critical', sigilConfig)).toBe('deliberate');
    });

    it('returns smooth for standard zone', () => {
      expect(inferPhysicsFromZone('standard', sigilConfig)).toBe('smooth');
    });

    it('returns expressive for marketing zone', () => {
      expect(inferPhysicsFromZone('marketing', sigilConfig)).toBe('expressive');
    });

    it('returns null for unknown zone', () => {
      expect(inferPhysicsFromZone('unknown', sigilConfig)).toBeNull();
    });
  });

  describe('fuzzyMatchVocabulary', () => {
    it('matches plural forms', () => {
      const result = fuzzyMatchVocabulary('claims', sigilConfig);
      expect(result).toBe('claim');
    });

    it('matches verb forms', () => {
      const result = fuzzyMatchVocabulary('claiming', sigilConfig);
      expect(result).toBe('claim');
    });

    it('matches past tense', () => {
      const result = fuzzyMatchVocabulary('deleted', sigilConfig);
      expect(result).toBe('delete');
    });

    it('returns null for no fuzzy match', () => {
      const result = fuzzyMatchVocabulary('asdfgh', sigilConfig);
      expect(result).toBeNull();
    });

    it('prefers exact match over fuzzy', () => {
      const result = fuzzyMatchVocabulary('claim', sigilConfig);
      expect(result).toBe('claim');
    });
  });

  describe('edge cases', () => {
    it('handles empty prompt', () => {
      const terms = extractVocabularyTerms('', sigilConfig);
      expect(terms).toEqual([]);
    });

    it('handles prompt with only punctuation', () => {
      const terms = extractVocabularyTerms('!!!...???', sigilConfig);
      expect(terms).toEqual([]);
    });

    it('handles compound words', () => {
      const terms = extractVocabularyTerms('claim-button', sigilConfig);
      expect(terms).toContain('claim');
    });

    it('handles camelCase', () => {
      const terms = extractVocabularyTerms('ClaimButton', sigilConfig);
      expect(terms).toContain('claim');
    });
  });

});
