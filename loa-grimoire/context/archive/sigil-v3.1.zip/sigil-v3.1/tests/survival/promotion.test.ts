/**
 * Survival System Tests
 * 
 * Tests for the pattern survival tracking system.
 * Verifies promotion, rejection, and gardener behavior.
 * 
 * "Survival is the only vote" - code existence IS precedent.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  scanPatterns,
  calculateStatus,
  promotePattern,
  rejectPattern,
  runGardener,
  getSurvivalReport
} from '../src/skills/survival';

describe('survival', () => {

  describe('calculateStatus', () => {
    const now = new Date('2026-01-08');

    describe('promotion rules', () => {
      it('marks pattern as canonical with 3+ occurrences', () => {
        const status = calculateStatus({
          firstSeen: new Date('2026-01-01'),
          occurrences: 3
        }, now);
        
        expect(status).toBe('canonical');
      });

      it('marks pattern as canonical with 5 occurrences', () => {
        const status = calculateStatus({
          firstSeen: new Date('2026-01-01'),
          occurrences: 5
        }, now);
        
        expect(status).toBe('canonical');
      });

      it('requires exactly 3 for promotion', () => {
        const status = calculateStatus({
          firstSeen: new Date('2026-01-01'),
          occurrences: 2
        }, now);
        
        expect(status).not.toBe('canonical');
      });
    });

    describe('survival rules', () => {
      it('marks pattern as survived after 14+ days', () => {
        const status = calculateStatus({
          firstSeen: new Date('2025-12-20'), // 19 days ago
          occurrences: 1
        }, now);
        
        expect(status).toBe('survived');
      });

      it('marks pattern as experimental under 14 days', () => {
        const status = calculateStatus({
          firstSeen: new Date('2026-01-05'), // 3 days ago
          occurrences: 1
        }, now);
        
        expect(status).toBe('experimental');
      });

      it('uses 14 days as survival threshold', () => {
        // Exactly 14 days
        const status = calculateStatus({
          firstSeen: new Date('2025-12-25'), // 14 days
          occurrences: 1
        }, now);
        
        expect(status).toBe('survived');
      });

      it('under 14 days is experimental', () => {
        // 13 days
        const status = calculateStatus({
          firstSeen: new Date('2025-12-26'),
          occurrences: 1
        }, now);
        
        expect(status).toBe('experimental');
      });
    });

    describe('rejection rules', () => {
      it('marks pattern as rejected with 0 occurrences', () => {
        const status = calculateStatus({
          firstSeen: new Date('2025-12-01'),
          occurrences: 0,
          wasGreaterThanZero: true
        }, now);
        
        expect(status).toBe('rejected');
      });

      it('does not reject pattern that never existed', () => {
        const status = calculateStatus({
          firstSeen: new Date('2026-01-01'),
          occurrences: 0,
          wasGreaterThanZero: false
        }, now);
        
        // This is a new pattern that was never used, not a rejection
        expect(status).toBe('unknown');
      });
    });

    describe('priority', () => {
      it('canonical takes precedence over survived', () => {
        // 3 occurrences + over 14 days
        const status = calculateStatus({
          firstSeen: new Date('2025-12-01'),
          occurrences: 3
        }, now);
        
        expect(status).toBe('canonical');
      });

      it('rejection takes precedence over age', () => {
        // 0 occurrences but old pattern
        const status = calculateStatus({
          firstSeen: new Date('2025-01-01'),
          occurrences: 0,
          wasGreaterThanZero: true
        }, now);
        
        expect(status).toBe('rejected');
      });
    });
  });

  describe('scanPatterns', () => {
    it('finds patterns with @sigil-pattern tag', async () => {
      const mockFiles = {
        'src/hooks/useClaimAnimation.ts': `
          // @sigil-pattern: useClaimAnimation (2026-01-01)
          export function useClaimAnimation() {}
        `,
        'src/components/ClaimButton.tsx': `
          // @sigil-pattern: useClaimAnimation (2026-01-01)
          import { useClaimAnimation } from '../hooks';
        `
      };
      
      const patterns = await scanPatterns(mockFiles);
      
      expect(patterns['useClaimAnimation']).toBeDefined();
      expect(patterns['useClaimAnimation'].occurrences).toBe(2);
    });

    it('extracts first-seen date from tag', async () => {
      const mockFiles = {
        'src/test.ts': `// @sigil-pattern: newPattern (2026-01-05)`
      };
      
      const patterns = await scanPatterns(mockFiles);
      
      expect(patterns['newPattern'].firstSeen).toEqual(new Date('2026-01-05'));
    });

    it('handles patterns without date', async () => {
      const mockFiles = {
        'src/test.ts': `// @sigil-pattern: datelessPattern`
      };
      
      const patterns = await scanPatterns(mockFiles);
      
      expect(patterns['datelessPattern']).toBeDefined();
      // Should use current date as fallback
      expect(patterns['datelessPattern'].firstSeen).toBeDefined();
    });

    it('counts files containing pattern', async () => {
      const mockFiles = {
        'src/a.ts': `// @sigil-pattern: shared`,
        'src/b.ts': `// @sigil-pattern: shared`,
        'src/c.ts': `// @sigil-pattern: shared`,
        'src/d.ts': `// @sigil-pattern: unique`
      };
      
      const patterns = await scanPatterns(mockFiles);
      
      expect(patterns['shared'].files.length).toBe(3);
      expect(patterns['unique'].files.length).toBe(1);
    });
  });

  describe('runGardener', () => {
    it('produces survival report', async () => {
      const existingState = {
        patterns: {
          'oldPattern': { 
            firstSeen: '2025-12-01', 
            occurrences: 3,
            status: 'canonical'
          }
        }
      };
      
      const currentFiles = {
        'src/a.ts': `// @sigil-pattern: oldPattern`,
        'src/b.ts': `// @sigil-pattern: oldPattern`,
        'src/c.ts': `// @sigil-pattern: oldPattern`
      };
      
      const report = await runGardener(existingState, currentFiles);
      
      expect(report.canonical.length).toBeGreaterThanOrEqual(1);
    });

    it('detects new patterns', async () => {
      const existingState = { patterns: {} };
      
      const currentFiles = {
        'src/new.ts': `// @sigil-pattern: brandNewPattern (2026-01-08)`
      };
      
      const report = await runGardener(existingState, currentFiles);
      
      expect(report.new).toContain('brandNewPattern');
    });

    it('detects rejections (deleted patterns)', async () => {
      const existingState = {
        patterns: {
          'deletedPattern': {
            firstSeen: '2025-12-01',
            occurrences: 2,
            status: 'experimental'
          }
        }
      };
      
      const currentFiles = {
        // deletedPattern not present
        'src/other.ts': `// @sigil-pattern: otherPattern`
      };
      
      const report = await runGardener(existingState, currentFiles);
      
      expect(report.rejected).toContain('deletedPattern');
    });

    it('detects promotions', async () => {
      const existingState = {
        patterns: {
          'growingPattern': {
            firstSeen: '2025-12-01',
            occurrences: 2,
            status: 'experimental'
          }
        }
      };
      
      const currentFiles = {
        'src/a.ts': `// @sigil-pattern: growingPattern`,
        'src/b.ts': `// @sigil-pattern: growingPattern`,
        'src/c.ts': `// @sigil-pattern: growingPattern`
      };
      
      const report = await runGardener(existingState, currentFiles);
      
      expect(report.promoted).toContain('growingPattern');
    });
  });

  describe('getSurvivalReport', () => {
    it('formats report for display', () => {
      const state = {
        patterns: {
          'canonical1': { status: 'canonical', occurrences: 5 },
          'canonical2': { status: 'canonical', occurrences: 3 },
          'experimental1': { status: 'experimental', occurrences: 1 },
          'rejected1': { status: 'rejected', occurrences: 0 }
        },
        lastScan: '2026-01-08T10:00:00Z'
      };
      
      const report = getSurvivalReport(state);
      
      expect(report.stats).toEqual({
        total: 4,
        canonical: 2,
        experimental: 1,
        rejected: 1
      });
    });
  });

  describe('edge cases', () => {
    it('handles empty codebase', async () => {
      const report = await runGardener({ patterns: {} }, {});
      
      expect(report.canonical).toEqual([]);
      expect(report.experimental).toEqual([]);
      expect(report.rejected).toEqual([]);
    });

    it('handles malformed pattern tags', async () => {
      const mockFiles = {
        'src/bad.ts': `// @sigil-pattern: (missing name)`,
        'src/good.ts': `// @sigil-pattern: validPattern`
      };
      
      const patterns = await scanPatterns(mockFiles);
      
      // Should skip malformed, include valid
      expect(patterns['validPattern']).toBeDefined();
      expect(Object.keys(patterns).length).toBe(1);
    });

    it('handles concurrent occurrences correctly', async () => {
      // Same file, multiple occurrences
      const mockFiles = {
        'src/multi.ts': `
          // @sigil-pattern: multiUse
          // @sigil-pattern: multiUse
          // @sigil-pattern: multiUse
        `
      };
      
      const patterns = await scanPatterns(mockFiles);
      
      // Should count occurrences, not just files
      expect(patterns['multiUse'].occurrences).toBe(3);
    });
  });

});
