/**
 * @sigil-tier gold
 * @sigil-zone critical
 * @sigil-physics deliberate
 * @sigil-vocabulary claim, withdraw
 */

import { motion, AnimatePresence } from 'framer-motion';
import * as Dialog from '@radix-ui/react-dialog';

// @sigil-pattern: ClaimButton (2025-12-01)
// @sigil-pattern: useConfirmation (2025-12-05)

interface ClaimButtonProps {
  amount: number;
  onClaim: () => void;
  disabled?: boolean;
}

export function ClaimButton({ amount, onClaim, disabled }: ClaimButtonProps) {
  return (
    <motion.button
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
      onClick={onClaim}
      disabled={disabled}
      className="claim-button"
    >
      Claim {amount}
    </motion.button>
  );
}

export default ClaimButton;
