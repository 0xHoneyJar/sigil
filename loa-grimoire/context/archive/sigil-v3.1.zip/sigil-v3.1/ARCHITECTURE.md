# The Native Muse: Sigil Intelligence Architecture v3.1

> **Code is precedent. Survival is approval. Creativity needs no permission.**

## Overview

The Native Muse is Sigil's intelligence layer. It grounds the agent in repository reality while preserving creative flow. Unlike previous versions that policed the codebase, v3.1 *curates* it—seeding taste for cold starts, observing pattern survival silently, and allowing ephemeral exploration without pollution.

**Core Principles:**
1. The repo is the only truth
2. Existence is approval, deletion is rejection
3. Never interrupt flow to ask permission
4. Innovation is the job, not a risk to flag

---

## Evolution

| Version | Name | Fatal Flaw |
|---------|------|------------|
| v1 | Foraging Wisdom | 10-45s latency during /craft |
| v2 | Indexing Authority | Documentation lies; daemon doesn't exist |
| v3 | Living Filesystem | Bureaucratic (interrupts for approval, YAML rot) |
| **v3.1** | **Native Muse** | Current architecture |

### Why v3 Failed

**Good ideas, wrong execution:**
- ✓ Local-first intelligence
- ✓ Type definitions as law
- ✓ Scoped to actual imports
- ✗ JIT grep too slow (200ms)
- ✗ Phantom flagging interrupted flow
- ✗ Precedent YAML files rotted and drifted
- ✗ Empty room problem for new projects
- ✗ Airlock too rigid for creative exploration

---

## Skill Architecture

```
Sigil Skills (v3.1 "Native Muse")
│
├── Discovery
│   ├── Scanning Sanctuary       → Find components (ripgrep)
│   ├── Graphing Imports         → Map dependencies from src/
│   └── Seeding Sanctuary        → Virtual taste for cold start
│
├── Intelligence  
│   ├── Querying Workshop        → Pre-computed index (5ms)
│   └── Validating Physics       → Constraint check, not existence check
│
├── Evolution
│   ├── Inspiring Ephemerally    → One-time fetch, forked context
│   └── Forging Patterns         → Explicit precedent-breaking mode
│
├── Verification
│   ├── Auditing Cohesion        → Visual consistency check
│   └── Chronicling Rationale    → Streamlined craft log
│
└── Memory
    └── Observing Survival       → Silent tracking via code existence
```

---

## Claude Code 2.1 Integration

### Agent-Scoped Hooks

Sigil leverages Claude Code 2.1's hook system for lifecycle control:

```yaml
# sigil.skill.md frontmatter
---
name: sigil
description: Design context framework
hooks:
  PreToolUse:
    - validate_physics      # Block physics violations before generation
    - check_workshop_index  # Ensure index is current
  PostToolUse:
    - observe_patterns      # Silent phantom detection
    - update_workshop       # Incremental index updates
  Stop:
    - ensure_craft_log      # Verify rationale exists
    - mark_survival         # Tag new patterns for observation
---
```

### Context Forking

Isolation for exploration skills:

```yaml
# Ephemeral inspiration runs in forked context
---
name: inspiring-ephemerally
context: fork
description: One-time fetch that doesn't pollute main conversation
---

# Forge mode runs in forked context
---
name: forging-patterns
context: fork  
description: Precedent-breaking exploration, isolated
---
```

**Why fork matters:**
- Ephemeral fetch uses context, then discards
- Forge mode experiments don't contaminate main flow
- Research stays separate from implementation

---

## Skill Specifications

### Seeding Sanctuary

**Purpose:** Solve the empty room problem.

**Problem:** New project, empty `src/`. Agent has no taste to reference.

**Solution:** Virtual Sanctuary that exists until replaced.

**Trigger:** `sigil init` or first `/craft` with empty Sanctuary

**Flow:**
```
sigil init
  ↓
"Which vibe?"
  ├── Linear-like (minimal, keyboard-first, monochrome)
  ├── Vercel-like (bold, high-contrast, geometric)
  ├── Stripe-like (soft gradients, generous spacing)
  └── Blank (no seed, pure inference)
  ↓
Inject virtual_sanctuary context
  ↓
Agent has taste from minute zero
```

**Virtual Sanctuary Structure:**
```yaml
# .sigil/seed.yaml (generated, not committed)
seed: linear-like
version: 2026.01
virtual_components:
  Button:
    tiers: [gold]
    physics: snappy (150ms)
    zones: [standard, critical]
  Card:
    tiers: [gold]
    physics: smooth (300ms)
    zones: [standard]
  # ... minimal set of primitives
```

**Fade Behavior:**
```
User creates real src/components/Button.tsx
  ↓
Virtual Button fades, real Button takes precedence
  ↓
When all virtuals replaced, seed.yaml can be deleted
```

**Key:** Never let the agent stare at a blank wall. Give it a mirror until the user builds one.

---

### Querying Workshop

**Purpose:** Pre-computed index for instant lookups.

**Problem:** JIT grep on node_modules takes 200ms. Still a thinking spinner.

**Solution:** Background index maintained via hooks, queried in 5ms.

**Index Structure:**
```json
// .sigil/workshop.json
{
  "indexed_at": "2026-01-08T14:30:00Z",
  "package_hash": "a1b2c3...",
  "materials": {
    "framer-motion": {
      "version": "11.0.0",
      "exports": ["motion", "AnimatePresence", "useAnimation"],
      "types_available": true,
      "readme_available": true
    },
    "@radix-ui/react-dialog": {
      "version": "1.1.0",
      "exports": ["Root", "Trigger", "Portal", "Content"],
      "types_available": true,
      "readme_available": false
    }
  },
  "components": {
    "ClaimButton": {
      "path": "src/sanctuary/gold/ClaimButton.tsx",
      "tier": "gold",
      "zone": "critical",
      "imports": ["framer-motion", "@radix-ui/react-dialog"]
    }
  }
}
```

**Maintenance via Hooks:**
```yaml
hooks:
  PostToolUse:
    - update_workshop  # Incremental update after file changes
```

**Startup Sentinel:**
```
Session start
  ↓
Compare package.json hash to workshop.json.package_hash
  ↓
Match → Ready (0ms)
Mismatch → Quick rebuild (~500ms, blocking OK)
```

**Query Pattern:**
```
/craft needs framer-motion knowledge
  ↓
Query: workshop.json → materials["framer-motion"]
  ↓
Result: { exports, version, types_available } in 5ms
  ↓
If deeper info needed → Read types from node_modules (targeted, not grep-all)
```

---

### Validating Physics

**Purpose:** Check constraints, not existence.

**Problem:** v3 flagged patterns as "Phantoms" if they weren't in codebase. This penalizes innovation.

**Solution:** Validate against Physics (rules), not Pattern (existence).

**What Gets Validated:**

| Check | Example |
|-------|---------|
| API correctness | Does `motion.div` exist in framer-motion? |
| Zone constraints | Critical action using `physics: playful`? Block. |
| Material constraints | Clay button with 0ms transition? Block. |
| Fidelity ceiling | 3D transform in standard component? Block. |

**What Does NOT Get Validated:**

| Non-Check | Why |
|-----------|-----|
| Pattern existence | New patterns are the job, not a risk |
| Style novelty | Experimentation is encouraged |
| Component precedent | Survival decides, not pre-approval |

**Hook Integration:**
```yaml
hooks:
  PreToolUse:
    - validate_physics  # Runs before generation
```

**Validation Flow:**
```
Agent proposes: spring({ stiffness: 500, damping: 10 })
  ↓
Check 1: Is spring() valid API? → Yes (from workshop index)
  ↓
Check 2: Does zone allow bouncy physics? 
  └── Zone: critical → No bounce allowed
  └── BLOCK: "Critical zone requires deliberate physics"
  ↓
Check 3: Does material allow this timing?
  └── Material: clay → Requires 200ms+ transitions
  └── BLOCK: "Clay material requires deliberate transitions"
```

**Key shift:** Flag physics violations, not novelty.

---

### Inspiring Ephemerally

**Purpose:** Allow creative exploration without pollution.

**Problem:** v3's Airlock was too rigid. Designers don't work via CLI commands.

**Solution:** One-time fetch in forked context. Use it, discard it.

**Trigger:**
```
/craft "make it feel like stripe.com"
```

**Flow (using context: fork):**
```
/craft "make it feel like stripe.com"
  ↓
Detect: External reference (stripe.com)
  ↓
Fork context (Claude Code 2.1)
  ↓
[Forked] Fetch stripe.com via Firecrawl
  ↓
[Forked] Extract: gradients, spacing, typography, motion
  ↓
[Forked] Apply to generation
  ↓
Return to main context with generated code only
  ↓
Fetched content discarded (never enters Sanctuary)
```

**Skill Definition:**
```yaml
---
name: inspiring-ephemerally
context: fork
description: One-time external fetch, isolated from main context
triggers:
  - "like [url]"
  - "inspired by [url]"
  - "similar to [url]"
---
```

**Sanctification (Optional):**
```
User likes the result
  ↓
/sanctify "stripe spacing rhythm"
  ↓
Extracts pattern → Proposes rule → User approves
  ↓
Appends to rules.md (now permanent)
```

**Key:** Ephemeral = safe to explore. Sanctify = deliberate commitment.

---

### Forging Patterns

**Purpose:** Explicit precedent-breaking mode.

**Problem:** Precedent creates echo chambers. Sometimes you need to break the pattern.

**Solution:** `/forge` command that ignores survival history.

**Trigger:**
```
/craft --forge "reimagine the claim flow"
# or
/forge "radical new onboarding"
```

**Flow (using context: fork):**
```
/forge "radical new onboarding"
  ↓
Fork context
  ↓
[Forked] Ignore: survival patterns, learned constraints
  ↓
[Forked] Respect: Physics only (API correctness, zone rules)
  ↓
[Forked] Generate: Novel approach
  ↓
Return: Experimental code + rationale
  ↓
User decides: Keep (enters codebase) or Discard
```

**Skill Definition:**
```yaml
---
name: forging-patterns
context: fork
description: Break precedent, optimize for innovation
physics_only: true  # Still respects hard constraints
---
```

**Era Versioning:**
```yaml
# rules.md
## Era: v2-Tactile (started 2026-01-08)

Previous era (v1-Flat) patterns are deprioritized.
Current era emphasizes: depth, texture, physicality.

/forge respects current era direction.
```

**Era Transition:**
```
/new-era "Tactile"
  ↓
Archives current patterns as "v1-Flat"
  ↓
Starts fresh precedent tracking
  ↓
Old patterns don't block new exploration
```

---

### Observing Survival

**Purpose:** Track pattern adoption without interrupting.

**Problem:** v3's YAML files rotted and drifted from code.

**Solution:** Code existence IS precedent. grep count = approval level.

**The Rule:**
```
Approved = exists in src/
Rejected = doesn't exist in src/
Canonical = exists 3+ times
Experimental = exists 1 time, < 2 weeks old
```

**How It Works:**
```
Agent generates new pattern: useClaimAnimation()
  ↓
PostToolUse hook tags with comment:
  // @sigil-pattern: useClaimAnimation (2026-01-08)
  ↓
2 weeks later, Gardener scans:
  rg "@sigil-pattern: useClaimAnimation" src/ --count
  ↓
Count = 3 → Survived, promote to canonical
Count = 1 → Survived, still experimental  
Count = 0 → Deleted, mark as rejected (in hidden index only)
```

**The Gardener (Weekly):**
```bash
# Run weekly or on-demand
sigil garden

# Scans for pattern tags
# Updates hidden survival index
# Promotes/demotes based on count and age
```

**Hidden Index (Not YAML):**
```json
// .sigil/survival.json (auto-generated, .gitignore optional)
{
  "patterns": {
    "useClaimAnimation": {
      "first_seen": "2026-01-08",
      "occurrences": 3,
      "status": "canonical"
    },
    "bouncySpring": {
      "first_seen": "2026-01-05",
      "occurrences": 0,
      "status": "rejected",
      "deleted_at": "2026-01-07"
    }
  }
}
```

**Key:** No approval dialogs. Survival is the only vote.

---

### Chronicling Rationale (Streamlined)

**Purpose:** Verification artifact for Loa integration.

**Change from v3:** Lighter weight, no approval checklist blocking.

**Output:**
```markdown
# Craft: claim-button (2026-01-08)

## Request
"trustworthy claim button"

## Decisions
- Zone: critical (claim vocabulary)
- Physics: deliberate (800ms, no bounce)
- Component: ClaimButton (Gold, matched)
- Framework: framer-motion v11.0.0

## New Patterns Introduced
- None (all patterns canonical)

## Physics Validated
- ✓ Zone constraint (critical → deliberate)
- ✓ Material constraint (clay → 200ms+)
- ✓ API correctness (motion.div verified)

## Notes
Ready for integration.
```

**No blocking checklist.** Rationale is for audit trail, not approval gate.

**Loa Integration:**
```
Loa receives: code + craft log
Loa decision: Continue task (no Sigil approval required)
```

---

## Session Lifecycle

### Startup Sentinel

```
claude / sigil session starts
  ↓
1. Check .sigil/workshop.json exists
   └── No → Build from scratch (~2s)
   └── Yes → Continue
  ↓
2. Compare package.json hash
   └── Match → Ready (0ms)
   └── Mismatch → Rebuild workshop (~500ms)
  ↓
3. Check src/ for Sanctuary components
   └── Empty → Load virtual Sanctuary from seed
   └── Populated → Ready
  ↓
4. Run Gardener if > 7 days since last run
  ↓
Ready for /craft
```

### The /craft Flow (v3.1)

```
/craft "trustworthy claim button"
  │
  ├─► Graphing Imports
  │   └── Verify dependencies in workshop.json ✓
  │
  ├─► Scanning Sanctuary (or Seeding if empty)
  │   └── Find ClaimButton or virtual equivalent ✓
  │
  ├─► Querying Workshop
  │   └── Get framer-motion exports/types (5ms) ✓
  │
  ├─► Validating Physics
  │   └── Check zone + material constraints ✓
  │   └── Block if violation, continue if clean
  │
  ├─► Generate Implementation
  │   └── No interruption, no approval request
  │
  ├─► Observing Survival (PostToolUse hook)
  │   └── Tag new patterns silently
  │
  └─► Chronicling Rationale
      └── Generate lightweight craft log
      
  ↓
Output: Code + Craft Log
  ↓
No approval gate. Artist iterates or accepts.
```

---

## File Structure

```
.sigil/
├── workshop.json         # Pre-computed index (materials + components)
├── seed.yaml             # Virtual Sanctuary for cold start (fades as real code grows)
├── survival.json         # Pattern survival tracking (auto-generated)
│
├── knowledge/            # Cached docs (fallback, minimal)
│   └── framer-motion/
│       └── v11.0.0/
│           └── readme.md
│
└── craft-log/            # Rationale artifacts (lightweight)
    └── 2026-01-08-claim-button.md

# DELETED from v3:
# - precedent/approved.yaml (code is precedent now)
# - precedent/rejected.yaml (deletion is rejection)
# - precedent/near-misses.yaml (survival tracking replaces)
```

---

## Hooks Reference

### PreToolUse Hooks

```yaml
hooks:
  PreToolUse:
    - name: validate_physics
      description: Block generation if physics violated
      blocks: true
      checks:
        - zone_constraints
        - material_constraints
        - api_correctness
        
    - name: check_workshop_index
      description: Ensure workshop.json is current
      blocks: false
      action: Rebuild if stale
```

### PostToolUse Hooks

```yaml
hooks:
  PostToolUse:
    - name: observe_patterns
      description: Tag new patterns for survival tracking
      blocks: false
      action: Add @sigil-pattern comments
      
    - name: update_workshop
      description: Incremental index update after file changes
      blocks: false
      action: Update workshop.json with new exports/components
```

### Stop Hooks

```yaml
hooks:
  Stop:
    - name: ensure_craft_log
      description: Verify rationale was generated
      blocks: false
      action: Generate if missing
      
    - name: mark_survival
      description: Finalize pattern tags
      blocks: false
      action: Update survival.json
```

---

## Taste Governance (v3.1)

### Always Available

| Source | Mechanism |
|--------|-----------|
| Sanctuary (real) | Scanning Sanctuary |
| Sanctuary (virtual) | Seeding Sanctuary |
| rules.md | Direct reference |
| Canonical patterns | Querying Workshop |

### Available via Fork

| Source | Mechanism |
|--------|-----------|
| External URL | Inspiring Ephemerally (context: fork) |
| Competitor reference | Inspiring Ephemerally (context: fork) |
| Precedent-free exploration | Forging Patterns (context: fork) |

### Permanently Sanctified

| Trigger | Result |
|---------|--------|
| `/sanctify "pattern name"` | Extracted from ephemeral → rules.md |
| Pattern survives 2+ weeks | Auto-promoted to canonical |
| 3+ occurrences in src/ | Auto-promoted to canonical |

### Never Autonomous

| Banned | Why |
|--------|-----|
| Agent-initiated web search | Pollution risk |
| Auto-ingestion of "trends" | Bypasses sanctification |
| "Similar to" without explicit URL | Too vague, leads to hallucination |

---

## Loa Integration

### As Loa Construct

```yaml
# construct.yaml
name: sigil
version: 0.4.0
type: design-context

commands:
  - name: craft
    description: Generate from feel description
    requires_approval: false  # Changed from v3
    
  - name: forge
    description: Break precedent, explore
    context: fork
    
  - name: sanctify
    description: Promote ephemeral pattern to rule
    
  - name: garden
    description: Run survival scan

artifacts:
  - craft-log

hooks:
  PreToolUse: [validate_physics, check_workshop_index]
  PostToolUse: [observe_patterns, update_workshop]
  Stop: [ensure_craft_log, mark_survival]
```

### Task Flow

```
Loa Task: "Implement claim flow UI"
  ↓
Loa triggers Sigil
  ↓
Sigil /craft (no approval gate):
  ├── Generate with physics validation
  ├── Tag new patterns silently
  └── Return code + craft log
  ↓
Loa continues immediately
  ↓
Artist reviews in their own time
  ↓
If issues: /craft refinement
If good: Loa task completes
```

**Key change:** Sigil doesn't block Loa. Artist review is async.

---

## Migration from v3

### Delete
```bash
rm -rf .sigil/precedent/
```

### Rename
```bash
# Conceptual, not literal files
"Introspecting Reality" → "Querying Workshop"
"Flagging Phantoms" → "Validating Physics"
"Recording Precedent" → "Observing Survival"
"Guarding Airlock" → "Inspiring Ephemerally"
```

### Generate
```bash
sigil init  # Creates workshop.json, offers seed selection
```

### Update rules.md
```markdown
## Era: v1 (migrated from v3)

Legacy patterns from precedent/*.yaml have been archived.
Survival tracking now based on code existence.
```

---

## Comparison: v3 → v3.1

| Aspect | v3 (Living Filesystem) | v3.1 (Native Muse) |
|--------|------------------------|-------------------|
| Cold start | Empty room | Virtual Sanctuary |
| Index mechanism | JIT grep (200ms) | Pre-computed workshop (5ms) |
| New patterns | Flagged as Phantom | Silently observed |
| Approval flow | Checklist interruption | No interruption |
| Precedent storage | YAML files | Code existence (grep) |
| External taste | CLI command only | Ephemeral (context: fork) |
| Innovation | Penalized (flag) | Encouraged (forge mode) |
| Loa blocking | Yes (approval required) | No (async review) |

---

## Open Questions (Fewer Now)

1. **Seed library:** How many virtual components in each seed? Minimal (5) or comprehensive (20)?

2. **Gardener frequency:** Weekly by default. Should it also run on git push?

3. **Era naming:** User-defined or auto-generated (v1, v2, v3...)?

4. **Ephemeral URL scope:** Should Inspiring Ephemerally follow links, or single page only?

---

## Next Steps

1. [ ] Define seed libraries (Linear-like, Vercel-like, Stripe-like)
2. [ ] Implement workshop.json schema and builder
3. [ ] Create Claude Code 2.1 hook definitions
4. [ ] Build Inspiring Ephemerally with context: fork
5. [ ] Implement Forging Patterns mode
6. [ ] Create Gardener script for survival scanning
7. [ ] Update Loa construct manifest
8. [ ] Test end-to-end cold start → /craft → survival flow
