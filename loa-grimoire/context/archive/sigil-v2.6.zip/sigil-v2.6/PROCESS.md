# Sigil v2.6 — Process & Workflow Architecture

**Version**: 2.6.0  
**Philosophy**: "Sweat the art. We handle the mechanics. Return to flow."  
**Date**: 2026-01-06

---

## Philosophy: Protecting the Craftsman's Flow

Sigil exists to protect the craftsman's flow state — not to shortcut thinking.

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE CRAFTSMAN'S FLOW                             │
│                                                                      │
│  PROTECT:                                                           │
│    ✓ Deep thinking about feel and soul                              │
│    ✓ Time for inspiration and observation                          │
│    ✓ The joy of sweating the right details                         │
│    ✓ Deep dives when the craft demands it                          │
│                                                                      │
│  REMOVE:                                                            │
│    ✗ Implementation mechanics                                       │
│    ✗ Consistency tracking ("did we already decide this?")          │
│    ✗ Boilerplate and wiring                                        │
│    ✗ Context loss after time away                                  │
│                                                                      │
│  ENABLE:                                                            │
│    → Return to flow after stepping away                             │
│    → Quick decisions when you already know                          │
│    → Deep exploration when the art requires it                      │
└─────────────────────────────────────────────────────────────────────┘
```

### The Distinction

| Craftsman Thinks About | Agent Handles |
|------------------------|---------------|
| "How should this feel?" | Wiring up the animation library |
| "What's the right weight here?" | CSS implementation |
| "Does this honor the soul?" | Component structure |
| Deep dives on timing curves | Consistency with past decisions |
| Observing, sketching, feeling | Boilerplate, mechanics |

The craftsman SHOULD sweat the details — that's the essence of craft. Sigil removes the *wrong* cognitive load so you can focus on the *right* details.

---

## Loa + Sigil: The Full Picture

```
┌─────────────────────────────────────────────────────────────────────┐
│                    LOA (Structure & Logic)                          │
│                                                                      │
│  PRD → SDD → Implementation → Deployment                           │
│  Handles: Architecture, data flow, business logic, features        │
└─────────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    SIGIL (Feel & Interface)                         │
│                                                                      │
│  Vision → Rules → Deep Work → Polish                               │
│  Handles: Motion, feel, interaction, the human element             │
│                                                                      │
│  The craftsman's domain. Where taste lives.                        │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Command Overview (8 Commands)

| Command | Purpose | Flow Protection |
|---------|---------|-----------------|
| `/setup` | Initialize Sigil | Quick setup, return to work |
| `/envision` | Externalize vision | Capture inspiration before it fades |
| `/inherit` | Bootstrap from existing | Preserve past decisions |
| `/codify` | Define rules | Externalize tacit knowledge |
| `/sandbox` | Experiment freely | Safe space for exploration |
| `/consult` | Lock a decision | Stop re-litigating settled questions |
| `/craft` | Get context | Return to flow after time away |
| `/garden` | Maintain health | Periodic check, not interruption |

---

## Command Specifications

### 1. `/envision` — Externalize Your Vision

**Purpose**: Get what's in your head OUT before it fades.

**Why This Matters for Flow**:
- Inspiration is fleeting — capture it while it's vivid
- Externalized vision survives stepping away
- Tacit knowledge becomes shareable artifact

**Not About**: Quick selection or avoiding thought. Take your time. Go deep.

**When to Use**:
- Starting a project and vision is clear
- After inspiration strikes
- When onboarding someone to the feel

**What Gets Captured**:
- Reference products (what inspires you, why)
- Feel descriptors (how moments should feel)
- Anti-patterns (what you've learned to hate)
- Core values (what's non-negotiable)
- User lenses (who you're designing for)

**Output**:
- `sigil-mark/moodboard.md` — Your vision, preserved
- `sigil-mark/constitution/` — Protected capabilities
- `sigil-mark/lens-array/` — User perspectives

---

### 2. `/codify` — Capture Tacit Rules

**Purpose**: Externalize the patterns you've internalized.

**Why This Matters for Flow**:
- Tacit knowledge gets lost between sessions
- Consistency shouldn't require memory
- New sessions shouldn't lose old wisdom

**When to Use**:
- After /envision, to make it concrete
- When patterns have emerged from work
- When onboarding collaborators

**What Gets Captured**:
- Color tokens and usage
- Typography rules
- Spacing conventions
- Motion by zone (critical, marketing, admin)
- Component-specific rules

**Output**:
- `sigil-mark/rules.md` — Your taste, codified
- Updated `.sigilrc.yaml` — Zone configurations

---

### 3. `/craft` — Return to Flow

**Purpose**: Restore context. Get back into the work.

**Why This Matters for Flow**:
- Time away is essential for craft
- Returning shouldn't require archaeology
- Context loss kills momentum

**Modes**:

#### Return Mode
```
You stepped away. Where were we?

/craft

→ Product feel summary
→ Locked decisions
→ Current zone configurations
→ What you were working on
```

#### File-Specific Mode
```
/craft src/features/checkout/Button.tsx

→ Zone: Critical
→ Motion: Deliberate (800ms+)
→ Locked decisions that apply
→ Constitution checks
→ Lens validation
```

#### Deep Dive Mode
```
/craft "What are our options for confirmation animations?"

→ Comprehensive exploration
→ References and examples
→ Trade-offs and considerations
→ No rushing — go as deep as you want
```

---

### 4. `/consult` — Lock a Settled Decision

**Purpose**: When you've deliberated and decided, lock it.

**Why This Matters for Flow**:
- Bikeshedding kills flow
- Settled questions should stay settled
- Future-you shouldn't re-argue with past-you

**When to Use**:
- AFTER you've thought deeply
- When the team keeps revisiting the same question
- When you want to commit and move on

**Not About**: Avoiding thought. This is for AFTER deliberation.

**Lock Periods**:
- Strategic: 180 days
- Direction: 90 days
- Execution: 30 days

**Unlock**: Always possible with justification. Creates audit trail.

---

### 5. `/sandbox` — Safe Space for Exploration

**Purpose**: Try things without design system constraints.

**Why This Matters for Flow**:
- Exploration shouldn't trigger lint errors
- Sometimes you need to break rules to find new ones
- The best discoveries come from play

**Lifecycle**:
- Create → 7 days of freedom → Stale warning → Codify or Discard

---

### 6. `/inherit` — Preserve Past Wisdom

**Purpose**: Extract implicit design system from existing codebase.

**Why This Matters for Flow**:
- Past decisions shouldn't be invisible
- Onboarding shouldn't start from zero
- Existing patterns are information

**What It Does**:
- Scans codebase for patterns
- Infers colors, typography, spacing, motion
- Shows confidence levels
- Asks for confirmation/refinement

---

### 7. `/garden` — Periodic Health Check

**Purpose**: Occasional review, not constant interruption.

**Why This Matters for Flow**:
- Batch the maintenance, protect the making
- Weekly ritual, not hourly alerts
- Review and resolve, then return to work

**What It Reports**:
- Constitution status
- Lens coverage
- Stale sandboxes
- Expiring locked decisions
- Recommended actions

---

### 8. `/setup` — Initialize and Get Out of the Way

**Purpose**: Quick setup, minimal interruption, back to work.

---

## The Constitution

Some things are settled at a level above individual decisions:

```yaml
protected:
  - withdraw        # User can always exit
  - risk_alert      # Warnings always shown
  - fee_disclosure  # Fees visible before confirm
  - balance_visible # User sees what they own
```

These aren't for `/consult`. They're constitutional. Marketing can't toggle them. The craftsman protects the user.

---

## Lenses

The same product, honestly rendered for different users:

| Lens | Mental Model | The Craftsman Thinks About |
|------|--------------|---------------------------|
| Pot (Henlocker) | Physical jar | "How does putting money in a jar feel?" |
| Vault (Chef) | Financial instrument | "How does a power user want to interact?" |
| Dashboard (Taster) | Analytics | "What does an operator need to see?" |

The agent implements the physics. The craftsman defines the feel.

---

## Lens-Specific Physics

Interaction should match the mental model:

**Pot Physics** (tactile, forgiving):
- Big tap targets (48px+)
- Drag-and-drop deposit
- Generous hit areas
- Undo-friendly

**Vault Physics** (efficient, precise):
- Compact form (32px targets)
- Keyboard shortcuts
- Numeric input with quick amounts
- Dense, efficient

The craftsman decides which physics fit the moment. The agent implements them.

---

## Inspector Mode

Engineering truth hidden by default, revealable when needed:

```
Cmd+Option reveals:
- Entity IDs
- Contract addresses
- Current strategy
- Active persona
```

Clean UI for users. X-ray vision for debugging.

---

## Vibe Checks

Quantitative data says WHAT. Qualitative asks WHY.

```yaml
trigger: "strategy_change:glance_to_personal"
question: "What were you looking for?"
options: ["Fees", "History", "Just curious"]
```

The craftsman uses this to understand users, not to optimize metrics.

---

## What Sigil Is NOT

- **Not a shortcut for thinking**: The craft requires deep thought
- **Not automation of taste**: Taste is human, irreducibly
- **Not a replacement for observation**: Watch users, feel the product
- **Not a way to avoid decisions**: It's for AFTER you've decided

---

## What Sigil IS

- **A memory for your design decisions**
- **A context restorer after time away**
- **An implementation partner for the mechanics**
- **A protector of flow state**
- **A way to stop re-arguing settled questions**

---

## The One-Liner

> **Sweat the art. We handle the mechanics. Return to flow.**
