---
name: consult
description: Lock a decision you've already made through deliberation
skill: consulting-decisions
skill_path: .claude/skills/consulting-decisions/SKILL.md
preflight:
  - sigil_mounted
human_effort: low
effort_type: confirmation
---

# /consult — Lock a Deliberated Decision

## Purpose

When you've **already thought deeply** and reached a conclusion, `/consult` locks it so you don't re-argue with yourself later.

This is for AFTER deliberation, not instead of it.

## When to Use

✓ You've been thinking about button colors for three days. You've decided.
✓ The team keeps revisiting a settled question.
✓ You want to commit and move on.

✗ You're still exploring options.
✗ You haven't thought deeply yet.
✗ You want the agent to decide for you.

## Usage

```bash
# Lock a decision you've made
/consult "button color for primary CTA"

# Unlock if new information emerges
/consult --unlock DEC-2026-001
```

## What Happens

1. **Topic** — What have you decided about?
2. **Scope** — How long should this lock?
   - Strategic: 180 days (fundamental direction)
   - Direction: 90 days (pattern choice)
   - Execution: 30 days (implementation detail)
3. **Context** — Agent gathers relevant info
4. **Options** — Agent presents options with trade-offs
5. **Your Decision** — You confirm what you've already decided
6. **Lock** — Protected for the period

## Example

```
/consult "primary button color"

CONTEXT:
- Your moodboard: "Confident & Secure"
- Zone: Critical (checkout)

OPTIONS:
  [A] Blue — industry standard, confident feel
  [B] Green — brand differentiation
  [C] Custom

You: "Blue. I've already decided."

DECISION LOCKED
ID: DEC-2026-001
Lock: 90 days
```

## Integration

- `/craft` reminds you if you touch locked areas
- `/garden` shows lock status and expirations
- Unlock always possible with justification

## Philosophy

> "After you've thought deeply, lock it. Stop re-arguing."

This protects your flow by preventing bikeshedding on settled questions.
