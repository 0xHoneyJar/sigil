---
name: envision
description: Capture your vision before it fades
skill: envisioning-moodboard
skill_path: .claude/skills/envisioning-moodboard/SKILL.md
preflight:
  - sigil_mounted
human_effort: medium
effort_type: expression
---

# /envision — Capture Your Vision

## Purpose

When inspiration is clear and vivid, `/envision` helps you externalize it before it fades.

This is about capturing what moved you — the products that felt right, the moments you want to create, the patterns you've learned to hate.

## When to Use

✓ Vision is clear and you want to capture it
✓ Inspiration just struck and it's vivid
✓ Onboarding someone new to the feel
✓ Revisiting and refining established vision

## Usage

```bash
# Full capture session
/envision

# Focus on specific sections
/envision --section values
/envision --section lenses
/envision --section feel
```

## What Gets Captured

### References
"What products inspire this feel?"

Take your time here. Talk about:
- Games that felt right
- Apps that delighted you
- What specifically to capture from each

### Feel by Context
"How should high-stakes moments feel?"

Go deep. This matters:
- Transaction feel (confident? swift? ceremonial?)
- Success feel (earned? celebrated? understated?)
- Loading feel (calm? engaged? invisible?)
- Error feel (gentle? direct? recoverable?)

### Anti-Patterns
"What must we never do?"

The patterns you've learned to hate:
- Why they're wrong for this product
- What they communicate that you don't want

### Values (Constitution)
"What's non-negotiable?"

Protected capabilities:
- Security, accessibility, performance
- User protections that can't be overridden

### Lenses (Personas)
"Who are you designing for?"

Each persona with their:
- Mental model
- Constraints
- How the product should feel to them

## Output

```
sigil-mark/moodboard.md         — Your vision, preserved
sigil-mark/constitution/        — Protected capabilities
sigil-mark/lens-array/          — User perspectives
```

## Philosophy

> "Capture the vision while it's vivid."

Inspiration fades. The moodboard survives.
