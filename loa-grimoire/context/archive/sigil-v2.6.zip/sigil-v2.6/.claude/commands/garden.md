---
name: garden
description: Review design health and maintain system integrity
skill: gardening-entropy
skill_path: .claude/skills/gardening-entropy/SKILL.md
preflight:
  - sigil_mounted
human_effort: low
effort_type: approval
---

# /garden — Design Health Report

## Purpose

Review design system health. Report on constitution violations, lens coverage, sandbox status, and locked decisions. Approve recommended actions.

## Usage

```bash
# Full health report
/garden

# Focus areas
/garden --constitution
/garden --lenses
/garden --sandboxes
/garden --decisions
```

## Report Sections

### Constitution Status
```
CONSTITUTION STATUS
┌─────────────────────────────────────────────────────────┐
│ Protected Capabilities: 8 defined                       │
│ Violations This Week: 0 ✓                               │
│ Override Requests: 2 (approved: 1, denied: 1)          │
└─────────────────────────────────────────────────────────┘
```

### Lens Coverage
```
LENS COVERAGE
┌─────────────────────────────────────────────────────────┐
│ Lens          │ Components │ Passing │ Coverage        │
├─────────────────────────────────────────────────────────┤
│ power_user    │ 24         │ 22      │ ████████░░ 92% │
│ newcomer      │ 24         │ 20      │ ███████░░░ 83% │
│ mobile        │ 24         │ 18      │ ██████░░░░ 75% │
│ accessibility │ 24         │ 24      │ ██████████ 100%│
└─────────────────────────────────────────────────────────┘
```

### Sandbox Status
```
SANDBOXES
┌─────────────────────────────────────────────────────────┐
│ experiment-sticky-header.tsx  │ 3 days  │ OK           │
│ experiment-drag-deposit.tsx   │ 9 days  │ STALE ⚠️     │
│ experiment-confetti.tsx       │ 15 days │ CRITICAL 🔴  │
└─────────────────────────────────────────────────────────┘
```

### Locked Decisions
```
LOCKED DECISIONS
┌─────────────────────────────────────────────────────────┐
│ DEC-2026-001: Primary CTA Color │ 87 days remaining    │
│ DEC-2026-002: Onboarding Flow   │ 120 days remaining   │
└─────────────────────────────────────────────────────────┘
```

### Recommendations
```
RECOMMENDATIONS
┌─────────────────────────────────────────────────────────┐
│ 1. Codify or discard: experiment-drag-deposit.tsx      │
│    [Codify] [Discard]                                  │
│                                                         │
│ 2. Mobile lens coverage low (75%)                      │
│    [View failing components]                           │
│                                                         │
│ 3. CRITICAL: experiment-confetti.tsx (15 days)         │
│    [Codify] [Discard] [Extend 7 days]                  │
└─────────────────────────────────────────────────────────┘
```

## Actions

Each recommendation has inline actions. Click to resolve:
- **[Codify]** — Promote sandbox to proper component
- **[Discard]** — Delete sandbox
- **[Extend]** — Add 7 more days
- **[View]** — See details

## Philosophy

> "Report with inline actions. Click to resolve."

Garden shows problems AND solutions. Approve the fix, don't debug it.
