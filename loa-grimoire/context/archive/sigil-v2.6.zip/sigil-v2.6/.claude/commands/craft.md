---
name: craft
description: Restore context and support deep exploration
skill: crafting-guidance
skill_path: .claude/skills/crafting-guidance/SKILL.md
preflight:
  - sigil_mounted
human_effort: low
effort_type: conversation
---

# /craft — Return to Flow

## Purpose

`/craft` helps you:
1. **Restore context** after time away
2. **Get zone-specific guidance** during implementation
3. **Deep dive** when the craft demands it

The agent handles mechanics. You focus on feel.

## Usage

```bash
# Restore context after time away
/craft

# Get guidance for a specific file
/craft src/features/checkout/Button.tsx

# Deep dive on a topic
/craft "I want to explore confirmation animations in depth"

# Validate against a specific lens
/craft --lens mobile

# See lens physics
/craft --physics
```

## Modes

### Return Mode (after time away)

```
/craft

"Welcome back. Here's where we are:

PRODUCT FEEL
[Your moodboard summary]

LOCKED DECISIONS
🔒 DEC-2026-001: Primary CTA is Blue (87 days remaining)

ZONES
Critical: checkout/** → Deliberate (800ms+)
Marketing: marketing/** → Playful

What would you like to work on?"
```

### File-Specific Mode

```
/craft src/features/checkout/Button.tsx

Zone: Critical
Motion: Deliberate (800ms+)
Locked: Primary button is Blue
Constitution: fee_disclosure must be visible

[Contextual guidance for this specific file]
```

### Deep Dive Mode

```
/craft "I want to explore confirmation animations in depth"

[Comprehensive exploration]
- Different approaches with trade-offs
- References from your moodboard
- Timing considerations
- Spring physics options

Take your time. Let me know what feels right.
```

## Philosophy

> "Restore context. Support exploration. Handle mechanics."

The craftsman thinks about feel. The agent handles implementation.
