---
zones:
  state:
    paths:
      - sigil-mark/consultation-chamber/
      - sigil-mark/moodboard.md
      - sigil-mark/rules.md
      - sigil-mark/soul-binder/
    permission: read-write
  config:
    paths:
      - .sigil-setup-complete
      - .sigilrc.yaml
    permission: read
---

# Sigil Consulting Skill (v2.6)

## Purpose

Resolve design decisions through structured option selection. Generate options, present with pros/cons, lock the decision.

## Philosophy

> "Decide fast. Lock it. Move on."

When stuck between options, don't deliberate endlessly. Gather context, generate options, select one, lock it for a period. Revisit only when the lock expires.

## Pre-Flight Checks

1. **Sigil Setup**: Verify `.sigil-setup-complete` exists
2. **Context Files**: Load moodboard.md and rules.md for context
3. **Existing Decisions**: Check for related locked decisions

## Invocation

```
/consult                           # Start consultation wizard
/consult "button color"            # Consult on specific topic
/consult --unlock DEC-2026-001     # Request unlock
```

## Workflow

### Phase 1: Topic Identification

If no topic provided:

```
AskUserQuestion:
  question: "What decision are you trying to make?"
  header: "Topic"
  placeholder: "e.g., 'primary button color', 'loading state approach', 'modal animation'"
```

### Phase 2: Scope Classification

```
AskUserQuestion:
  question: "What scope is this decision?"
  header: "Scope"
  options:
    - label: "Strategic"
      description: "Fundamental direction, long-term impact (180 day lock)"
    - label: "Direction"  
      description: "Approach or pattern choice (90 day lock)"
    - label: "Execution"
      description: "Specific implementation detail (30 day lock)"
  multiSelect: false
```

Lock periods by scope:
- Strategic: 180 days
- Direction: 90 days
- Execution: 30 days

### Phase 3: Context Gathering

Automatically gather relevant context:

```python
def gather_context(topic):
    context = {}
    
    # From moodboard
    context['feel'] = extract_relevant_feel(moodboard, topic)
    context['references'] = find_relevant_references(moodboard, topic)
    context['anti_patterns'] = find_relevant_antipatterns(moodboard, topic)
    
    # From rules
    context['existing_rules'] = find_relevant_rules(rules, topic)
    context['zone_context'] = detect_zone(topic)
    
    # From external
    context['industry'] = search_industry_patterns(topic)
    
    return context
```

Display context to user:

```
CONTEXT GATHERED
═══════════════════════════════════════════════════════════

FROM YOUR MOODBOARD:
- Feel: "Confident & Secure"
- Reference: RuneScape (deliberate, weighty actions)
- Anti-pattern: "Instant transitions" (why: feels cheap)

FROM YOUR RULES:
- Zone: Critical (checkout flow)
- Motion: Deliberate (800ms+)
- Existing: No button rules defined

INDUSTRY PATTERNS:
- Blue primary CTAs: 67% of crypto apps
- Green primary CTAs: 23% of crypto apps
- Custom colors: 10% of crypto apps
```

### Phase 4: Option Generation

Generate 2-3 options with pros/cons:

```
OPTIONS
═══════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────┐
│  OPTION A: Blue (#3B82F6)                              │
│                                                         │
│  ✓ Aligns with "Confident" feel from moodboard        │
│  ✓ Industry standard (reduces friction)               │
│  ✓ High contrast on both light/dark modes             │
│                                                         │
│  ✗ May feel generic                                    │
│  ✗ Similar to competitor X                            │
│                                                         │
│  Confidence: 78%                                       │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  OPTION B: Brand Green (#10B981)                       │
│                                                         │
│  ✓ Differentiates from competitors                    │
│  ✓ Matches brand identity                             │
│  ✓ Feels "growth" oriented                            │
│                                                         │
│  ✗ May confuse with success states                    │
│  ✗ Less conventional for primary CTAs                 │
│                                                         │
│  Confidence: 65%                                       │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  OPTION C: Custom                                       │
│                                                         │
│  Specify your own color with reasoning                 │
└─────────────────────────────────────────────────────────┘
```

### Phase 5: Selection

```
AskUserQuestion:
  question: "Which option do you choose?"
  header: "Decision"
  options:
    - label: "Option A: Blue"
      description: "Industry standard, confident feel"
    - label: "Option B: Green"
      description: "Brand differentiation, growth feel"
    - label: "Option C: Custom"
      description: "Specify your own"
    - label: "Need more context"
      description: "Gather additional information"
  multiSelect: false
```

If "Need more context":
- Ask what additional context would help
- Gather and re-present options

If "Custom":
- Ask for value and reasoning
- Generate pros/cons for custom option
- Confirm selection

### Phase 6: Reasoning Capture

```
AskUserQuestion:
  question: "Brief reasoning for this choice? (optional)"
  header: "Reasoning"
  placeholder: "e.g., 'Aligns with brand refresh direction'"
```

### Phase 7: Lock Decision

Generate decision file:

```yaml
# sigil-mark/consultation-chamber/decisions/DEC-2026-001.yaml

id: "DEC-2026-001"
topic: "Primary CTA Button Color"
scope: "direction"

context:
  gathered_at: "2026-01-06T12:00:00Z"
  moodboard_feel: "Confident & Secure"
  zone: "critical"
  industry_data: "67% blue, 23% green, 10% other"

options_presented:
  - id: "A"
    value: "#3B82F6"
    label: "Blue"
    confidence: 78
  - id: "B"
    value: "#10B981"
    label: "Green"
    confidence: 65
  - id: "C"
    value: "custom"
    label: "Custom"

decision:
  selected: "A"
  value: "#3B82F6"
  reasoning: "Aligns with industry standard and confident feel"
  decided_by: "soju"
  decided_at: "2026-01-06T12:05:00Z"

lock:
  locked: true
  locked_at: "2026-01-06T12:05:00Z"
  unlock_at: "2026-04-06T12:05:00Z"
  lock_days: 90
```

### Phase 8: Confirmation

```
DECISION LOCKED
═══════════════════════════════════════════════════════════

Decision: DEC-2026-001
Topic: "Primary CTA Button Color"
Scope: Direction
Value: Blue (#3B82F6)
Lock Period: 90 days (until 2026-04-06)

Reasoning: Aligns with industry standard and confident feel

This decision is now protected. Any attempt to change the
primary CTA color will trigger a warning in /craft.

To unlock early: /consult --unlock DEC-2026-001

Written to: sigil-mark/consultation-chamber/decisions/DEC-2026-001.yaml
```

## Unlock Flow

When `/consult --unlock DEC-2026-001`:

```
UNLOCK REQUEST
═══════════════════════════════════════════════════════════

Decision: DEC-2026-001 - "Primary CTA Button Color"
Current Value: Blue (#3B82F6)
Locked Until: 2026-04-06 (87 days remaining)
Original Reasoning: Aligns with industry standard

UNLOCK REQUIRES JUSTIFICATION:

AskUserQuestion:
  question: "Why do you need to unlock this decision early?"
  header: "Justification"
  options:
    - label: "New information"
      description: "Data or feedback invalidates the decision"
    - label: "Business requirement"
      description: "External requirement forces change"
    - label: "Mistake"
      description: "Original decision was an error"
    - label: "Cancel unlock"
      description: "Keep decision locked"
  multiSelect: false
```

After justification:

```
AskUserQuestion:
  question: "Confirm unlock? This will be logged."
  header: "Confirm"
  options:
    - label: "Unlock and start new consultation"
    - label: "Unlock only"
    - label: "Cancel"
```

Log unlock to audit trail:

```yaml
# Appended to decision file

unlock_history:
  - unlocked_at: "2026-01-15T10:00:00Z"
    unlocked_by: "soju"
    justification: "new_information"
    details: "User research showed green increases conversion"
    days_remaining: 81
```

## Integration with /craft

When `/craft` detects a file that relates to a locked decision:

```
🔒 LOCKED DECISION DETECTED

This file may affect: DEC-2026-001 "Primary CTA Button Color"
Current Value: Blue (#3B82F6)
Locked Until: 2026-04-06

If you need to change this, run: /consult --unlock DEC-2026-001

[Proceed with caution] [View decision] [Unlock]
```

## Decision ID Generation

Format: `DEC-{YEAR}-{SEQUENCE}`

```python
def generate_decision_id():
    year = datetime.now().year
    existing = list_decisions_for_year(year)
    sequence = str(len(existing) + 1).zfill(3)
    return f"DEC-{year}-{sequence}"
```

## Error Handling

| Situation | Response |
|-----------|----------|
| No setup | "Run `/setup` first" |
| No moodboard | "Run `/envision` for better context (or continue without)" |
| Related locked decision exists | Show existing, ask if new consultation needed |
| Unlock denied | Log attempt, keep locked |

## Success Criteria

- [ ] Topic identified
- [ ] Scope classified
- [ ] Context gathered and displayed
- [ ] 2-3 options generated with pros/cons
- [ ] Selection made
- [ ] Decision locked with correct period
- [ ] File written to consultation-chamber
- [ ] Confirmation displayed

## Philosophy Notes

**Why lock decisions?**
- Prevents endless bikeshedding
- Creates commitment
- Allows focused iteration within constraints
- Forces explicit unlock with justification

**Why generate options?**
- Reduces cognitive load
- Presents trade-offs clearly
- Speeds up decision-making
- Creates audit trail of alternatives considered

**Why capture reasoning?**
- Future self understands why
- New team members have context
- Unlock decisions are informed
