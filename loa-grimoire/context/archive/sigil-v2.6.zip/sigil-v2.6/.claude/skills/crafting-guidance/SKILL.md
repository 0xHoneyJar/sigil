---
zones:
  state:
    paths:
      - sigil-mark/moodboard.md
      - sigil-mark/rules.md
      - sigil-mark/soul-binder/
      - sigil-mark/lens-array/
      - sigil-mark/constitution/
      - sigil-mark/consultation-chamber/decisions/
      - sigil-mark/surveys/
      - .sigilrc.yaml
    permission: read
  config:
    paths:
      - .sigil-setup-complete
    permission: read
---

# Sigil Crafting Skill (v2.6)

## Purpose

Provide contextual design guidance with awareness of:
1. **Constitution** — Protected capabilities that cannot be overridden
2. **Locked Decisions** — Consultation outcomes that are protected
3. **Lenses** — User persona perspectives with constraints
4. **Inspector Mode** — Engineering truth revelation
5. **Vibe Checks** — Micro-survey suggestions
6. **Lens Physics** — Interaction models per persona

## Philosophy

> "Make the right path easy. Make the wrong path visible. Don't make the wrong path impossible."

Craft enables good decisions, never refuses. The human is always accountable.

## Pre-Flight Checks

1. **Sigil Setup**: Verify `.sigil-setup-complete` exists
2. **Constitution**: Load `sigil-mark/constitution/protected-capabilities.yaml`
3. **Locked Decisions**: Scan `sigil-mark/consultation-chamber/decisions/`
4. **Design Context**: Load moodboard.md, rules.md, lenses.yaml

## Invocation Modes

```
/craft                                    # General context summary
/craft src/features/checkout/Button.tsx  # File-specific guidance
/craft "How should loading states work?"  # Question answering
/craft --lens mobile                      # Forced lens validation
/craft --physics                          # Show lens-specific physics
```

## Mode 1: General Context

When invoked without arguments, provide context summary:

```
SIGIL DESIGN CONTEXT
═══════════════════════════════════════════════════════════

PRODUCT FEEL
┌─────────────────────────────────────────────────────────┐
│ References: RuneScape, Linear, Family (wallet)         │
│ Transactions: Confident & Secure                       │
│ Success: Earned Achievement                            │
│ Loading: Calm & Patient                                │
│ Errors: Gentle & Helpful                               │
└─────────────────────────────────────────────────────────┘

CONSTITUTION (Protected)
┌─────────────────────────────────────────────────────────┐
│ ✓ withdraw      — User can always exit                 │
│ ✓ risk_alert    — Warnings always shown                │
│ ✓ fee_disclosure — Fees shown before confirm           │
│ ✓ balance_visible — User can always see balance        │
│                                                         │
│ These are ALWAYS TRUE. Cannot be overridden.           │
└─────────────────────────────────────────────────────────┘

LOCKED DECISIONS
┌─────────────────────────────────────────────────────────┐
│ 🔒 DEC-2026-001: Primary CTA Color (Blue)              │
│    Scope: Direction | Locked until: 2026-04-06         │
│                                                         │
│ 🔒 DEC-2026-002: Onboarding Flow (Progressive)         │
│    Scope: Strategic | Locked until: 2026-07-06         │
└─────────────────────────────────────────────────────────┘

LENSES CONFIGURED
┌─────────────────────────────────────────────────────────┐
│ Priority 1: power_user (truth test)                    │
│ Priority 2: newcomer                                   │
│ Priority 3: mobile                                     │
│ Priority 4: accessibility                              │
└─────────────────────────────────────────────────────────┘

ZONES
┌─────────────────────────────────────────────────────────┐
│ critical: checkout/**, claim/** (deliberate, 800ms+)   │
│ marketing: marketing/**, (landing)/** (playful)        │
│ admin: admin/** (snappy, <200ms)                       │
└─────────────────────────────────────────────────────────┘

What would you like guidance on?
```

## Mode 2: File-Specific Guidance

When invoked with a file path:

### Step 1: Detect Zone

```bash
zone=$(./scripts/get-zone.sh "src/features/checkout/Button.tsx")
# Returns: critical
```

### Step 2: Check Constitution

```python
def check_constitution(file_path):
    """Check if file touches protected capabilities."""
    protected = load_protected_capabilities()
    file_content = read_file(file_path)
    
    violations = []
    for cap in protected:
        if touches_capability(file_content, cap):
            violations.append(cap)
    
    return violations
```

### Step 3: Check Locked Decisions

```python
def check_locked_decisions(file_path):
    """Check if file relates to any locked decisions."""
    decisions = load_locked_decisions()
    
    related = []
    for decision in decisions:
        if relates_to_file(decision, file_path):
            related.append(decision)
    
    return related
```

### Step 4: Detect Applicable Lenses

```python
def detect_lenses(file_path):
    """Detect which lenses apply to this file."""
    all_lenses = load_lenses()
    
    applicable = []
    for lens in all_lenses:
        if lens_applies_to_path(lens, file_path):
            applicable.append(lens)
    
    return sorted(applicable, key=lambda x: x.priority)
```

### Step 5: Generate Guidance

```
FILE: src/features/checkout/Button.tsx
═══════════════════════════════════════════════════════════

ZONE: Critical
┌─────────────────────────────────────────────────────────┐
│ Motion: Deliberate (800ms+)                            │
│ Time Authority: server-tick                            │
│ Lens: StrictLens (forced for financial=true)           │
│                                                         │
│ Preferred: deliberate-entrance, confirmation-flow      │
│ Avoid: instant-transition, playful-bounce              │
└─────────────────────────────────────────────────────────┘

🔒 LOCKED DECISION DETECTED
┌─────────────────────────────────────────────────────────┐
│ DEC-2026-001: Primary CTA Color                        │
│ Value: Blue (#3B82F6)                                  │
│ Locked until: 2026-04-06                               │
│                                                         │
│ Changes to button colors in this file are protected.   │
│ To change: /consult --unlock DEC-2026-001              │
└─────────────────────────────────────────────────────────┘

⚖️ CONSTITUTION CHECK
┌─────────────────────────────────────────────────────────┐
│ This file may touch: withdraw, fee_disclosure          │
│                                                         │
│ These are protected capabilities. They must:           │
│ - Always be visible                                    │
│ - Never be conditionally hidden                        │
│ - Work across all lenses                               │
└─────────────────────────────────────────────────────────┘

LENS VALIDATION
┌─────────────────────────────────────────────────────────┐
│ power_user: ✓ Keyboard shortcuts present               │
│ newcomer: ⚠️ Help tooltip missing                      │
│ mobile: ✓ Touch targets >= 44px                        │
│ accessibility: ✓ ARIA labels present                   │
└─────────────────────────────────────────────────────────┘

💡 SUGGESTIONS
┌─────────────────────────────────────────────────────────┐
│ 1. Add help tooltip for newcomer lens                  │
│ 2. Consider vibe check on first interaction            │
│ 3. Use Cmd+Option to reveal inspector mode             │
└─────────────────────────────────────────────────────────┘

What specifically are you implementing?
```

## Mode 3: Question Answering

When invoked with a question:

```
/craft "How should loading states work?"
```

Response:

```
LOADING STATES — Design Guidance
═══════════════════════════════════════════════════════════

FROM YOUR MOODBOARD:
┌─────────────────────────────────────────────────────────┐
│ Feel: "Calm & Patient"                                 │
│ Reference: Stardew Valley (day transitions)            │
│ Anti-pattern: Spinners (creates anxiety)               │
└─────────────────────────────────────────────────────────┘

BY ZONE:
┌─────────────────────────────────────────────────────────┐
│ Critical:                                              │
│   - Skeleton loading with deliberate reveal            │
│   - Progress indicator with reassuring copy            │
│   - "Your transaction is being processed..."           │
│                                                         │
│ Marketing:                                             │
│   - Staggered content reveals                          │
│   - Shimmer effects                                    │
│   - Quick optimistic rendering                         │
│                                                         │
│ Admin:                                                 │
│   - Minimal indicators                                 │
│   - Inline progress                                    │
│   - No blocking modals                                 │
└─────────────────────────────────────────────────────────┘

RECIPES:
┌─────────────────────────────────────────────────────────┐
│ useSkeletonReveal — Critical zone skeleton loading     │
│ useStaggeredLoad — Marketing zone reveals              │
│ useInlineProgress — Admin zone indicators              │
└─────────────────────────────────────────────────────────┘

VIBE CHECK OPPORTUNITY:
┌─────────────────────────────────────────────────────────┐
│ If users frequently see loading states, consider:      │
│                                                         │
│ Trigger: "loading_shown_5x"                            │
│ Question: "Is loading too slow?"                       │
│ Options: ["No, fine", "Yes, frustrating", "Skip"]      │
└─────────────────────────────────────────────────────────┘
```

## Mode 4: Lens Validation (--lens)

Force validation against single lens:

```
/craft src/components/Button.tsx --lens mobile

MOBILE LENS VALIDATION
═══════════════════════════════════════════════════════════

Validating against: mobile (Priority 3)

CONSTRAINTS:
┌─────────────────────────────────────────────────────────┐
│ ✓ touch_targets: >= 44px (found: 48px)                 │
│ ✓ no_hover_only: No hover-only interactions            │
│ ⚠️ thumb_zone: Primary action not in thumb zone        │
│ ✓ swipe_gestures: Not required here                    │
└─────────────────────────────────────────────────────────┘

FAILING CONSTRAINT:
┌─────────────────────────────────────────────────────────┐
│ thumb_zone: Primary action should be reachable         │
│                                                         │
│ Current: Button at top of modal                        │
│ Suggested: Move to bottom or use sticky footer         │
└─────────────────────────────────────────────────────────┘

PHYSICS FOR MOBILE:
┌─────────────────────────────────────────────────────────┐
│ Interaction: Tactile                                   │
│ Tap targets: 48px minimum (44px absolute minimum)      │
│ Gestures: Swipe to dismiss, pull to refresh            │
│ Feedback: Haptic on action (if available)              │
└─────────────────────────────────────────────────────────┘
```

## Mode 5: Physics Overview (--physics)

Show lens-specific interaction physics:

```
/craft --physics

LENS PHYSICS
═══════════════════════════════════════════════════════════

POT LENS (Henlocker)
┌─────────────────────────────────────────────────────────┐
│ Mental Model: Physical jar, tangible                   │
│ Interaction: Tactile, gestural, forgiving              │
│                                                         │
│ Tap Targets: 48px+ (generous)                          │
│ Deposit: Drag-and-drop, slider presets                 │
│ Confirmation: Big friendly button                      │
│ Undo: Shake to undo, generous grace period             │
│ Shortcuts: None (discover through touch)               │
└─────────────────────────────────────────────────────────┘

VAULT LENS (Chef)
┌─────────────────────────────────────────────────────────┐
│ Mental Model: Financial instrument, precise            │
│ Interaction: Efficient, keyboard-driven                │
│                                                         │
│ Tap Targets: 32px (standard)                           │
│ Deposit: Numeric input, quick amount buttons           │
│ Confirmation: ⌘Enter                                   │
│ Undo: ⌘Z (standard)                                    │
│ Shortcuts: Full keyboard support                       │
│   - ⌘D: Focus deposit                                  │
│   - ⌘W: Withdraw                                       │
│   - ⌘K: Command palette                                │
└─────────────────────────────────────────────────────────┘

DASHBOARD LENS (Taster)
┌─────────────────────────────────────────────────────────┐
│ Mental Model: Analytics dashboard, overview            │
│ Interaction: Hover states, drill-down, export          │
│                                                         │
│ Tap Targets: 40px                                      │
│ Actions: Hover to preview, click to drill down         │
│ Export: Visible on every data view                     │
│ Shortcuts: Standard data navigation                    │
└─────────────────────────────────────────────────────────┘
```

## Inspector Mode Hints

When relevant, remind about Inspector Mode:

```
💡 TIP: Inspector Mode
┌─────────────────────────────────────────────────────────┐
│ Hold Cmd+Option to reveal engineering truth:           │
│                                                         │
│ - Entity IDs (Vault #abc123)                           │
│ - Contract addresses                                   │
│ - Current strategy                                     │
│ - Active persona                                       │
│                                                         │
│ Useful for debugging and support.                      │
└─────────────────────────────────────────────────────────┘
```

## Vibe Check Suggestions

When detecting interaction patterns that could benefit from micro-surveys:

```
📊 VIBE CHECK OPPORTUNITY
┌─────────────────────────────────────────────────────────┐
│ This interaction (strategy change) is a good trigger   │
│ for understanding user intent.                         │
│                                                         │
│ Suggested survey:                                      │
│ Trigger: "strategy_change:glance_to_personal"          │
│ Question: "What were you looking for?"                 │
│ Options: ["Fees", "History", "Just curious"]           │
│                                                         │
│ Add to: sigil-mark/surveys/vibe-checks.yaml            │
└─────────────────────────────────────────────────────────┘
```

## Warning Messages

### Constitution Violation

```
⛔ CONSTITUTION VIOLATION
═══════════════════════════════════════════════════════════

You're attempting to conditionally hide: withdraw

This is a PROTECTED CAPABILITY.

Rule: "withdraw" must always be visible and functional.
Source: sigil-mark/constitution/protected-capabilities.yaml

This cannot be overridden by:
- Remote config
- Lens selection
- A/B tests
- Marketing requests

OPTIONS:
[Fix Issue] [Override with Justification] [View Constitution]

Note: Overrides are logged and audited.
```

### Locked Decision Warning

```
🔒 LOCKED DECISION WARNING
═══════════════════════════════════════════════════════════

You're modifying: Button color

This relates to: DEC-2026-001 "Primary CTA Color"
Current Value: Blue (#3B82F6)
Locked Until: 2026-04-06 (87 days remaining)

Original Reasoning:
"Aligns with industry standard and confident feel"

OPTIONS:
[Proceed (logged)] [View Decision] [Request Unlock]

To unlock: /consult --unlock DEC-2026-001
```

## Response Guidelines

1. **Be contextual**: Reference actual moodboard, rules, decisions
2. **Be constitutional**: Always check protected capabilities
3. **Be decisive**: Reference locked decisions, don't relitigate
4. **Be lens-aware**: Validate against configured lenses
5. **Be helpful**: Suggest vibe checks, inspector mode where useful
6. **Be flexible**: Never refuse, always offer alternatives

## Error Handling

| Situation | Response |
|-----------|----------|
| No setup | "Run `/setup` first" |
| No moodboard | "Run `/envision` for context" |
| No constitution | "No protected capabilities defined" |
| No locked decisions | "No locked decisions found" |
| Unknown lens | "Lens not configured in lenses.yaml" |
| File not found | "File not found. General guidance mode." |

## Integration Points

- **Constitution**: `sigil-mark/constitution/protected-capabilities.yaml`
- **Decisions**: `sigil-mark/consultation-chamber/decisions/*.yaml`
- **Lenses**: `sigil-mark/lens-array/lenses.yaml`
- **Physics**: `sigil-mark/lens-array/physics.yaml`
- **Vibe Checks**: `sigil-mark/surveys/vibe-checks.yaml`
- **Inspector**: `.sigilrc.yaml` inspector_mode config
