# Sigil v2.6 — Command Flows Reference

> "Sweat the art. We handle the mechanics. Return to flow."

---

## Philosophy in Practice

These flows protect the craftsman's flow state. They're not about speed or efficiency — they're about:

1. **Capturing inspiration** before it fades
2. **Restoring context** after time away
3. **Locking decisions** that have been deliberated
4. **Handling mechanics** so the craftsman focuses on feel

---

## Flow Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PROTECTING THE CRAFTSMAN'S FLOW                  │
│                                                                      │
│                                                                      │
│    [Inspiration strikes]                                            │
│           │                                                         │
│           ▼                                                         │
│    ┌──────────────┐                                                 │
│    │  /envision   │ ← Capture vision before it fades               │
│    │              │                                                 │
│    │  Go deep.    │                                                 │
│    │  Take time.  │                                                 │
│    └──────────────┘                                                 │
│           │                                                         │
│           ▼                                                         │
│    ┌──────────────┐                                                 │
│    │   /codify    │ ← Externalize tacit knowledge                  │
│    │              │                                                 │
│    │  Patterns    │                                                 │
│    │  you know.   │                                                 │
│    └──────────────┘                                                 │
│           │                                                         │
│           ▼                                                         │
│    ┌──────────────┐                                                 │
│    │  [DEEP WORK] │ ← The craft happens here                       │
│    │              │                                                 │
│    │  Design.     │                                                 │
│    │  Observe.    │                                                 │
│    │  Iterate.    │                                                 │
│    └──────┬───────┘                                                 │
│           │                                                         │
│     ┌─────┴─────┐                                                   │
│     │           │                                                   │
│     ▼           ▼                                                   │
│ [Time away]  [Stuck]                                                │
│     │           │                                                   │
│     ▼           ▼                                                   │
│ ┌────────┐  ┌──────────┐                                            │
│ │ /craft │  │ /consult │                                            │
│ │        │  │          │                                            │
│ │ Return │  │ Lock it. │                                            │
│ │ to     │  │ Move on. │                                            │
│ │ flow.  │  │          │                                            │
│ └────────┘  └──────────┘                                            │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Flow 1: Capturing Inspiration

When vision is clear and inspiration is vivid.

```
THE MOMENT
───────────────────────────────────────────────────────────────────────
You've been thinking. Reading. Playing games. Using products.
Something clicked. You see how the product should feel.
This insight is precious and fleeting.
───────────────────────────────────────────────────────────────────────

/envision

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  "What products inspire this feel?"                                 │
│                                                                      │
│  Take your time. This is about capturing what moved you.           │
│                                                                      │
│  → Talk about the games that felt right                            │
│  → The apps that delighted you                                     │
│  → What specifically you want to capture                           │
│                                                                      │
│  [Agent listens. Captures faithfully. Asks follow-ups.]            │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  "How should high-stakes moments feel?"                             │
│                                                                      │
│  Go deep here. This matters.                                        │
│                                                                      │
│  → Describe the weight you want                                    │
│  → The trust you want to build                                     │
│  → References that capture it                                      │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  Vision captured in sigil-mark/moodboard.md                         │
│                                                                      │
│  This survives:                                                     │
│    - Time away                                                      │
│    - New team members                                               │
│    - Your own forgetfulness                                         │
│                                                                      │
│  Return to it whenever you need to remember the feel.               │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Flow 2: Returning to Flow

After time away — a day, a week, a month.

```
THE MOMENT
───────────────────────────────────────────────────────────────────────
You stepped away. Life happened. 
Now you're back, staring at the code.
Where were we? What had we decided?
───────────────────────────────────────────────────────────────────────

/craft

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  PRODUCT FEEL                                                       │
│  ─────────────────────────────────────────────────                  │
│  References: RuneScape (deliberate actions), Linear (snappy UI)    │
│  Transactions: Confident & Secure                                   │
│  Success: Earned Achievement                                        │
│  Loading: Calm & Patient                                            │
│                                                                      │
│  LOCKED DECISIONS                                                   │
│  ─────────────────────────────────────────────────                  │
│  🔒 DEC-2026-001: Primary CTA is Blue (87 days remaining)          │
│  🔒 DEC-2026-002: Onboarding is Progressive (120 days)             │
│                                                                      │
│  ZONES                                                              │
│  ─────────────────────────────────────────────────                  │
│  Critical: checkout/**, claim/** → Deliberate (800ms+)             │
│  Marketing: marketing/** → Playful                                  │
│  Admin: admin/** → Snappy (<200ms)                                  │
│                                                                      │
│  What would you like to work on?                                    │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

You: "Let's work on the checkout confirmation."

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  CHECKOUT CONFIRMATION                                              │
│  ─────────────────────────────────────────────────                  │
│  Zone: Critical                                                     │
│  Motion: Deliberate (800ms+, heavy spring)                         │
│  Lens: StrictLens enforced (high-stakes)                           │
│                                                                      │
│  Locked: Primary button is Blue                                     │
│  Constitution: fee_disclosure must be visible                       │
│                                                                      │
│  Last session you were exploring skeleton loading vs spinners.      │
│  Spinners are in your anti-patterns ("creates anxiety").           │
│                                                                      │
│  Want to continue that exploration?                                 │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

[Context restored. Back in flow.]
```

---

## Flow 3: Locking a Decision

After deliberation, when it's time to commit.

```
THE MOMENT
───────────────────────────────────────────────────────────────────────
You've been thinking about button colors for three days.
You've looked at competitors. Considered brand. Thought about trust.
You've decided. Now lock it so you don't re-argue.
───────────────────────────────────────────────────────────────────────

/consult "primary button color"

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  CONSULTATION: Primary Button Color                                 │
│                                                                      │
│  Scope:                                                             │
│  ○ Strategic (180 days) — Fundamental direction                    │
│  ● Direction (90 days) — Pattern choice                            │
│  ○ Execution (30 days) — Implementation detail                     │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

You: "Direction. 90 days."

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  CONTEXT I'VE GATHERED                                              │
│  ─────────────────────────────────────────────────                  │
│  Your moodboard: "Confident & Secure"                               │
│  Zone: Critical (checkout flows)                                    │
│  Industry pattern: Blue (67%), Green (23%)                         │
│                                                                      │
│  OPTIONS                                                            │
│  ─────────────────────────────────────────────────                  │
│                                                                      │
│  [A] Blue (#3B82F6)                                                 │
│      ✓ Aligns with "confident" feel                                │
│      ✓ Industry standard, reduces friction                         │
│      ✗ May feel generic                                            │
│                                                                      │
│  [B] Green (#10B981)                                                │
│      ✓ Differentiates from competitors                             │
│      ✓ Matches "growth" semantics                                  │
│      ✗ May confuse with success states                             │
│                                                                      │
│  [C] Custom — specify your own                                      │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

You: "Blue. I've already decided."

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  DECISION LOCKED                                                    │
│  ─────────────────────────────────────────────────                  │
│  ID: DEC-2026-001                                                   │
│  Topic: Primary CTA Color                                           │
│  Value: Blue (#3B82F6)                                              │
│  Locked until: 2026-04-06 (90 days)                                 │
│                                                                      │
│  This decision is now protected.                                    │
│  /craft will remind you if you touch this area.                    │
│  Future-you can unlock with /consult --unlock DEC-2026-001         │
│                                                                      │
│  Written to: sigil-mark/consultation-chamber/decisions/             │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

[Decision locked. No more bikeshedding. Move on.]
```

---

## Flow 4: Deep Dive

When the craft demands deep exploration.

```
THE MOMENT
───────────────────────────────────────────────────────────────────────
You want to obsess over confirmation animations.
This detail matters. You're going to sweat it.
───────────────────────────────────────────────────────────────────────

/craft "I want to explore confirmation animations in depth"

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  CONFIRMATION ANIMATIONS — DEEP DIVE                                │
│                                                                      │
│  Let's explore this thoroughly.                                     │
│                                                                      │
│  ─────────────────────────────────────────────────                  │
│                                                                      │
│  FROM YOUR MOODBOARD                                                │
│  The feel you're after: "Confident & Secure"                        │
│  Reference: RuneScape skill confirmations (deliberate, weighty)    │
│  Anti-pattern: Instant transitions (feels cheap)                   │
│                                                                      │
│  ─────────────────────────────────────────────────                  │
│                                                                      │
│  APPROACHES TO CONSIDER                                             │
│                                                                      │
│  1. The Weight Approach                                             │
│     Heavy entrance (800ms+), deliberate spring                     │
│     Communicates: "This matters"                                   │
│     Risk: Can feel slow if overdone                                │
│     Reference: Banking apps, legal confirmations                   │
│                                                                      │
│  2. The Progression Approach                                        │
│     Multi-step with momentum                                        │
│     Communicates: "You're building toward something"              │
│     Risk: Can feel bureaucratic                                    │
│     Reference: Checkout flows, onboarding                          │
│                                                                      │
│  3. The Ceremony Approach                                           │
│     Distinct before/after states with celebration                  │
│     Communicates: "You've accomplished something"                  │
│     Risk: Can feel patronizing                                     │
│     Reference: Game achievements, completion screens               │
│                                                                      │
│  ─────────────────────────────────────────────────                  │
│                                                                      │
│  TIMING CONSIDERATIONS                                              │
│                                                                      │
│  For your "Confident & Secure" feel:                                │
│  - Under 300ms: Feels too easy, unimportant                        │
│  - 300-600ms: Standard, professional                               │
│  - 600-1000ms: Deliberate, important                               │
│  - Over 1000ms: Ceremonial, major moment                           │
│                                                                      │
│  ─────────────────────────────────────────────────                  │
│                                                                      │
│  SPRING PHYSICS OPTIONS                                             │
│                                                                      │
│  Tight spring (tension: 300, friction: 26):                        │
│    Quick and precise, professional feel                            │
│                                                                      │
│  Medium spring (tension: 180, friction: 20):                        │
│    Balanced, substantial but not heavy                             │
│                                                                      │
│  Heavy spring (tension: 120, friction: 14):                         │
│    Deliberate, weighty, "this matters"                             │
│                                                                      │
│  ─────────────────────────────────────────────────                  │
│                                                                      │
│  Take your time with this. Try things.                              │
│  Let me know what direction feels right.                            │
│                                                                      │
│  I can create a /sandbox if you want to experiment.                │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

[Agent supports the deep dive. No rushing. Go as deep as needed.]
```

---

## Flow 5: Safe Experimentation

When you need to break rules to discover new ones.

```
THE MOMENT
───────────────────────────────────────────────────────────────────────
You have an idea that doesn't fit the system.
You need to try it without triggering lint errors.
───────────────────────────────────────────────────────────────────────

/sandbox "drag-to-deposit interaction"

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  SANDBOX CREATED                                                    │
│  ─────────────────────────────────────────────────                  │
│  File: sigil-mark/sandbox/experiment-drag-deposit.tsx              │
│                                                                      │
│  This is a safe space:                                              │
│    ✓ No lint warnings for 7 days                                   │
│    ✓ Outside the design system                                     │
│    ✓ Free to break rules                                           │
│                                                                      │
│  In 7 days, I'll ask if you want to:                               │
│    - Codify: Promote to the system                                 │
│    - Discard: It was just exploration                              │
│    - Extend: Still cooking                                         │
│                                                                      │
│  Play freely.                                                       │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

[7 days later, in /garden]

┌─────────────────────────────────────────────────────────────────────┐
│                                                                      │
│  SANDBOX STATUS                                                     │
│  ─────────────────────────────────────────────────                  │
│  experiment-drag-deposit.tsx — 7 days old                          │
│                                                                      │
│  What would you like to do?                                         │
│                                                                      │
│  [Codify] — This belongs in the system                             │
│  [Discard] — It was just exploration                               │
│  [Extend 7 days] — Still working on it                             │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Flow Summary: Effort Distribution

```
┌─────────────────────────────────────────────────────────────────────┐
│                    WHERE EFFORT GOES                                │
│                                                                      │
│  ████████████████████████████████████████░░░░░░░░░░  Craftsman      │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████  Agent        │
│                                                                      │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                      │
│  CRAFTSMAN EFFORT (The Art):                                        │
│    - Deep thinking about feel                                       │
│    - Observing users                                                │
│    - Sweating the right details                                    │
│    - Deciding what matters                                          │
│    - Time away for perspective                                      │
│                                                                      │
│  AGENT EFFORT (The Mechanics):                                      │
│    - Tracking consistency                                           │
│    - Implementing physics                                           │
│    - Restoring context                                              │
│    - Managing locked decisions                                      │
│    - Handling boilerplate                                           │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## When NOT to Use Sigil Commands

**Don't use /envision** if vision isn't clear yet.
→ Go observe. Play with products. Let inspiration come.

**Don't use /consult** if you're still deliberating.
→ Keep thinking. Consult is for AFTER you've decided.

**Don't use /craft** for implementation details.
→ Just ask. Agent handles mechanics without commands.

**Don't use /garden** mid-flow.
→ It's for session start or weekly ritual.

---

## The One-Liner

> **Sweat the art. We handle the mechanics. Return to flow.**
