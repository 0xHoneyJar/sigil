# Sigil v2.6 — The Craftsman's Flow

> "Sweat the art. We handle the mechanics. Return to flow."

Sigil protects the craftsman's flow state. It handles implementation mechanics so you can focus on the art of design.

## Philosophy

```
┌─────────────────────────────────────────────────────────────────────┐
│                    THE CRAFTSMAN'S FLOW                             │
│                                                                      │
│  PROTECT:                                                           │
│    ✓ Deep thinking about feel and soul                              │
│    ✓ Time for inspiration and observation                          │
│    ✓ The joy of sweating the right details                         │
│    ✓ Deep dives when the craft demands it                          │
│                                                                      │
│  REMOVE:                                                            │
│    ✗ Implementation mechanics                                       │
│    ✗ Consistency tracking                                          │
│    ✗ Context loss after time away                                  │
│    ✗ Re-arguing settled questions                                  │
└─────────────────────────────────────────────────────────────────────┘
```

The craftsman SHOULD sweat the details — that's the essence of craft. Sigil removes the *wrong* cognitive load so you can focus on the *right* details.

## Quick Start

```bash
# When vision is clear
/envision

# After patterns emerge
/codify

# After time away
/craft

# When you've decided something
/consult "primary button color"

# Periodic health check
/garden
```

## Commands

| Command | When to Use |
|---------|-------------|
| `/envision` | Vision is clear, capture it before it fades |
| `/codify` | Patterns have emerged, externalize them |
| `/craft` | Returning after time away, or need context |
| `/consult` | You've deliberated and decided, lock it |
| `/sandbox` | Want to experiment outside the system |
| `/inherit` | Joining existing codebase |
| `/garden` | Weekly health check |
| `/setup` | Initialize Sigil |

## What Sigil Is

- **A memory** for your design decisions
- **A context restorer** after time away
- **An implementation partner** for the mechanics
- **A flow protector** against interruption
- **A lock** for settled questions

## What Sigil Is NOT

- **Not a shortcut for thinking** — the craft requires deep thought
- **Not automation of taste** — taste is human, irreducibly
- **Not a replacement for observation** — watch users, feel the product
- **Not a way to avoid decisions** — it's for AFTER you've decided

## Architecture

```
sigil-mark/
├── moodboard.md                    # Your vision
├── rules.md                        # Your taste, codified
│
├── constitution/                   # Protected capabilities
├── lens-array/                     # User perspectives
├── consultation-chamber/           # Locked decisions
├── surveys/                        # Vibe checks
└── sandbox/                        # Safe experimentation
```

## Key Concepts

### Constitution
Capabilities that are always protected. User can always withdraw. Fees are always disclosed. Not toggleable by marketing or A/B tests.

### Locked Decisions
After you've deliberated and decided, lock it. Stop re-arguing. Unlock later if new information emerges.

### Lenses
Different user personas viewing the same product. Power user wants efficiency. Newcomer needs guidance. Same truth, different experience.

### Zones
Areas of the product with different motion and feel. Critical zones are deliberate. Marketing zones are playful. Admin zones are snappy.

## Integration with Loa

Loa handles structure and logic. Sigil handles feel and interface.

```
Loa: PRD → SDD → Implementation → Deployment
Sigil: Vision → Rules → Deep Work → Polish
```

After Loa builds, use `/craft` to refine the interface layer.

## The One-Liner

> **Sweat the art. We handle the mechanics. Return to flow.**
